"use strict";
(self["webpackChunk_eightshift_redesign"] = self["webpackChunk_eightshift_redesign"] || []).push([["src_Blocks_components_header_assets_hide-header-scroll_js"],{

/***/ "./src/Blocks/components/header/assets/hide-header-scroll.js":
/*!*******************************************************************!*\
  !*** ./src/Blocks/components/header/assets/hide-header-scroll.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HideHeaderScroll: () => (/* binding */ HideHeaderScroll)
/* harmony export */ });
/* harmony import */ var _text_animation_assets_text_animation_handling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../text-animation/assets/text-animation-handling */ "./src/Blocks/components/text-animation/assets/text-animation-handling.js");

class HideHeaderScroll {
    constructor({ headerComponent, headerNavigationSelector, headerNavigationComponent, hideElementSelectors }){
        this.headerComponent = headerComponent;
        this.headerNavigationComponent = headerNavigationComponent;
        this.headerComponentLeft = headerComponent.querySelector(`${headerNavigationSelector}-left`);
        this.headerComponentCenter = headerComponent.querySelector(`${headerNavigationSelector}-center`);
        this.headerComponentRight = headerComponent.querySelector(`${headerNavigationSelector}-right`);
        this.hideElementSelectors = hideElementSelectors;
        this.hideElements = [];
        this.observer = {};
    }
    init() {
        this.hideElements = this.hideElementSelectors.reduce((acc, hideElementSelector)=>{
            const hideElements = this.headerNavigationComponent.querySelectorAll(hideElementSelector);
            return hideElementSelector.length ? [
                ...acc,
                ...hideElements
            ] : [
                ...acc
            ];
        }, []);
        (0,_text_animation_assets_text_animation_handling__WEBPACK_IMPORTED_MODULE_0__.setIndexToChildren)(this.hideElements);
        (0,_text_animation_assets_text_animation_handling__WEBPACK_IMPORTED_MODULE_0__.setNumberOfChildrenVariable)(this.headerNavigationComponent, this.hideElements);
        this.observer = new IntersectionObserver((e)=>{
            if (e[0].isIntersecting) {
                this.headerNavigationComponent.classList.remove('is-scroll');
            } else {
                this.headerNavigationComponent.classList.add('is-scroll');
            }
        }, {
            threshold: [
                0
            ]
        });
        this.observer.observe(this.headerComponent);
    }
}


/***/ }),

/***/ "./src/Blocks/components/text-animation/assets/text-animation-handling.js":
/*!********************************************************************************!*\
  !*** ./src/Blocks/components/text-animation/assets/text-animation-handling.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   setIndexToChildren: () => (/* binding */ setIndexToChildren),
/* harmony export */   setNumberOfChildrenVariable: () => (/* binding */ setNumberOfChildrenVariable)
/* harmony export */ });
const setNumberOfChildrenVariable = (element, children, childrenNumberVariableIdentifier = 'number-of-children')=>{
    element?.style.setProperty(`--${childrenNumberVariableIdentifier}`, children.length);
};
const setIndexToChildren = (children, childIndexVariableIdentifier = 'child-index')=>{
    [
        ...children
    ].forEach((child, index)=>{
        child.style.setProperty(`--${childIndexVariableIdentifier}`, index);
    });
};


/***/ })

}]);
"use strict";
(self["webpackChunk_eightshift_redesign"] = self["webpackChunk_eightshift_redesign"] || []).push([["src_Blocks_components_menu-accordion_assets_menu-accordion_js"],{

/***/ "./src/Blocks/components/menu-accordion/assets/menu-accordion.js":
/*!***********************************************************************!*\
  !*** ./src/Blocks/components/menu-accordion/assets/menu-accordion.js ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MenuAccordion: () => (/* binding */ MenuAccordion)
/* harmony export */ });
class MenuAccordion {
    constructor(options){
        this.element = options.element;
        this.menuItemSelector = options.menuItemSelector;
        this.menuItemIsActiveSelector = options.menuItemIsActiveSelector;
    }
    init() {
        this.checkActiveMenuItem();
    }
    checkActiveMenuItem = ()=>{
        const menuItems = this.element.querySelectorAll(`.${this.menuItemSelector}`);
        const isActiveItemPresent = Array.from(menuItems).some((item)=>item.classList.contains(this.menuItemIsActiveSelector));
        if (isActiveItemPresent) {
            this.element.classList.add('is-active-parent');
        }
    };
}


/***/ })

}]);
"use strict";
(self["webpackChunk_eightshift_redesign"] = self["webpackChunk_eightshift_redesign"] || []).push([["src_Blocks_components_drawer_assets_drawerMenuChoice_js"],{

/***/ "./src/Blocks/components/drawer/assets/drawerMenuChoice.js":
/*!*****************************************************************!*\
  !*** ./src/Blocks/components/drawer/assets/drawerMenuChoice.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DrawerMenuChoice: () => (/* binding */ DrawerMenuChoice)
/* harmony export */ });
/* harmony import */ var _text_animation_assets_text_animation_handling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../text-animation/assets/text-animation-handling */ "./src/Blocks/components/text-animation/assets/text-animation-handling.js");
/* harmony import */ var gsap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! gsap */ "./node_modules/gsap/index.js");


class DrawerMenuChoice {
    constructor({ drawer, itemsSelector, imageWrapperSelector, menuSelector, menuLinkSelector, imageSelector }){
        this.drawer = drawer;
        this.items = this.drawer.querySelectorAll(itemsSelector);
        this.imageWrapper = this.drawer.querySelector(imageWrapperSelector);
        this.menu = this.drawer.querySelector(menuSelector);
        this.image = imageSelector;
        this.menuLink = menuLinkSelector;
        this.accordion = this.drawer.querySelector('.js-menu-accordion');
        this.accordionContainer = this.drawer.querySelector('.js-menu-accordion-container');
        this.accordionLink = this.drawer.querySelector('.js-menu-accordion-main-link');
        this.mainMenuItems = this.drawer.querySelectorAll(`.menu__link`);
        this.drawerData = {};
        this.CLASS_IS_HOVER = 'is-hover';
        this.CLASS_IS_HIDDEN = 'is-hidden';
        this.zIndex = 1;
        this.revealedImage;
    }
    init() {
        let drawerItemImages = {};
        // Setting all the images to an object with Menu Item ID as a key.
        this.drawer.querySelectorAll(this.image).forEach((image)=>{
            drawerItemImages = {
                ...drawerItemImages,
                [image.dataset.id]: image
            };
        });
        // Setting Item links.
        [
            ...this.items
        ].forEach((drawerItem)=>{
            const link = drawerItem.querySelector(this.menuLink);
            if (!link) {
                return;
            }
            const path = link?.pathname?.replace(/^\/|\/$/g, '') || 'expertise';
            this.drawerData = {
                ...this.drawerData,
                [path]: {
                    path: path,
                    img: drawerItemImages[path],
                    link: link
                }
            };
        });
        this.drawerData = {
            ...this.drawerData,
            default: {
                path: 'default',
                img: drawerItemImages['default']
            }
        };
        this.setDefaultImage();
        (0,_text_animation_assets_text_animation_handling__WEBPACK_IMPORTED_MODULE_0__.setIndexToChildren)(this.mainMenuItems);
        // Setting event listener to links.
        Object.values(this.drawerData).map(({ link, path })=>{
            if (!link) {
                return;
            }
            if (path === 'expertise') {
                return;
            }
            link.addEventListener('mouseover', this.activateLinks);
            link.addEventListener('keyup', this.activateLinks);
        });
        [
            ...this.mainMenuItems
        ].forEach((item)=>{
            item.addEventListener('keyup', this.onHoverInnerEvent);
        });
        this.accordionLink.addEventListener('mouseover', this.activateExpertiseLinksShow);
        this.accordionLink.addEventListener('click', this.activateExpertiseLinksToggle);
    }
    onHoverInnerEvent = ()=>{
        if (!this.accordion.classList.contains(this.CLASS_IS_HOVER)) {
            this.accordion.classList.add(this.CLASS_IS_HOVER);
        }
        Object.entries(this.drawerData).map(([key, { link }])=>{
            if (!link) {
                return;
            }
            if (key !== 'expertise') {
                link.parentElement.classList.remove(this.CLASS_IS_HOVER);
            }
        });
        this.accordionLink.ariaExpanded = true;
        this.accordionContainer.ariaHidden = false;
    };
    activateExpertiseLinksToggle = (e)=>{
        const link = e.target;
        if (link.parentElement.classList.contains(this.CLASS_IS_HOVER)) {
            this.activateExpertiseLinksHide(e);
        } else {
            this.activateExpertiseLinksShow(e);
        }
    };
    activateExpertiseLinksShow = (e)=>{
        const link = e.target;
        if (window.matchMedia('(pointer: coarse)').matches && e.type === 'mouseover') {
            return;
        }
        link.nextElementSibling.ariaHidden = false;
        link.ariaExpanded = true;
        link.parentElement.classList.add(this.CLASS_IS_HOVER);
    };
    activateExpertiseLinksHide = (e)=>{
        const link = e.target;
        link.nextElementSibling.ariaHidden = true;
        link.ariaExpanded = false;
        link.parentElement.classList.remove(this.CLASS_IS_HOVER);
    };
    activateLinks = (e)=>{
        const link = e.target;
        this.resetImages();
        this.resetItems();
        const path = link?.pathname?.replace(/^\/|\/$/g, '') || 'expertise';
        const img = this.drawerData[path]?.img;
        link.parentElement.classList.add(this.CLASS_IS_HOVER);
        if (img) {
            this.revealImage(img);
        }
    };
    revealImage = (image)=>{
        if (!image?.parentElement || this.revealedImage === image) {
            return;
        }
        this.revealedImage = image;
        image.classList.remove(this.CLASS_IS_HIDDEN);
        image.parentElement.classList.add(this.CLASS_IS_HOVER);
        gsap__WEBPACK_IMPORTED_MODULE_1__["default"].fromTo(image, {
            yPercent: -100,
            scale: 1.15
        }, {
            scale: 1,
            duration: 1.2,
            ease: 'expo.out',
            yPercent: 0
        });
        gsap__WEBPACK_IMPORTED_MODULE_1__["default"].fromTo(image.parentElement, {
            yPercent: 100,
            zIndex: this.zIndex
        }, {
            duration: 1.2,
            ease: 'expo.out',
            yPercent: 0
        });
        this.zIndex++;
    };
    resetItems = ()=>{
        Object.values(this.drawerData).forEach(({ link })=>{
            if (!link) {
                return;
            }
            link?.parentElement?.classList.remove(this.CLASS_IS_HOVER);
        });
        this.accordionContainer.ariaHidden = true;
        this.accordionLink.ariaExpanded = false;
    };
    resetImages = ()=>{
        Object.values(this.drawerData).forEach(({ img })=>{
            img?.parentElement?.classList.remove(this.CLASS_IS_HOVER);
        });
    };
    setDefaultImage = ()=>{
        const path = window.location.pathname.replace(/^\/|\/$/g, '');
        const img = this.drawerData[path]?.img || this.drawerData['default']?.img;
        if (this.imageWrapper && !this.imageWrapper.style.length) {
            this.imageWrapper.removeAttribute('style');
        }
        this.revealImage(img);
    };
    isExpertiseLink = (link)=>{
        return link.tagName === 'BUTTON';
    };
}


/***/ }),

/***/ "./src/Blocks/components/text-animation/assets/text-animation-handling.js":
/*!********************************************************************************!*\
  !*** ./src/Blocks/components/text-animation/assets/text-animation-handling.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   setIndexToChildren: () => (/* binding */ setIndexToChildren),
/* harmony export */   setNumberOfChildrenVariable: () => (/* binding */ setNumberOfChildrenVariable)
/* harmony export */ });
const setNumberOfChildrenVariable = (element, children, childrenNumberVariableIdentifier = 'number-of-children')=>{
    element?.style.setProperty(`--${childrenNumberVariableIdentifier}`, children.length);
};
const setIndexToChildren = (children, childIndexVariableIdentifier = 'child-index')=>{
    [
        ...children
    ].forEach((child, index)=>{
        child.style.setProperty(`--${childIndexVariableIdentifier}`, index);
    });
};


/***/ })

}]);
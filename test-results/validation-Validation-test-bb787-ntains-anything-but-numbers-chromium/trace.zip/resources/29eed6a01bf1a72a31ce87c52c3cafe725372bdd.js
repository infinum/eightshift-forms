"use strict";
(self["webpackChunk_eightshift_redesign"] = self["webpackChunk_eightshift_redesign"] || []).push([["src_Blocks_components_drawer_assets_drawerOpenClose_js"],{

/***/ "./src/Blocks/components/drawer/assets/drawerOpenClose.js":
/*!****************************************************************!*\
  !*** ./src/Blocks/components/drawer/assets/drawerOpenClose.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DrawerOpenClose: () => (/* binding */ DrawerOpenClose)
/* harmony export */ });
/* harmony import */ var _text_animation_assets_text_animation_handling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../text-animation/assets/text-animation-handling */ "./src/Blocks/components/text-animation/assets/text-animation-handling.js");

class DrawerOpenClose {
    constructor({ drawer, itemsSelector, socialItemsSelector, CLASS_IS_OPEN, CLASS_IS_OPENING, CLASS_DRAWER_IS_OPEN }){
        this.CLASS_IS_OPEN = CLASS_IS_OPEN;
        this.CLASS_DRAWER_IS_OPEN = CLASS_DRAWER_IS_OPEN;
        this.CLASS_IS_OPENING = CLASS_IS_OPENING;
        this.drawer = drawer;
        this.trigger = document.querySelector(`.${this.drawer.getAttribute('data-trigger')}`);
        this.menuItems = this.drawer.querySelectorAll(itemsSelector);
        this.socialItems = this.drawer.querySelectorAll(socialItemsSelector);
        this.monkeyLock = false;
        // Get all links with potential anchor behavior.
        this.relativeLinks = this.drawer.querySelectorAll('[href*="#"]');
        this.pageScrollY = 0;
        this.CLASS_IS_HOVER = 'is-hover';
        this.ANIMATION_DURATION = 500;
        this.ANIMATION_DELAY_OPENING = 300;
        this.ANIMATION_DELAY_CLOSING = 200;
    }
    init = ()=>{
        this.trigger.addEventListener('click', this.handleTriggerClick);
        window.addEventListener('closeMenu', this.closeMenu);
        [
            ...this.relativeLinks
        ].forEach((anchorLink)=>{
            anchorLink.addEventListener('click', this.closeMenu);
        });
        (0,_text_animation_assets_text_animation_handling__WEBPACK_IMPORTED_MODULE_0__.setIndexToChildren)(this.menuItems);
        (0,_text_animation_assets_text_animation_handling__WEBPACK_IMPORTED_MODULE_0__.setIndexToChildren)(this.socialItems);
    };
    handleTriggerClick = ()=>{
        if (!this.monkeyLock) {
            this.monkeyLock = true;
            setTimeout(()=>{
                this.monkeyLock = false;
            }, this.ANIMATION_DURATION);
            this.toggleMenu();
        }
    };
    toggleMenu = ()=>{
        if (document.body.classList.contains(this.CLASS_IS_OPEN)) {
            this.closeMenu();
        } else {
            this.openMenu();
        }
    };
    openMenu = ()=>{
        document.body.classList.add(this.CLASS_IS_OPENING);
        setTimeout(()=>{
            document.body.classList.add(this.CLASS_IS_OPEN);
            this.disableScroll();
        }, this.ANIMATION_DELAY_OPENING);
        const centerLinks = document.querySelectorAll('.js-header-navigation-center a, .js-header-navigation-center .js-menu-dropdown-main-link');
        [
            ...centerLinks
        ].forEach((link)=>{
            link.tabIndex = -1;
        });
    };
    closeMenu = ()=>{
        this.enableScroll();
        document.body.classList.remove(this.CLASS_IS_OPEN);
        setTimeout(()=>{
            document.body.classList.remove(this.CLASS_IS_OPENING);
        }, this.ANIMATION_DELAY_CLOSING);
        const centerLinks = document.querySelectorAll('.js-header-navigation-center a, .js-header-navigation-center .js-menu-dropdown-main-link');
        [
            ...centerLinks
        ].forEach((link)=>{
            link.tabIndex = 0;
        });
        this.hideExpertiseLinks();
    };
    hideExpertiseLinks() {
        const link = this.drawer.querySelector('.js-menu-accordion-main-link');
        link.nextElementSibling.ariaHidden = true;
        link.ariaExpanded = false;
        link.parentElement.classList.remove(this.CLASS_IS_HOVER);
    }
    disableScroll = ()=>{
        this.pageScrollY = window.scrollY;
        setTimeout(()=>{
            document.body.classList.add(this.CLASS_DRAWER_IS_OPEN);
        }, this.ANIMATION_DELAY_OPENING);
    };
    enableScroll = ()=>{
        document.body.classList.remove(this.CLASS_DRAWER_IS_OPEN);
        window.scrollTo(0, parseInt(this.pageScrollY || '0', 10));
        const enableScrollEvent = new CustomEvent('scrollEnabled');
        window.dispatchEvent(enableScrollEvent);
    };
}


/***/ }),

/***/ "./src/Blocks/components/text-animation/assets/text-animation-handling.js":
/*!********************************************************************************!*\
  !*** ./src/Blocks/components/text-animation/assets/text-animation-handling.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   setIndexToChildren: () => (/* binding */ setIndexToChildren),
/* harmony export */   setNumberOfChildrenVariable: () => (/* binding */ setNumberOfChildrenVariable)
/* harmony export */ });
const setNumberOfChildrenVariable = (element, children, childrenNumberVariableIdentifier = 'number-of-children')=>{
    element?.style.setProperty(`--${childrenNumberVariableIdentifier}`, children.length);
};
const setIndexToChildren = (children, childIndexVariableIdentifier = 'child-index')=>{
    [
        ...children
    ].forEach((child, index)=>{
        child.style.setProperty(`--${childIndexVariableIdentifier}`, index);
    });
};


/***/ })

}]);
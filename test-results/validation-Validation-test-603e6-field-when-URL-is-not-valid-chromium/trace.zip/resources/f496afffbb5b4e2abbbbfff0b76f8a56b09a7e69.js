"use strict";
(self["webpackChunk_eightshift_redesign"] = self["webpackChunk_eightshift_redesign"] || []).push([["src_Blocks_components_eightshift-forms_assets_form_js"],{

/***/ "./src/Blocks/components/eightshift-forms/assets/form.js":
/*!***************************************************************!*\
  !*** ./src/Blocks/components/eightshift-forms/assets/form.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Forms: () => (/* binding */ Forms)
/* harmony export */ });
class Forms {
    /**
	 * Init all actions.
	 *
	 * @returns {void}
	 */ init() {
        window.addEventListener('esFormsGoToPrevStep', this.onPrevStepAction);
        window.addEventListener('esFormsGoToNextStep', this.onNextStepAction);
    }
    /**
	 * Get the full flow of the form.
	 *
	 * @param {Object} esForms - The esForms object.
	 * @param {string} formId - The form id.
	 *
	 * @returns {string}
	 */ getFlow(esForms, formId) {
        const flow = esForms?.store?.getStateFormStepsFlow(formId) || [];
        const currentStep = esForms?.store?.getStateFormStepsCurrent(formId) || '';
        return [
            ...flow,
            currentStep
        ]?.join(',') || '';
    }
    /**
	 * Get the form identifier.
	 *
	 * @param {Object} esForms - The esForms object.
	 * @param {string} formId - The form id.
	 *
	 * @returns {string}
	 */ getFormIdentifier(esForms, formId) {
        const formCustomName = esForms?.store?.getStateFormCustomName(formId) || '';
        const formFId = esForms?.store?.getStateFormFid(formId) || '';
        return formCustomName || formFId || `form-${location.pathname}`;
    }
    //////////////////////////////////////
    // Events callbacks.
    //////////////////////////////////////
    /**
	 * Go to the next step.
	 *
	 * @returns {void}
	 */ onNextStepAction = ({ detail: { esForms, formId } })=>{
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({
            event: 'stepChange',
            formName: this.getFormIdentifier(esForms, formId),
            formStepsFlow: this.getFlow(esForms, formId),
            formStep: 'next'
        });
    };
    /**
	 * Go to the previous step.
	 *
	 * @returns {void}
	 */ onPrevStepAction = ({ detail: { esForms, formId } })=>{
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({
            event: 'stepChange',
            formName: this.getFormIdentifier(esForms, formId),
            formStepsFlow: this.getFlow(esForms, formId),
            formStep: 'prev'
        });
    };
}


/***/ })

}]);
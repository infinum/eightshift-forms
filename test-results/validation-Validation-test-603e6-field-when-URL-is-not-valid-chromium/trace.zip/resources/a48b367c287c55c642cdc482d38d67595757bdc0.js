"use strict";
(self["webpackChunk_eightshift_redesign"] = self["webpackChunk_eightshift_redesign"] || []).push([["src_Blocks_components_typography_assets_typography_js"],{

/***/ "./src/Blocks/components/typography/assets/typography.js":
/*!***************************************************************!*\
  !*** ./src/Blocks/components/typography/assets/typography.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Typography: () => (/* binding */ Typography)
/* harmony export */ });
class Typography {
    init() {
        this.initA11yBr();
    }
    initA11yBr() {
        document.querySelectorAll('br').forEach((element)=>{
            element.ariaHidden = true;
        });
    }
}


/***/ })

}]);
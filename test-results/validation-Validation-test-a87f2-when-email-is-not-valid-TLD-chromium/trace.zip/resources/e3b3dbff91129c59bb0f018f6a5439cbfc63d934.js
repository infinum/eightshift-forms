"use strict";
(self["webpackChunk_eightshift_redesign"] = self["webpackChunk_eightshift_redesign"] || []).push([["src_Blocks_components_menu-dropdown_assets_menu-dropdown_js"],{

/***/ "./src/Blocks/components/menu-dropdown/assets/menu-dropdown.js":
/*!*********************************************************************!*\
  !*** ./src/Blocks/components/menu-dropdown/assets/menu-dropdown.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MenuDropdown: () => (/* binding */ MenuDropdown)
/* harmony export */ });
/* harmony import */ var _text_animation_assets_text_animation_handling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../text-animation/assets/text-animation-handling */ "./src/Blocks/components/text-animation/assets/text-animation-handling.js");

class MenuDropdown {
    constructor(options){
        this.container = options.container;
        this.containerSelector = options.componentJsClass;
        this.menuDropdownMainSelector = options.menuDropdownMainSelector;
        this.menuDropdownAdditionalSelector = options.menuDropdownAdditionalSelector;
        this.menuDropdownItemSelector = options.menuDropdownItemSelector;
        this.additionalMenuItems = this.container.querySelectorAll(`${this.menuDropdownAdditionalSelector} ${this.menuDropdownItemSelector}`);
        this.mainMenuItems = this.container.querySelectorAll(`.menu__link`);
        this.CLASS_IS_OPEN = options.CLASS_IS_OPEN;
        this.CLASS_IS_OPENING = options.CLASS_IS_OPENING;
        this.CLASS_IS_CLOSING = options.CLASS_IS_CLOSING;
        this.CLASS_IS_CLOSED = options.CLASS_IS_CLOSED;
        this.trigger = this.container.querySelector(`.${this.containerSelector}-main-link`);
        this.lock = false;
        this.ANIMATION_DELAY_CLOSING = 550;
        this.ANIMATION_DELAY_OPENING = 550;
        this.menuItemSelector = options.menuItemSelector;
        this.menuItemIsActiveSelector = options.menuItemIsActiveSelector;
    }
    init() {
        document.body.classList.add(this.CLASS_IS_CLOSED);
        (0,_text_animation_assets_text_animation_handling__WEBPACK_IMPORTED_MODULE_0__.setIndexToChildren)(this.mainMenuItems);
        this.setMenuItemsCount();
        this.removeTabIndex();
        this.checkActiveMenuItem();
        this.trigger.addEventListener('mouseenter', this.onOpen);
        window.addEventListener('scroll', this.onClose);
        this.container.addEventListener('mouseleave', this.onClose);
        this.trigger.addEventListener('keydown', this.onToggle);
    }
    checkActiveMenuItem = ()=>{
        const menuItems = this.container.querySelectorAll(`.${this.menuItemSelector}`);
        const isActiveItemPresent = Array.from(menuItems).some((item)=>item.classList.contains(this.menuItemIsActiveSelector));
        if (isActiveItemPresent) {
            this.container.classList.add('is-active-parent');
        }
    };
    onOpen = ()=>{
        if (this.lock) {
            return;
        }
        this.openDropdown();
        this.addTabIndex();
    };
    onToggle = (e)=>{
        if (e.key === 'Enter' || e.key === ' ') {
            e.stopPropagation();
            if (this.lock) {
                return;
            }
            if (document.body.classList.contains(this.CLASS_IS_OPEN)) {
                this.onClose();
            } else {
                this.onOpen();
            }
        }
    };
    onClose = ()=>{
        if (this.lock) {
            return;
        }
        this.closeDropdown();
        this.removeTabIndex();
    };
    openDropdown = ()=>{
        this.lock = true;
        document.body.classList.add(this.CLASS_IS_OPENING);
        document.body.classList.remove(this.CLASS_IS_CLOSED);
        setTimeout(()=>{
            document.body.classList.add(this.CLASS_IS_OPEN);
            this.lock = false;
        }, this.ANIMATION_DELAY_OPENING);
    };
    closeDropdown = ()=>{
        this.lock = true;
        document.body.classList.remove(this.CLASS_IS_OPEN);
        document.body.classList.add(this.CLASS_IS_CLOSING);
        setTimeout(()=>{
            document.body.classList.remove(this.CLASS_IS_OPENING);
            document.body.classList.remove(this.CLASS_IS_CLOSING);
            document.body.classList.add(this.CLASS_IS_CLOSED);
            this.lock = false;
        }, this.ANIMATION_DELAY_CLOSING);
    };
    setMenuItemsCount = ()=>{
        const totalMainItems = this.mainMenuItems.length;
        document.querySelector(this.menuDropdownMainSelector).style.setProperty('--total-items', totalMainItems);
    };
    removeTabIndex = ()=>{
        this.setTabIndexForItems(this.mainMenuItems, -1);
    };
    addTabIndex = ()=>{
        this.setTabIndexForItems(this.mainMenuItems, 0);
    };
    setTabIndexForItems = (menuItems, value)=>{
        menuItems.forEach((item)=>{
            item.tabIndex = value;
        });
    };
}


/***/ }),

/***/ "./src/Blocks/components/text-animation/assets/text-animation-handling.js":
/*!********************************************************************************!*\
  !*** ./src/Blocks/components/text-animation/assets/text-animation-handling.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   setIndexToChildren: () => (/* binding */ setIndexToChildren),
/* harmony export */   setNumberOfChildrenVariable: () => (/* binding */ setNumberOfChildrenVariable)
/* harmony export */ });
const setNumberOfChildrenVariable = (element, children, childrenNumberVariableIdentifier = 'number-of-children')=>{
    element?.style.setProperty(`--${childrenNumberVariableIdentifier}`, children.length);
};
const setIndexToChildren = (children, childIndexVariableIdentifier = 'child-index')=>{
    [
        ...children
    ].forEach((child, index)=>{
        child.style.setProperty(`--${childIndexVariableIdentifier}`, index);
    });
};


/***/ })

}]);
"use strict";
(self["webpackChunk_eightshift_redesign"] = self["webpackChunk_eightshift_redesign"] || []).push([["src_Blocks_components_gdpr-modal_assets_gdpr-modal_js"],{

/***/ "./node_modules/@eightshift/frontend-libs/scripts/helpers/cookies.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@eightshift/frontend-libs/scripts/helpers/cookies.js ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cookies: () => (/* binding */ cookies)
/* harmony export */ });
/**
 * Helper to set and unset cookies.
 */ const cookies = {
    /**
	 * Set a cookie value
	 *
	 * @param {string} key   - Unique cookie key.
	 * @param {string} value - Cookie value.
	 * @param {number} time  - Number denoting the expiration of the cookie.
	 * @param {string} path  - URL path that must exist in the requested URL in order to send the Cookie header.
	 * @param {string} domain  - Domain name of the server that set the cookie.
	 * @param {boolean} secure - A secure cookie is only sent to the server with an encrypted request over the HTTPS protocol.
	 * @param {string} sameSite - A SameSite cookie prevents the browser from sending this cookie along with cross-site requests
	 *
	 * @access public
	 *
	 * @returns {boolean}
	 *
	 * Usage:
	 * ```js
	 * cookies.setCookie('gdpr', '2', cookies.setOneDay(), '/', '.example.com', true, 'Strict');
	 * ```
	 */ setCookie (key, value, time, path, domain, secure = true, sameSite = 'Lax') {
        const expires = new Date();
        expires.setTime(expires.getTime() + time);
        const cookieParts = {
            value: `${key}=${value}`,
            expires: `expires=${expires.toUTCString()}`,
            sameSite: `SameSite=${sameSite}`,
            path: path ? `path=${path}` : '',
            domain: domain ? `domain=${domain}` : '',
            secure: secure ? 'Secure' : ''
        };
        try {
            document.cookie = Object.values(cookieParts).filter(Boolean).join('; ');
            return true;
        } catch (e) {
            console.error('Failed to set cookie:', e);
            return false;
        }
    },
    /**
	 * Get a cookie
	 *
	 * @param {string} key Unique cookie key.
	 *
	 * @return Cookie value or null if the cookie doesn't exist.
	 *
	 * Usage:
	 * ```js
	 * cookies.getCookie('gdpr');
	 * ```
	 */ getCookie (key) {
        const keyValue = document.cookie.match(`(^|;) ?${key}=([^;]*)(;|$)`);
        return keyValue ? keyValue[2] : null;
    },
    setHalfDay () {
        return 43200000;
    },
    setOneDay () {
        return 86400000;
    },
    setOneYear () {
        return 31540000000;
    },
    setHalfAnHour () {
        return 1800000;
    },
    setOneMonth () {
        return 2628000000;
    }
};


/***/ }),

/***/ "./src/Blocks/components/gdpr-modal/assets/gdpr-modal.js":
/*!***************************************************************!*\
  !*** ./src/Blocks/components/gdpr-modal/assets/gdpr-modal.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GdprModal: () => (/* binding */ GdprModal)
/* harmony export */ });
/* harmony import */ var _eightshift_frontend_libs_scripts_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @eightshift/frontend-libs/scripts/helpers */ "./node_modules/@eightshift/frontend-libs/scripts/helpers/cookies.js");

class GdprModal {
    constructor({ modalId, modalSelector, btnSelector, btnPredefinedSelector, showAdvanceSelector, advancedToggleSelector, screenBasicSelector, screenAdvancedSelector, cookieExpirePeriod = _eightshift_frontend_libs_scripts_helpers__WEBPACK_IMPORTED_MODULE_0__.cookies.setOneYear(), BODY_ACTIVE_CLASS = 'is-gdpr-modal-active', BODY_ADVANCED_ACTIVE_CLASS = 'is-gdpr-modal-active', ACTIVE_CLASS = 'is-active', HIDDEN_CLASS = 'is-hidden', ADVANCED_OPEN = 'is-advanced-open', ON_CHANGE_GDPR_EVENT = 'changedGdprLevel' }){
        // Selectors and classes.
        this.modalId = modalId;
        this.modalSelector = modalSelector;
        this.screenBasicSelector = screenBasicSelector;
        this.screenAdvancedSelector = screenAdvancedSelector;
        // State Classes.
        this.BODY_ACTIVE_CLASS = BODY_ACTIVE_CLASS;
        this.BODY_ADVANCED_ACTIVE_CLASS = BODY_ADVANCED_ACTIVE_CLASS;
        this.ACTIVE_CLASS = ACTIVE_CLASS;
        this.HIDDEN_CLASS = HIDDEN_CLASS;
        this.ADVANCED_OPEN = ADVANCED_OPEN;
        this.gdprCookieLevels = {
            required: true
        };
        // Elements.
        this.modalElement = document.querySelector(this.modalSelector);
        if (!this.modalElement) {
            return;
        }
        this.dateOfPublishing = this.modalElement?.dataset?.publishDate;
        this.showAdvanceElement = this.modalElement.querySelector(showAdvanceSelector);
        this.advancedToggles = this.modalElement.querySelectorAll(advancedToggleSelector);
        this.btnElements = this.modalElement.querySelectorAll(btnSelector);
        this.btnPredefinedElements = this.modalElement.querySelectorAll(btnPredefinedSelector);
        this.openModalLinkElements = document.querySelectorAll(`a[href="#${this.modalId}-modal"]`);
        // Body element.
        this.body = document.querySelector('body');
        // Initial cookie level and settings.
        if (!this.advancedToggles.length) {
            return;
        }
        [
            ...this.advancedToggles
        ].forEach((toggle)=>{
            if (toggle) {
                this.gdprCookieLevels[toggle.value] = toggle?.checked;
            }
        });
        this.acceptedGdprCookieValue = 'required';
        this.cookieExpirePeriod = cookieExpirePeriod;
        this.ON_CHANGE_GDPR_EVENT = ON_CHANGE_GDPR_EVENT;
        this.IS_MODAL_OPEN_CLICKED = false;
    }
    // Initializing the GDPR modal.
    init() {
        const currentGdprCookieLevel = _eightshift_frontend_libs_scripts_helpers__WEBPACK_IMPORTED_MODULE_0__.cookies.getCookie(this.modalId);
        const gdprCookieAcceptDate = _eightshift_frontend_libs_scripts_helpers__WEBPACK_IMPORTED_MODULE_0__.cookies.getCookie(`${this.modalId}-accept-date`);
        const openingCondition = // If GDPR cookie is not defined AND It is a previous definition (0-2) of gdpr cookie or current one.
        !currentGdprCookieLevel?.includes('required') || // If accept date cookie is not set.
        !gdprCookieAcceptDate || // Date of acceptance was before publishing privacy policy in GMT.
        new Date(`${gdprCookieAcceptDate} GMT`) < new Date(this.dateOfPublishing);
        this.acceptedGdprCookieValue = currentGdprCookieLevel || this.acceptedGdprCookieValue;
        const eventDetail = {
            isOpen: false
        };
        if (openingCondition) {
            this.open();
            this.setListeners();
            eventDetail.isOpen = true;
        }
        this.setListeners();
        const event = new CustomEvent('gdprModalIsOpen', {
            detail: eventDetail
        });
        window.dispatchEvent(event);
    }
    // Get the value from toggles.
    getToggles() {
        [
            ...this.advancedToggles
        ].forEach((toggle)=>{
            if (toggle) {
                this.gdprCookieLevels[toggle.value] = toggle?.checked;
            }
        });
    }
    // Handling basic opening/closing of modal and setting GDPR level.
    open = (onlyAdvanced = false)=>{
        this.modalElement.classList.remove(this.HIDDEN_CLASS);
        setTimeout(()=>{
            this.modalElement.classList.add(this.ACTIVE_CLASS);
            this.modalElement.setAttribute('aria-hidden', 'false');
            this.body.classList.add(this.BODY_ACTIVE_CLASS);
            if (onlyAdvanced) {
                this.showAdvanceContent();
                this.modalElement.querySelector(`${this.screenAdvancedSelector} button`).focus();
            } else {
                this.modalElement.querySelector(`${this.screenBasicSelector} button`).focus();
            }
        }, 300);
    };
    close = (gdprValue = this.onSetGdprValue())=>{
        this.setGdprCookie(gdprValue);
        this.body.classList.remove(this.BODY_ACTIVE_CLASS);
        this.body.classList.remove(this.BODY_ADVANCED_ACTIVE_CLASS);
        this.modalElement.classList.remove(this.ACTIVE_CLASS);
        this.modalElement.setAttribute('aria-hidden', 'true');
        setTimeout(()=>{
            this.modalElement.classList.remove(this.ADVANCED_OPEN);
        }, 0);
        setTimeout(()=>{
            this.modalElement.classList.add(this.HIDDEN_CLASS);
        }, 300);
        const event = new CustomEvent('gdprModalClosed', {
            detail: {
                isOpen: false
            }
        });
        window.dispatchEvent(event);
        if (this.IS_MODAL_OPEN_CLICKED) {
            document.querySelector(`a[href="#${this.modalId}-modal"]`)?.focus();
            this.IS_MODAL_OPEN_CLICKED = false;
        }
    };
    // Setting GDPR level to Cookies, notifying GTM that event has occurred.
    setGdprCookie = (currentLevel)=>{
        const date = new Date().toUTCString();
        _eightshift_frontend_libs_scripts_helpers__WEBPACK_IMPORTED_MODULE_0__.cookies.setCookie(this.modalId, currentLevel, this.cookieExpirePeriod, '/');
        _eightshift_frontend_libs_scripts_helpers__WEBPACK_IMPORTED_MODULE_0__.cookies.setCookie(`${this.modalId}-accept-date`, date, this.cookieExpirePeriod, '/');
        if (window.dataLayer) {
            window.dataLayer.push({
                event: this.ON_CHANGE_GDPR_EVENT
            });
        }
        const initialCookieLevel = this.acceptedGdprCookieValue;
        this.acceptedGdprCookieValue = currentLevel;
        // If cookie new cookie level includes all the previous levels no need to reload.
        if (initialCookieLevel.split(',').filter((initLevel)=>!currentLevel.includes(initLevel)).length) {
            location.reload();
        }
    };
    // Opening/closing advanced modal.
    onShowAdvanceContent = (e)=>{
        e.preventDefault();
        this.showAdvanceContent();
    };
    showAdvanceContent = ()=>{
        this.modalElement.classList.add(this.ADVANCED_OPEN);
        this.body.classList.add(this.BODY_ADVANCED_ACTIVE_CLASS);
    };
    // Transform an object to a string with GDPR value.
    onSetGdprValue = ()=>{
        return Object.entries(this.gdprCookieLevels)?.filter(([_, value])=>value)?.map(([key])=>key)?.join(',');
    };
    // When clicked on predefined values.
    onButtonPredefinedClick = (e)=>{
        e.preventDefault();
        this.close(e.target?.dataset.level || 'required');
    };
    // When clicked on accept button.
    onButtonClick = (e)=>{
        e.preventDefault();
        this.getToggles();
        this.close();
    };
    // Opening modal from link.
    openOnLinkModal = (e)=>{
        this.IS_MODAL_OPEN_CLICKED = true;
        e.preventDefault();
        this.open(true);
    };
    // Setting and removing listeners from all the elements.
    setListeners() {
        // On advance options button click.
        this.showAdvanceElement?.addEventListener('click', this.onShowAdvanceContent);
        // When user accepts cookie level.
        this.btnElements?.forEach((btnElement)=>{
            btnElement?.addEventListener('click', this.onButtonClick);
        });
        this.btnPredefinedElements?.forEach((btnPredefinedElement)=>{
            btnPredefinedElement?.addEventListener('click', this.onButtonPredefinedClick);
        });
        // On url open modal.
        [
            ...this.openModalLinkElements
        ]?.forEach((modalLink)=>{
            modalLink?.addEventListener('click', this.openOnLinkModal);
        });
    }
}


/***/ })

}]);
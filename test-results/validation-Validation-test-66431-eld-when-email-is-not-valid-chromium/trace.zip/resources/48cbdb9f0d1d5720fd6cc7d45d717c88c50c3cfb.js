var EightshiftForms;
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/@eightshift/frontend-libs/scripts/helpers/cookies.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@eightshift/frontend-libs/scripts/helpers/cookies.js ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cookies: () => (/* binding */ cookies)
/* harmony export */ });
/**
 * Helper to set and unset cookies.
 */ const cookies = {
    /**
	 * Set a cookie value
	 *
	 * @param {string} key   - Unique cookie key.
	 * @param {string} value - Cookie value.
	 * @param {number} time  - Number denoting the expiration of the cookie.
	 * @param {string} path  - URL path that must exist in the requested URL in order to send the Cookie header.
	 *
	 * @access public
	 *
	 * @returns {void}
	 *
	 * Usage:
	 * ```js
	 * cookies.setCookie('gdpr', '2', cookies.setOneDay(), '/');
	 * ```
	 */ setCookie (key, value, time, path, domain) {
        const expires = new Date();
        expires.setTime(expires.getTime() + time);
        let pathValue = '';
        let domainValue = '';
        if (typeof path !== 'undefined') {
            pathValue = `;path=${path}`;
        }
        if (typeof domain !== 'undefined') {
            domainValue = `;domain=${domain}`;
        }
        document.cookie = `${key}=${value}${pathValue}${domainValue};expires=${expires.toUTCString()}`;
    },
    /**
	 * Get a cookie
	 *
	 * @param {string} key Unique cookie key.
	 *
	 * @return Cookie value or null if the cookie doesn't exist.
	 *
	 * Usage:
	 * ```js
	 * cookies.getCookie('gdpr');
	 * ```
	 */ getCookie (key) {
        const keyValue = document.cookie.match(`(^|;) ?${key}=([^;]*)(;|$)`);
        return keyValue ? keyValue[2] : null;
    },
    setHalfDay () {
        return 43200000;
    },
    setOneDay () {
        return 86400000;
    },
    setOneYear () {
        return 31540000000;
    },
    setHalfAnHour () {
        return 1800000;
    },
    setOneMonth () {
        return 2628000000;
    }
};


/***/ }),

/***/ "./node_modules/@eightshift/frontend-libs/scripts/helpers/dynamic-import.js":
/*!**********************************************************************************!*\
  !*** ./node_modules/@eightshift/frontend-libs/scripts/helpers/dynamic-import.js ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   dynamicImport: () => (/* binding */ dynamicImport)
/* harmony export */ });
/**
 * Loop all paths required using require.context method.
 * Used to get (require) all the files using the `require.context` method.
 * It will find all files recursively in the folder using a regex.
 *
 * @param {object} paths - All `require.context` paths to iterate.
 *
 * @access public
 *
 * @returns {void}
 *
 * Usage:
 * ```js
 * dynamicImport(require.context('./../../custom', true, /assets\/index.js$/));
 * ```
 */ function dynamicImport(paths) {
    paths.keys().forEach(paths);
}


/***/ }),

/***/ "./node_modules/@eightshift/ui-components/dist/utilities/es-dash.js":
/*!**************************************************************************!*\
  !*** ./node_modules/@eightshift/ui-components/dist/utilities/es-dash.js ***!
  \**************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   camelCase: () => (/* binding */ camelCase),
/* harmony export */   has: () => (/* binding */ has),
/* harmony export */   isEmpty: () => (/* binding */ isEmpty),
/* harmony export */   isEqual: () => (/* binding */ isEqual),
/* harmony export */   isObject: () => (/* binding */ isObject),
/* harmony export */   isPlainObject: () => (/* binding */ isPlainObject),
/* harmony export */   isString: () => (/* binding */ isString),
/* harmony export */   kebabCase: () => (/* binding */ kebabCase),
/* harmony export */   lowerFirst: () => (/* binding */ lowerFirst),
/* harmony export */   pascalCase: () => (/* binding */ pascalCase),
/* harmony export */   snakeCase: () => (/* binding */ snakeCase),
/* harmony export */   upperFirst: () => (/* binding */ upperFirst)
/* harmony export */ });
var stringKebabCase = kebabCase$1;
var wordSeparators = /[\s\u2000-\u206F\u2E00-\u2E7F\\'!"#$%&()*+,\-.\/:;<=>?@\[\]^_`{|}~]+/;
var capital_plus_lower = /[A-ZÀ-Ý\u00C0-\u00D6\u00D9-\u00DD][a-zà-ÿ]/g;
var capitals = /[A-ZÀ-Ý\u00C0-\u00D6\u00D9-\u00DD]+/g;
function kebabCase$1(str) {
    str = str.replace(capital_plus_lower, function(match) {
        return " " + (match[0].toLowerCase() || match[0]) + match[1];
    });
    str = str.replace(capitals, function(match) {
        return " " + match.toLowerCase();
    });
    return str.trim().split(wordSeparators).join("-").replace(/^-/, "").replace(/-\s*$/, "");
}
var stringCamelCase = camelCase$1;
var wordSeparatorsRegEx = /[\s\u2000-\u206F\u2E00-\u2E7F\\'!"#$%&()*+,\-.\/:;<=>?@\[\]^_`{|}~]+/;
var basicCamelRegEx = /^[a-z\u00E0-\u00FCA-Z\u00C0-\u00DC][\d|a-z\u00E0-\u00FCA-Z\u00C0-\u00DC]*$/;
var fourOrMoreConsecutiveCapsRegEx = /([A-Z\u00C0-\u00DC]{4,})/g;
var allCapsRegEx = /^[A-Z\u00C0-\u00DC]+$/;
function camelCase$1(str) {
    var words = str.split(wordSeparatorsRegEx);
    var len = words.length;
    var mappedWords = new Array(len);
    for(var i = 0; i < len; i++){
        var word = words[i];
        if (word === "") {
            continue;
        }
        var isCamelCase = basicCamelRegEx.test(word) && !allCapsRegEx.test(word);
        if (isCamelCase) {
            word = word.replace(fourOrMoreConsecutiveCapsRegEx, function(match, p1, offset) {
                return deCap(match, word.length - offset - match.length == 0);
            });
        }
        var firstLetter = word[0];
        firstLetter = i > 0 ? firstLetter.toUpperCase() : firstLetter.toLowerCase();
        mappedWords[i] = firstLetter + (!isCamelCase ? word.slice(1).toLowerCase() : word.slice(1));
    }
    return mappedWords.join("");
}
function deCap(match, endOfWord) {
    var arr = match.split("");
    var first = arr.shift().toUpperCase();
    var last = endOfWord ? arr.pop().toLowerCase() : arr.pop();
    return first + arr.join("").toLowerCase() + last;
}
var objectIsEmpty = isEmpty$1;
function isEmpty$1(obj) {
    if (obj == null) {
        return true;
    }
    if (Array.isArray(obj)) {
        return !obj.length;
    }
    if (typeof obj == "string") {
        return !obj.length;
    }
    var type = ({}).toString.call(obj);
    if (type == "[object Object]") {
        return !Object.keys(obj).length && !Object.getOwnPropertySymbols(obj).length;
    }
    if (type == "[object Map]" || type == "[object Set]") {
        return !obj.size;
    }
    return Object(obj) !== obj || !Object.keys(obj).length;
}
var objectHas = has$1;
function has$1(obj, propsArg) {
    if (!obj) {
        return false;
    }
    var props, prop;
    if (Array.isArray(propsArg)) {
        props = propsArg.slice(0);
    }
    if (typeof propsArg == "string") {
        props = propsArg.split(".");
    }
    if (typeof propsArg == "symbol") {
        props = [
            propsArg
        ];
    }
    if (!Array.isArray(props)) {
        throw new Error("props arg must be an array, a string or a symbol");
    }
    while(props.length){
        prop = props.shift();
        if (obj == null) {
            return false;
        }
        if (!Object.prototype.hasOwnProperty.call(obj, prop)) {
            return false;
        }
        if (props.length === 0) {
            return true;
        }
        obj = obj[prop];
    }
    return false;
}
/**
 * Returns a camelCase-formatted string.
 *
 * @param {string} input - String to convert.
 *
 * @access public
 *
 * @return {string} *camelCase*-formatted string.
 *
 * @example
 * camelCase('New super Test-title') // => 'newSuperTestTitle'
 * camelCase(null) // => ''
 *
 * @preserve
 */ const camelCase = (input)=>lowerFirst(stringCamelCase(input ?? ""));
/**
 * Returns a PascalCase-formatted string.
 *
 * @param {string} input - String to convert.
 *
 * @access public
 *
 * @return {string} *PascalCase*-formatted string.
 *
 * Usage:
 * ```js
 * pascalCase('New super Test-title') // => 'NewSuperTestTitle'
 * pascalCase(null) // => ''
 * ```
 *
 * @preserve
 */ const pascalCase = (input)=>upperFirst(stringCamelCase(input ?? ""));
/**
 * Returns a snake_case-formatted string.
 *
 * @param {string} input - String to convert.
 *
 * @access public
 *
 * @return {string} *snake_case*-formatted string.
 *
 * Usage:
 * ```js
 * snakeCase('New super Test-title') // => 'new_super_test_title'
 * snakeCase(null) // => ''
 * ```
 *
 * @preserve
 */ const snakeCase = (input)=>kebabCase(input ?? "").replaceAll("-", "_");
const kebabCase = (input)=>stringKebabCase(input ?? "");
/**
 * Checks if value is an empty object or collection.
 *
 * @param {*} input - Value to check.
 *
 * @returns true if the object is empty, false otherwise.
 *
 * Usage:
 * ```js
 * isEmpty({}) // => true
 * isEmpty([]) // => true
 * isEmpty('') // => true
 * isEmpty({ a: 1 }) // => false
 * isEmpty([1, 2, 3]) // => false
 * ```
 *
 * @preserve
 */ const isEmpty = (input)=>objectIsEmpty(input);
/**
 * Returns the string with its first character converted to uppercase.
 *
 * @param {string} input - String to convert.
 *
 * @return {string} string with its first character converted to uppercase.
 *
 * @example
 * upperFirst('new super Test-title') // => 'New super Test-title'
 *
 * @preserve
 */ const upperFirst = (input)=>{
    if (typeof input === "undefined") {
        return "";
    }
    if (input === true) {
        return "True";
    } else if (input === false) {
        return "False";
    }
    if (typeof input !== "string") {
        input = String(input);
    }
    if (input.length < 2) {
        return input.toUpperCase();
    }
    return input.charAt(0).toUpperCase() + input.slice(1);
};
/**
 * Returns the string with its first character converted to lowercase.
 *
 * @param {string} input - String to convert.
 *
 * @return {string} string with its first character converted to lowercase.
 *
 * @example
 * lowerFirst('New super Test-title') // => 'new super Test-title'
 *
 * @preserve
 */ const lowerFirst = (input)=>{
    if (typeof input === "undefined") {
        return "";
    }
    if (input === true) {
        return "true";
    } else if (input === false) {
        return "false";
    }
    if (typeof input !== "string") {
        input = String(input);
    }
    if (input?.length < 2) {
        return input.toLowerCase();
    }
    return input.charAt(0).toLowerCase() + input.slice(1);
};
/**
 * Checks if `key` is a direct property of `object`. Key may be a path of a value separated by `.`
 *
 * @param {object} obj - Object to check.
 * @param {string} key - Key to check.
 *
 * @return {boolean} true if key is a direct property, false otherwise.
 *
 * Usage:
 * ```js
 * has({ a: 1 }, 'a') // => true
 * has({ a: 1 }, 'b') // => false
 * has({ a: { b: 2 } }, 'a.b') // => true
 * has({ a: { b: 3 } }, 'a.c') // => false
 * ```
 *
 * @preserve
 */ const has = (obj, key)=>objectHas(obj, key);
/*
 * Checks if value is a plain object, that is, an object created by the Object constructor or one with a `[[Prototype]]` of `null`.
 *
 * @param {*} value - Value to check.
 * @returns {boolean} true if value is a plain object, false otherwise.
 *
 * Usage:
 * ```js
 * isPlainObject({ a: 2 }) // => true
 * isPlainObject('Lorem') // => false
 * isPlainObject([]) // => false
 * isPlainObject(new Boolean()) // => false
 * ```
 *
 * @preserve
 */ const isPlainObject = (value)=>{
    if (typeof value !== "object" || value === null) {
        return false;
    }
    if (Object.prototype.toString.call(value) !== "[object Object]") {
        return false;
    }
    const proto = Object.getPrototypeOf(value);
    if (proto === null) {
        return true;
    }
    const Ctor = Object.prototype.hasOwnProperty.call(proto, "constructor") && proto.constructor;
    return typeof Ctor === "function" && Ctor instanceof Ctor && Function.prototype.call(Ctor) === Function.prototype.call(value);
};
/**
 * Checks if value is the language type of `Object`. (e.g. arrays, functions, objects, regexes, new Number(0), and new String(’’))
 *
 * @param {*} input - Value to check.
 *
 * @returns {boolean} true if value is an array, false otherwise.
 *
 * Usage:
 * ```js
 * isObject({}) // => true
 * isObject([1, 2, 3]) // => true
 * isObject(() => {}) // => true
 * isObject(null) // => false
 * ```
 *
 * @preserve
 */ const isObject = (input)=>input instanceof Object;
/**
 * Performs a deep comparison between two values to determine if they are equivalent.
 *
 * **Note**: works for simple types, arrays, and objects. Might not work for all the types the lodash version supports.
 *
 * @param {*} first First value to compare.
 * @param {*} second Second value to compare.
 *
 * @returns true if the values are equivalent, false otherwise.
 *
 * Usage:
 * ```js
 * isEqual({ a: 1 }, { a: 1 }) // => true
 * isEqual({ a: 1 }, { a: 2 }) // => false
 * isEqual({ a: 1 }, 'b') // => false
 * ```
 *
 * @preserve
 */ const isEqual = (first, second)=>{
    if (first === second) {
        return true;
    }
    if ((first === void 0 || second === void 0 || first === null || second === null) && (first || second)) {
        return false;
    }
    const firstType = first?.constructor.name;
    const secondType = second?.constructor.name;
    if (firstType !== secondType) {
        return false;
    }
    if (firstType === "Array") {
        if (first.length !== second.length) {
            return false;
        }
        let equal = true;
        for(let i = 0; i < first.length; i++){
            if (!isEqual(first[i], second[i])) {
                equal = false;
                break;
            }
        }
        return equal;
    }
    if (firstType === "Object") {
        let equal = true;
        const fKeys = Object.keys(first);
        const sKeys = Object.keys(second);
        if (fKeys.length !== sKeys.length) {
            return false;
        }
        for(let i = 0; i < fKeys.length; i++){
            if (first[fKeys[i]] && second[fKeys[i]]) {
                if (first[fKeys[i]] === second[fKeys[i]]) {
                    continue;
                }
                if (first[fKeys[i]] && (first[fKeys[i]].constructor.name === "Array" || first[fKeys[i]].constructor.name === "Object")) {
                    equal = isEqual(first[fKeys[i]], second[fKeys[i]]);
                    if (!equal) {
                        break;
                    }
                } else if (first[fKeys[i]] !== second[fKeys[i]]) {
                    equal = false;
                    break;
                }
            } else if (first[fKeys[i]] && !second[fKeys[i]] || !first[fKeys[i]] && second[fKeys[i]]) {
                equal = false;
                break;
            }
        }
        return equal;
    }
    return first === second;
};
/**
 * Checks if value is the language type of `String`.
 *
 * @param {*} value - Value to check.
 * @returns {boolean} true if value is a string, false otherwise.
 *
 * Usage:
 * ```js
 * isString('Lorem') // => true
 * isString(2) // => false
 * isString([]) // => false
 * isString(new String('Lorem')) // => false
 * ```
 *
 * @preserve
 */ const isString = (value)=>typeof value === "string" || value instanceof String;



/***/ }),

/***/ "./node_modules/@wordpress/dom-ready/build-module/index.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@wordpress/dom-ready/build-module/index.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ domReady)
/* harmony export */ });
/**
 * @typedef {() => void} Callback
 *
 * TODO: Remove this typedef and inline `() => void` type.
 *
 * This typedef is used so that a descriptive type is provided in our
 * automatically generated documentation.
 *
 * An in-line type `() => void` would be preferable, but the generated
 * documentation is `null` in that case.
 *
 * @see https://github.com/WordPress/gutenberg/issues/18045
 */

/**
 * Specify a function to execute when the DOM is fully loaded.
 *
 * @param {Callback} callback A function to execute after the DOM is ready.
 *
 * @example
 * ```js
 * import domReady from '@wordpress/dom-ready';
 *
 * domReady( function() {
 * 	//do something after DOM loads.
 * } );
 * ```
 *
 * @return {void}
 */
function domReady(callback) {
  if (typeof document === 'undefined') {
    return;
  }
  if (document.readyState === 'complete' ||
  // DOMContentLoaded + Images/Styles/etc loaded, so we call directly.
  document.readyState === 'interactive' // DOMContentLoaded fires at this point, so we call directly.
  ) {
    return void callback();
  }

  // DOMContentLoaded has not fired yet, delay callback until then.
  document.addEventListener('DOMContentLoaded', callback);
}
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./src/Blocks/assets/scripts/blocks-frontend.js":
/*!******************************************************!*\
  !*** ./src/Blocks/assets/scripts/blocks-frontend.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _eightshift_frontend_libs_scripts_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @eightshift/frontend-libs/scripts/helpers */ "./node_modules/@eightshift/frontend-libs/scripts/helpers/dynamic-import.js");
/**
 * This is the main entry point for Block Editor blocks scripts used for the `WordPress frontend screen`.
 * This file registers all blocks additional scripts dynamically using `dynamicImport` helper method.
 * File names must follow naming convention to be able run dynamically.
 *
 * `src/blocks/custom/block_name/assets/index.js`.
 *
 * Usage: `WordPress frontend screen`.
 */ 
// Find all blocks and require assets index.js inside it.
(0,_eightshift_frontend_libs_scripts_helpers__WEBPACK_IMPORTED_MODULE_0__.dynamicImport)(__webpack_require__("./src/Blocks/components sync recursive assets\\/index\\.js$"));


/***/ }),

/***/ "./src/Blocks/assets/styles/blocks-frontend.scss":
/*!*******************************************************!*\
  !*** ./src/Blocks/assets/styles/blocks-frontend.scss ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./src/Blocks/components sync recursive assets\\/index\\.js$":
/*!********************************************************!*\
  !*** ./src/Blocks/components/ sync assets\/index\.js$ ***!
  \********************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./form/assets/index.js": "./src/Blocks/components/form/assets/index.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./src/Blocks/components sync recursive assets\\/index\\.js$";

/***/ }),

/***/ "./src/Blocks/components/form/assets/conditional-tags.js":
/*!***************************************************************!*\
  !*** ./src/Blocks/components/form/assets/conditional-tags.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ConditionalTags: () => (/* binding */ ConditionalTags)
/* harmony export */ });
/* harmony import */ var _state_init__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./state-init */ "./src/Blocks/components/form/assets/state-init.js");
/* harmony import */ var _manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../../manifest.json */ "./src/Blocks/manifest.json");


/**
 * Main condition tags class.
 */ class ConditionalTags {
    constructor(utils){
        /** @type {import('./utils').Utils} */ this.utils = utils;
        /** @type {import('./state').State} */ this.state = this.utils.getState();
        // Simplify usage of constants
        this.SHOW = _manifest_json__WEBPACK_IMPORTED_MODULE_1__.comparatorActions.SHOW;
        this.HIDE = _manifest_json__WEBPACK_IMPORTED_MODULE_1__.comparatorActions.HIDE;
        this.OR = _manifest_json__WEBPACK_IMPORTED_MODULE_1__.comparatorLogic.OR;
        this.AND = _manifest_json__WEBPACK_IMPORTED_MODULE_1__.comparatorLogic.AND;
        this.IS = _manifest_json__WEBPACK_IMPORTED_MODULE_1__.comparator.IS;
        this.ISN = _manifest_json__WEBPACK_IMPORTED_MODULE_1__.comparator.ISN;
        this.C = _manifest_json__WEBPACK_IMPORTED_MODULE_1__.comparator.C;
        this.CN = _manifest_json__WEBPACK_IMPORTED_MODULE_1__.comparator.CN;
        // Set all public methods.
        this.publicMethods();
    }
    ////////////////////////////////////////////////////////////////
    // Public methods
    ////////////////////////////////////////////////////////////////
    /**
	 * Init one form by element after the loaded event is fired.
	 *
	 * @param {string} fromId Form Id.
	 *
	 * @returns {void}
	 */ initOne(formId) {
        // Bailout if admin.
        if (this.state.getStateConfigIsAdmin(formId)) {
            return;
        }
        // Listen to every field element change.
        window.addEventListener(this.state.getStateEvent('formJsLoaded'), this.onInitEvent);
    }
    /**
	 * Init forms visibility conditional logic.
	 *
	 * @param {string} fromId Form Id.
	 *
	 * @returns {void}
	 */ initForms(formId) {
        // Get all tags from state.
        let tags = this.state.getStateFormConditionalTagsForm(formId);
        if (!tags) {
            return;
        }
        // Prepare outputs.
        const outputHide = {
            top: [],
            topFinal: [],
            innerParents: [],
            inner: {}
        };
        const outputShow = {
            top: [],
            topFinal: [],
            innerParents: [],
            inner: {}
        };
        // Loop all conditional tags.
        tags.forEach(([tagName, tagVisibility, tagInner])=>{
            // Check if tag is hide state.
            if (tagVisibility === this.HIDE) {
                if (!tagInner) {
                    // Push to top state if no inner items.
                    outputHide.top.push(tagName);
                } else {
                    // Create a new inner state if not existing.
                    if (outputHide?.inner?.[tagName] === undefined) {
                        outputHide.inner[tagName] = [];
                    }
                    // Push to inner state if existing.
                    outputHide.inner[tagName].push(tagInner);
                }
            } else {
                // Check if tag is visible state.
                if (!tagInner) {
                    // Push to top state if no inner items.
                    outputShow.top.push(tagName);
                } else {
                    // Create a new inner state if not existing.
                    if (outputShow?.inner?.[tagName] === undefined) {
                        outputShow.inner[tagName] = [];
                    }
                    // Push to inner state if existing.
                    outputShow.inner[tagName].push(tagInner);
                }
            }
        });
        // Set state for form hide.
        this.state.setState([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS_STATE_FORM_HIDE
        ], outputHide, formId);
        // Set styles for form hide.
        this.setStyles(formId, outputHide, _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS_STATE_FORM_HIDE);
        // Set state for form show.
        this.state.setState([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS_STATE_FORM_SHOW
        ], outputShow, formId);
        // Set styles for form show.
        this.setStyles(formId, outputShow, _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS_STATE_FORM_SHOW);
    }
    /**
	 * Init fields conditional logic.
	 *
	 * @param {string} fromId Form Id.
	 *
	 * @returns {void}
	 */ initFields(formId) {
        // Set all rules for all form fields.
        for (const [name] of this.state.getStateElements(formId)){
            this.setFieldsRulesAll(formId, name);
        }
        // Set all rules for all non-form fields.
        for (const [name] of this.state.getStateElementsFields(formId)){
            this.setFieldsRulesAll(formId, name);
        }
        // Set fields states.
        this.setFields(formId);
    }
    /**
	 * Set field conditional logic on field change.
	 *
	 * @param {string} fromId Form Id.
	 * @param {string} fieldName Field name.
	 *
	 * @returns {void}
	 */ setField(formId, fieldName) {
        // Set all rules for all fields.
        this.setFieldsRulesAll(formId, fieldName);
        // Set fields states.
        this.setFields(formId);
    }
    /**
	 * Set all fields state.
	 *
	 * @param {string} fromId Form Id.
	 *
	 * @returns {void}
	 */ setFields(formId) {
        // Prepare outputs.
        const output = {
            top: [],
            topFinal: [],
            innerParents: [],
            inner: {}
        };
        // Loop all fields.
        for (const [name] of this.state.getStateElements(formId)){
            // Get element type.
            const type = this.state.getStateElementTypeField(name, formId);
            // Only select, checkbox and radio fields can have inner items.
            if (type === 'select' || type === 'checkbox' || type === 'radio') {
                // Prepare inner level outputs.
                let innerOutput = {};
                // Select fields can have multiple or single select inner options.
                if (type === 'select') {
                    innerOutput = this.state.getStateElementConfig(name, _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONFIG_SELECT_USE_MULTIPLE, formId) ? this.getFieldInnerSelectMultiple(formId, name) : this.getFieldInnerSelectSingle(formId, name);
                } else {
                    // Checkbox and radio inner fields.
                    innerOutput = this.getFieldInner(formId, name);
                }
                // Set inner Parents fields state.
                if (innerOutput.innerParents) {
                    output.innerParents.push(name);
                }
                // Set inner fields state.
                if (innerOutput.inner) {
                    output.inner[name] = innerOutput.inner;
                }
            }
            // Set top level fields state.
            const check = this.getFieldTopLevel(formId, name);
            if (check) {
                output.top.push(name);
            }
        }
        // Loop all non-form fields.
        for (const [name] of this.state.getStateElementsFields(formId)){
            // Set top level fields state.
            const check = this.getFieldTopLevel(formId, name, true);
            if (check) {
                output.top.push(name);
            }
        }
        // Set state for conditional tags.
        this.state.setState([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS_STATE_CT
        ], output, formId);
        // Set styles for conditional tags.
        this.setStyles(formId, output, _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS_STATE_CT);
    }
    /**
	 * Set all rules for all fields.
	 *
	 * @param {string} fromId Form Id.
	 * @param {string} fieldName Field name.
	 *
	 * @returns {void}
	 */ setFieldsRulesAll(formId, fieldName) {
        // Check and set top level events and set rules.
        this.state.getStateFormConditionalTagsEvents(formId)?.[fieldName]?.forEach((eventName)=>{
            this.setFieldsRules(formId, eventName);
        });
        // Check and set inner level events and set rules.
        this.state.getStateFormConditionalTagsInnerEvents(formId)?.[fieldName]?.forEach((eventName)=>{
            this.setFieldsRulesInner(formId, eventName);
        });
    }
    /**
	 * Set styles for conditional tags.
	 *
	 * @param {string} fromId Form Id.
	 * @param {object} data Data to set.
	 * @param {string} stateName State name to set.
	 *
	 * @returns {void}
	 */ setStyles(formId, data, stateName) {
        let output = [];
        // Get attributes.
        const fieldNameAttr = this.state.getStateAttribute('fieldName');
        const formIdAttr = this.state.getStateAttribute('formId');
        const formSelector = this.state.getStateSelector('form', true);
        const selectValueAttr = this.state.getStateAttribute('selectValue');
        // New array for top final so we don't mutate the original object.
        const topFinalOutput = [
            ...data.topFinal
        ];
        // Loop all top level items.
        data?.top.forEach((name)=>{
            // Push selector for style output.
            output.push(`${formSelector}[${formIdAttr}="${formId}"] [${fieldNameAttr}="${name}"]`);
            // Push to top final item.
            topFinalOutput.push(name);
        });
        // Loop all inner parents items.
        data?.innerParents.forEach((name)=>{
            // Push selector for style output.
            output.push(`${formSelector}[${formIdAttr}="${formId}"] [${fieldNameAttr}="${name}"]`);
            // If top final item is not already set push it.
            if (!data?.top.includes(name)) {
                // Push to top final item .
                topFinalOutput.push(name);
            }
        });
        // Loop all inner items.
        for (const [fieldName, innerItems] of Object.entries(data?.inner ?? {})){
            // Get correct selector type.
            let selectorType = this.state.getStateElementTypeField(fieldName, formId) === 'select' ? selectValueAttr : fieldNameAttr;
            // Loop all inner items.
            innerItems.forEach((inner)=>{
                // Push selector for style output.
                output.push(`${formSelector}[${formIdAttr}="${formId}"] [${fieldNameAttr}="${fieldName}"] [${selectorType}="${inner}"]`);
            });
        }
        // Set styles to DOM.
        this.outputStyles(formId, output, stateName);
        this.removeActiveFieldsOnHide(formId, data, stateName);
        // Set state for conditional tags.
        this.state.setState([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            stateName
        ], {
            ...data,
            topFinal: [
                ...new Set(topFinalOutput)
            ]
        }, formId);
    }
    /**
	 * Output styles to DOM.
	 *
	 * @param {string} fromId Form Id.
	 * @param {object} data Data to set.
	 * @param {string} stateName State name to set.
	 *
	 * @returns {void}
	 */ outputStyles(formId, data, stateName) {
        // Get form element.
        const form = this.state.getStateFormElement(formId);
        let selector = '';
        let type = '';
        // Set correct selector and type based on state name.
        switch(stateName){
            case _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS_STATE_FORM_HIDE:
                selector = 'forms-hide';
                type = 'none';
                break;
            case _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS_STATE_FORM_SHOW:
                selector = 'forms-show';
                type = 'initial';
                break;
            case _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS_STATE_CT:
                selector = 'ct-hide';
                type = 'none';
                break;
        }
        // Set style selector.
        const styleSelector = `style-${formId}-${selector}`;
        // Get style tag that needs settings.
        const styleTag = document.getElementById(`${styleSelector}`);
        // Set style output.
        const styleOutput = data.length ? `${data.join(',')}{display:${type} !important;}` : '';
        // Set style to DOM.
        if (!styleTag) {
            // Insert style to DOM.
            form.insertAdjacentHTML('beforeend', `<style id="${styleSelector}">${styleOutput}</style>`);
        } else {
            // Update style in DOM.
            styleTag.innerHTML = styleOutput;
        }
    }
    /**
	 * Get field top level state.
	 *
	 * @param {string} fromId Form Id.
	 * @param {string} name Field Name.
	 * @param {bool} isNoneFormBlock Is non-Forms block.
	 *
	 * @returns {bool}
	 */ getFieldTopLevel(formId, name, isNoneFormBlock = false) {
        // Find defaults to know what direction to use.
        const defaultState = !isNoneFormBlock ? this.state.getStateElementConditionalTagsDefaults(name, formId) : this.state.getStateElementFieldConditionalTagsDefaults(name, formId); // eslint-disable-line max-len
        const ref = !isNoneFormBlock ? this.state.getStateElementConditionalTagsRef(name, formId) : this.state.getStateElementFieldConditionalTagsRef(name, formId);
        // Check if conditions are valid or not. This is where the magic happens.
        const isValid = ref?.map((validItem)=>validItem.every(Boolean)).some(Boolean);
        // In case if option is visible by default.
        if (isValid && defaultState === this.SHOW) {
            return true;
        }
        // In case if option is hidden by default the logic is flipped.
        if (!isValid && defaultState === this.HIDE) {
            return true;
        }
        return false;
    }
    /**
	 * Get field inner level state.
	 *
	 * @param {string} fromId Form Id.
	 * @param {string} name Field Name.
	 *
	 * @returns {object}
	 */ getFieldInner(formId, name) {
        // Prepare outputs.
        const output = {
            innerParents: false,
            inner: []
        };
        // Find inner items.
        const items = Object.keys(this.state.getStateElementItems(name, formId) ?? []);
        // Loop inner items.
        items.forEach((innerName)=>{
            const inner = this.getFieldInnerByName(formId, name, innerName);
            if (inner) {
                // Push to inner state if existing.
                output.inner.push(inner);
            }
        });
        // Set inner parents fields state if every item in inner is hidden.
        if (this.getToggleParent(formId, name, output.inner)) {
            output.innerParents = true;
        }
        return output;
    }
    /**
	 * Get field inner items by name.
	 *
	 * @param {string} fromId Form Id.
	 * @param {string} name Field Name.
	 * @param {string} innerName Inner Field Name.
	 *
	 * @returns {bool|string}
	 */ getFieldInnerByName(formId, name, innerName) {
        // Check if conditions are valid or not. This is where the magic happens.
        const isValid = this.state.getStateElementConditionalTagsRefInner(name, innerName, formId)?.map((validItem)=>validItem.every(Boolean)).some(Boolean);
        // Find defaults to know what direction to use.
        const defaultState = this.state.getStateElementConditionalTagsDefaultsInner(name, innerName, formId);
        // In case if option is visible by default.
        if (isValid && defaultState === this.SHOW) {
            return innerName;
        }
        // In case if option is hidden by default the logic is flipped.
        if (!isValid && defaultState === this.HIDE) {
            return innerName;
        }
        return false;
    }
    /**
	 * Get field inner items - select.
	 *
	 * @param {string} fromId Form Id.
	 * @param {string} name Field Name.
	 *
	 * @returns {object}
	 */ getFieldInnerSelect(formId, name) {
        // Prepare outputs.
        const output = {
            innerParents: false,
            inner: []
        };
        // Loop all options.
        [
            ...this.state.getStateElementCustom(name, formId)?.passedElement?.element?.options ?? []
        ].forEach((option)=>{
            // Find item value.
            const innerName = option.value;
            // Bailout if placeholder.
            if (!innerName) {
                return;
            }
            const inner = this.getFieldInnerByName(formId, name, innerName);
            if (inner) {
                // Push to inner state if existing.
                output.inner.push(inner);
            }
        });
        // Set inner parents fields state if every item in inner is hidden.
        if (this.getToggleParent(formId, name, output.inner)) {
            output.innerParents = true;
        }
        return output;
    }
    /**
	 * Get field inner items - select single only.
	 *
	 * @param {string} fromId Form Id.
	 * @param {string} name Field Name.
	 *
	 * @returns {object}
	 */ getFieldInnerSelectSingle(formId, name) {
        // Get choices object.
        const custom = this.state.getStateElementCustom(name, formId);
        // Get active items.
        const innerName = custom?.getValue(true);
        // Remove active items by name.
        if (this.getFieldInnerByName(formId, name, innerName)) {
            custom?.removeActiveItemsByValue(innerName);
            custom?.setChoiceByValue('');
        }
        // Set inner items.
        return this.getFieldInnerSelect(formId, name);
    }
    /**
	 * Get field inner items - select multiple only.
	 *
	 * @param {string} fromId Form Id.
	 * @param {string} name Field Name.
	 *
	 * @returns {object}
	 */ getFieldInnerSelectMultiple(formId, name) {
        // Get choices object.
        const custom = this.state.getStateElementCustom(name, formId);
        // Get active items.
        custom?.getValue(true).forEach((innerName)=>{
            // Remove active items by name.
            if (this.getFieldInnerByName(formId, name, innerName)) {
                custom?.removeActiveItemsByValue(innerName);
            }
        });
        // Set inner items.
        return this.getFieldInnerSelect(formId, name);
    }
    /**
	 * Get toggle parent state.
	 *
	 * @param {string} fromId Form Id.
	 * @param {string} name Field Name.
	 * @param {string} currentState Current state name.
	 *
	 * @returns {bool}
	 */ getToggleParent(formId, name, currentState) {
        if (this.state.getStateElementTypeField(name, formId) === 'select') {
            // Get choices object.
            const items = this.state.getStateElementCustom(name, formId)?.passedElement?.element?.options;
            // Get total items.
            let totalItems = items?.length - 1;
            // All items are hidden so we need to hide the parent also.
            if (totalItems === currentState.length) {
                return true;
            }
        } else {
            // Get checkbox/radio items.
            const items = Object.keys(this.state.getStateElementItems(name, formId) ?? []);
            // All items are hidden so we need to hide the parent also.
            if (items?.length > 0 && items?.length === currentState.length) {
                return true;
            }
        }
        return false;
    }
    /**
	 * Do the actual logic of checking conditions for rule - inner item.
	 *
	 * @param {string} fromId Form Id.
	 * @param {string} name Field name.
	 *
	 * @returns {void}
	 */ setFieldsRulesInner(formId, name) {
        // Explode name because we can have inner items that have parent prefix.
        const [topName, innerName] = name.split('---');
        // Populate current ref state.
        let output = this.state.getStateElementConditionalTagsRefInner(topName, innerName, formId);
        // Loop all conditional tags.
        this.state.getStateElementConditionalTagsTagsInner(topName, innerName, formId).forEach((items, parent)=>{
            // Loop all inner fields.
            items.forEach(([innerName, innerCondition, innerValue], index)=>{
                // Placeholder value to check later.
                let value = '';
                // Get element type.
                const type = this.state.getStateElementTypeField(innerName, formId);
                // Bailout if type is missing.
                if (!type) {
                    return;
                }
                switch(type){
                    case 'checkbox':
                        // If check box inner items are missing this applies to parent element not children.
                        if (innerValue === '') {
                            // If all inner items are empty and not set this will output value to empty.
                            if (Object.values(this.state.getStateElementValue(innerName, formId)).map((inner)=>!inner).every(Boolean)) {
                                value = '';
                            } else {
                                // If we don't care about value just need to have not empty any item, value is set to something random.
                                value = 'empty';
                            }
                        } else {
                            // If we selected inner item in options use the value of that item.
                            value = this.state.getStateElementValue(innerName, formId)[innerValue] === innerValue ? innerValue : '';
                        }
                        break;
                    case 'select':
                    case 'country':
                        value = this.state.getStateElementValue(innerName, formId);
                        if (value.length === 0) {
                            value = '';
                        }
                        if (innerCondition === this.IS) {
                            innerCondition = this.C;
                        }
                        if (innerCondition === this.ISN) {
                            innerCondition = this.CN;
                        }
                        break;
                    default:
                        // Get element value by name.
                        value = this.state.getStateElementValue(innerName, formId);
                        break;
                }
                // Do the check based on the operator and set reference data with the correct state.
                output[parent][index] = this.utils.getComparator()[innerCondition](innerValue, value);
            });
        });
    }
    /**
	 * Do the actual logic of checking conditions for rule - top level item.
	 *
	 * @param {string} fromId Form Id.
	 * @param {string} name Field name.
	 *
	 * @returns {void}
	 */ setFieldsRules(formId, name) {
        // Populate current ref state.
        let output = this.state.getStateElementConditionalTagsRef(name, formId) ?? [];
        let data = this.state.getStateElementConditionalTagsTags(name, formId) ?? [];
        if (data.length === 0) {
            output = this.state.getStateElementFieldConditionalTagsRef(name, formId) ?? [];
            data = this.state.getStateElementFieldConditionalTagsTags(name, formId) ?? [];
        }
        // Loop all conditional tags.
        data.forEach((items, parent)=>{
            // Loop all inner fields.
            items.forEach((inner, index)=>{
                // Placeholder value to check later.
                let value = '';
                // Get element type.
                const type = this.state.getStateElementTypeField(inner[0], formId);
                // Bailout if type is missing.
                if (!type) {
                    return;
                }
                switch(type){
                    case 'checkbox':
                        // If check box inner items are missing this applies to parent element not children.
                        if (inner[2] === '') {
                            // If all inner items are empty and not set this will output value to empty.
                            if (Object.values(this.state.getStateElementValue(inner[0], formId)).map((inner)=>!inner).every(Boolean)) {
                                value = '';
                            } else {
                                // If we don't care about value just need to have not empty any item, value is set to something random.
                                value = 'empty';
                            }
                        } else {
                            // If we selected inner item in options use the value of that item.
                            value = this.state.getStateElementValue(inner[0], formId)[inner[2]] === inner[2] ? inner[2] : '';
                        }
                        break;
                    case 'select':
                    case 'country':
                        value = this.state.getStateElementValue(inner[0], formId);
                        if (value.length === 0) {
                            value = '';
                        }
                        if (inner[1] === this.IS) {
                            inner[1] = this.C;
                        }
                        if (inner[1] === this.ISN) {
                            inner[1] = this.CN;
                        }
                        break;
                    case 'phone':
                        value = this.utils.getPhoneCombinedValue(formId, inner[0]);
                        break;
                    default:
                        // Get element value by name.
                        value = this.state.getStateElementValue(inner[0], formId);
                        break;
                }
                // Do the check based on the operator and set reference data with the correct state.
                output[parent][index] = this.utils.getComparator()[inner[1]](inner[2], value);
            });
        });
    }
    /**
	 * Get ignore fields like hidden fields used when sending data to api.
	 *
	 * @param {string} formId Form Id.
	 *
	 * @returns {array}
	 */ getIgnoreFields(formId) {
        const ct = this.state.getStateFormConditionalTagsStateCt(formId)?.topFinal ?? [];
        const form = this.state.getStateFormConditionalTagsStateHideForms(formId)?.topFinal ?? [];
        return [
            ...new Set([
                ...ct,
                ...form
            ])
        ];
    }
    /**
	 * Remove active fields on hide.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 *
	 * @returns {void}
	 */ removeActiveFieldsOnHide(formId, data, stateName) {
        if (stateName === _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS_STATE_FORM_SHOW) {
            return;
        }
        Object.entries(data.inner).forEach(([key, items])=>{
            const type = this.state.getStateElementTypeField(key, formId);
            if (!items.length) {
                return;
            }
            if (!data.top.includes(key)) {
                switch(type){
                    case 'select':
                        this.removeManualSelectActiveValue(formId, key, items);
                        break;
                    case 'checkbox':
                        this.removeManualCheckboxActiveValue(formId, key, items);
                        break;
                    case 'radio':
                        this.removeManualRadioActiveValue(formId, key, items);
                        break;
                }
            }
        });
        [
            ...data.top,
            ...data.innerParents
        ].forEach((name)=>{
            this.removeActiveFieldsOnHideItem(formId, name);
        });
    }
    /**
	 * Remove active value from radio field.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 * @param {array} value Value to remove.
	 *
	 * @returns {void}
	 */ removeManualRadioActiveValue(formId, name, value) {
        if (!Array.isArray(value)) {
            return;
        }
        if (!(name in this.state.getStateElementsObject(formId))) {
            return;
        }
        let newValue = this.state.getStateElementValue(name, formId);
        const inner = this.state.getStateElementItems(name, formId);
        if (inner) {
            Object.values(inner).forEach((item)=>{
                if (value.includes(item.value)) {
                    item.input.checked = false;
                    newValue = '';
                }
            });
        }
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.setStateValues)(name, newValue, formId);
        this.utils.setMandatoryFieldState(formId, name, newValue, false);
    }
    /**
	 * Remove active value from select field.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 * @param {array} value Value to remove.
	 *
	 * @returns {void}
	 */ removeManualSelectActiveValue(formId, name, value) {
        if (!Array.isArray(value)) {
            return;
        }
        if (!(name in this.state.getStateElementsObject(formId))) {
            return;
        }
        const custom = this.state.getStateElementCustom(name, formId);
        const currentValue = this.state.getStateElementValue(name, formId);
        if (custom) {
            custom.removeActiveItemsByValue(value);
        }
        const newValue = currentValue.filter((item)=>!value.includes(item));
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.setStateValues)(name, newValue, formId);
        this.utils.setMandatoryFieldState(formId, name, newValue, false);
    }
    /**
	 * Remove active value from checkbox field.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 * @param {array} value Value to remove.
	 *
	 * @returns {void}
	 */ removeManualCheckboxActiveValue(formId, name, value) {
        if (!Array.isArray(value)) {
            return;
        }
        if (!(name in this.state.getStateElementsObject(formId))) {
            return;
        }
        let newValue = this.state.getStateElementValue(name, formId);
        const inner = this.state.getStateElementItems(name, formId);
        if (inner) {
            Object.values(inner).forEach((item)=>{
                if (value.includes(item.value)) {
                    item.input.checked = false;
                    newValue[item.value] = '';
                }
            });
        }
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.setStateValues)(name, newValue, formId);
        this.utils.setMandatoryFieldState(formId, name, newValue, false);
    }
    /**
	 * Remove active fields on hide item.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 *
	 * @returns {void}
	 */ removeActiveFieldsOnHideItem(formId, name) {
        switch(this.state.getStateElementTypeField(name, formId)){
            case 'range':
                this.utils.setManualRangeValue(formId, name, '', false);
                break;
            case 'rating':
                this.utils.setManualRatingValue(formId, name, '', false);
                break;
            case 'radio':
                this.utils.setManualRadioValue(formId, name, '', false);
                break;
            case 'checkbox':
                this.utils.setManualCheckboxValue(formId, name, {}, false);
                break;
            case 'select':
                this.utils.setManualSelectValue(formId, name, [], false);
                break;
            case 'country':
                this.utils.setManualCountryValue(formId, name, [], false);
                break;
            case 'phone':
                this.utils.setManualPhoneValue(formId, name, {}, false);
                break;
            case 'date':
            case 'dateTime':
                this.utils.setManualDateValue(formId, name, '', false);
                break;
            default:
                this.utils.setManualInputValue(formId, name, '', false);
                break;
        }
    }
    ////////////////////////////////////////////////////////////////
    // Other
    ////////////////////////////////////////////////////////////////
    /**
	 * Remove all event listeners from elements.
	 *
	 * @returns {void}
	 */ removeEvents() {
        window?.removeEventListener(this.state.getStateEvent('formJsLoaded'), this.onInitEvent);
    }
    ////////////////////////////////////////////////////////////////
    // Events callback
    ////////////////////////////////////////////////////////////////
    /**
	 * On init event callback.
	 *
	 * @param {CustomEvent} event Event object.
	 *
	 * @returns {void}
	 */ onInitEvent = (event)=>{
        const { formId } = event.detail;
        // Set forms logic.
        this.initForms(formId);
        // Set fields logic.
        this.initFields(formId);
    };
    ////////////////////////////////////////////////////////////////
    // Private methods - not shared to the public window object.
    ////////////////////////////////////////////////////////////////
    /**
	 * Set all public methods.
	 *
	 * @returns {void}
	 */ publicMethods() {
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.setStateWindow)();
        if (window[_state_init__WEBPACK_IMPORTED_MODULE_0__.prefix].conditionalTags) {
            return;
        }
        window[_state_init__WEBPACK_IMPORTED_MODULE_0__.prefix].conditionalTags = {
            SHOW: this.SHOW,
            HIDE: this.HIDE,
            OR: this.OR,
            AND: this.AND,
            initOne: (formId)=>{
                this.initOne(formId);
            },
            initForms: (formId)=>{
                this.initForms(formId);
            },
            initFields: (formId)=>{
                this.initFields(formId);
            },
            setField: (formId, name)=>{
                this.setField(formId, name);
            },
            setFields: (formId)=>{
                this.setFields(formId);
            },
            setFieldsRulesAll: (formId, fieldName)=>{
                this.setFieldsRulesAll(formId, fieldName);
            },
            setStyles: (formId, data, stateName)=>{
                this.setStyles(formId, data, stateName);
            },
            outputStyles: (formId, data, stateName)=>{
                this.outputStyles(formId, data, stateName);
            },
            getFieldTopLevel: (formId, name, isNoneFormBlock = false)=>{
                return this.getFieldTopLevel(formId, name, isNoneFormBlock);
            },
            getFieldInner: (formId, name)=>{
                return this.getFieldInner(formId, name);
            },
            getFieldInnerByName: (formId, name, innerName)=>{
                return this.getFieldInnerByName(formId, name, innerName);
            },
            getFieldInnerSelect: (formId, name)=>{
                return this.getFieldInnerSelect(formId, name);
            },
            getFieldInnerSelectSingle: (formId, name)=>{
                return this.getFieldInnerSelectSingle(formId, name);
            },
            getFieldInnerSelectMultiple: (formId, name)=>{
                return this.getFieldInnerSelectMultiple(formId, name);
            },
            getToggleParent: (formId, name, currentState)=>{
                return this.getToggleParent(formId, name, currentState);
            },
            setFieldsRulesInner: (formId, name)=>{
                this.setFieldsRulesInner(formId, name);
            },
            setFieldsRules: (formId, name)=>{
                this.setFieldsRules(formId, name);
            },
            getIgnoreFields: (formId)=>{
                return this.getIgnoreFields(formId);
            },
            removeActiveFieldsOnHide: (formId, data, stateName)=>{
                this.removeActiveFieldsOnHide(formId, data, stateName);
            },
            removeManualRadioActiveValue: (formId, name, value)=>{
                this.removeManualRadioActiveValue(formId, name, value);
            },
            removeManualSelectActiveValue: (formId, data, stateName)=>{
                this.removeManualSelectActiveValue(formId, data, stateName);
            },
            removeManualCheckboxActiveValue: (formId, data, stateName)=>{
                this.removeManualCheckboxActiveValue(formId, data, stateName);
            },
            removeActiveFieldsOnHideItem: (formId, name)=>{
                this.removeActiveFieldsOnHideItem(formId, name);
            },
            removeEvents: (formId)=>{
                this.removeEvents(formId);
            },
            onInitEvent: (event)=>{
                this.onInitEvent(event);
            }
        };
    }
}


/***/ }),

/***/ "./src/Blocks/components/form/assets/enrichment.js":
/*!*********************************************************!*\
  !*** ./src/Blocks/components/form/assets/enrichment.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Enrichment: () => (/* binding */ Enrichment)
/* harmony export */ });
/* harmony import */ var _eightshift_frontend_libs_scripts_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @eightshift/frontend-libs/scripts/helpers */ "./node_modules/@eightshift/frontend-libs/scripts/helpers/cookies.js");
/* harmony import */ var _state_init__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./state-init */ "./src/Blocks/components/form/assets/state-init.js");


/**
 * Enrichment class.
 */ class Enrichment {
    constructor(utils){
        /** @type {import('./utils').Utils} */ this.utils = utils;
        /** @type {import('./state').State} */ this.state = this.utils.getState();
        // Set all public methods.
        this.publicMethods();
    }
    ////////////////////////////////////////////////////////////////
    // Public methods
    ////////////////////////////////////////////////////////////////
    /**
	 * Init all actions.
	 *
	 * @returns {void}
	 */ init() {
        // Check if enrichment is used.
        if (!this.state.getStateEnrichmentIsUsed()) {
            return;
        }
        // Set local storage data for enrichment.
        this.setLocalStorageEnrichment();
    }
    /**
	 * Set localStorage value for enrichment.
	 *
	 * @returns {void}
	 */ setLocalStorageEnrichment() {
        // Check if enrichment is used.
        if (!this.state.getStateEnrichmentIsUsed() || !this.state.getStateEnrichmentIsLocalStorageUsed()) {
            return;
        }
        const allowedTags = this.state.getStateEnrichmentAllowed();
        // Missing data from backend, bailout.
        if (!allowedTags) {
            return;
        }
        // Get storage from backend this is considered new by the page request.
        const newStorage = {
            ...this.getUrlAllowedParams(allowedTags),
            ...this.getCookiesAllowedParams(allowedTags)
        };
        this.setLocalStorage(newStorage, this.state.getStateEnrichmentStorageName());
    }
    /**
	 * Prefill localStorage value for every field.
	 *
	 * @returns {void}
	 */ setLocalStorageFormPrefill() {
        // Check if enrichment is used.
        if (!this.state.getStateEnrichmentIsUsed() || !this.state.getStateEnrichmentIsLocalStorageUsed()) {
            return;
        }
        window.addEventListener(this.state.getStateEvent('formJsLoaded'), this.onLocalstoragePrefillEvent);
    }
    /**
	 * Prefill url params value for every field.
	 *
	 * @returns {void}
	 */ setUrlParamsFormPrefill() {
        // Check if enrichment is used.
        if (!this.state.getStateEnrichmentIsUsed() || !this.state.getStateEnrichmentIsPrefillUrlUsed()) {
            return;
        }
        window.addEventListener(this.state.getStateEvent('formJsLoaded'), this.onUrlParamsPrefillEvent);
    }
    /**
	 * Set localStorage value for every field.
	 *
	 * @returns {void}
	 */ setLocalStorageFormPrefillField(formId, name) {
        this.setLocalStorageFormPrefillFieldItem(formId, name);
        this.setLocalStorageFormPrefillFieldSmart(formId, name);
    }
    /**
	 * Set localStorage value for every field - general.
	 *
	 * @returns {void}
	 */ setLocalStorageFormPrefillFieldItem(formId, name) {
        // Check if enrichment is used.
        if (!this.state.getStateEnrichmentIsUsed() || !this.state.getStateEnrichmentIsLocalStorageUsed()) {
            return;
        }
        if (!this.state.getStateEnrichmentIsPrefillUsed()) {
            return;
        }
        const valueData = this.state.getStateElementValue(name, formId);
        const newStorage = {
            [name]: typeof valueData === 'undefined' ? '' : valueData
        };
        this.setLocalStorage(newStorage, this.state.getStateEnrichmentFormPrefillStorageName(formId), this.state.getStateEnrichmentExpirationPrefill());
    }
    /**
	 * Set localStorage value for every field - smart.
	 *
	 * @returns {void}
	 */ setLocalStorageFormPrefillFieldSmart(formId, name) {
        // Check if enrichment is used.
        if (!this.state.getStateEnrichmentIsUsed() || !this.state.getStateEnrichmentIsLocalStorageUsed()) {
            return;
        }
        const allowedSmartTags = this.state.getStateEnrichmentAllowedSmart();
        if (!allowedSmartTags) {
            return;
        }
        if (!allowedSmartTags.includes(name)) {
            return;
        }
        const valueData = this.state.getStateElementValue(name, formId);
        const newStorage = {
            [name]: typeof valueData === 'undefined' ? '' : valueData
        };
        this.setLocalStorage(newStorage, this.state.getStateEnrichmentSmartStorageName());
    }
    /**
	 * Set localStorage value.
	 *
	 * @returns {void}
	 */ setLocalStorage(newStorage, storageName, expiration = this.state.getStateEnrichmentExpiration()) {
        // Check if enrichment is used.
        if (!this.state.getStateEnrichmentIsUsed() || !this.state.getStateEnrichmentIsLocalStorageUsed()) {
            return;
        }
        if (!localStorage || !newStorage) {
            return;
        }
        // Add current timestamp to new storage.
        newStorage.timestamp = Date.now();
        // Create new storage if this is the first visit or it was expired.
        if (this.getLocalStorage(storageName) === null) {
            newStorage.timestamp = newStorage.timestamp.toString();
            localStorage?.setItem(storageName, JSON.stringify(newStorage));
            return;
        }
        // Store in a new variable for later usage.
        const newStorageFinal = {
            ...newStorage
        };
        delete newStorageFinal.timestamp;
        // Current storage is got from localStorage.
        const currentStorage = JSON.parse(this.getLocalStorage(storageName));
        // Store in a new variable for later usage.
        const currentStorageFinal = {
            ...currentStorage
        };
        delete currentStorageFinal.timestamp;
        currentStorage.timestamp = parseInt(currentStorage?.timestamp, 10);
        // If storage exists check if it is expired.
        if (this.getLocalStorage(storageName) !== null) {
            // Update expiration date by number of days from the current
            let expirationDate = new Date(currentStorage.timestamp);
            expirationDate.setDate(expirationDate.getDate() + parseInt(expiration, 10));
            // Remove expired storage if it exists.
            if (expirationDate.getTime() < currentStorage.timestamp) {
                localStorage?.removeItem(storageName);
            }
        }
        // Prepare new output.
        const output = {
            ...currentStorageFinal,
            ...newStorageFinal
        };
        // If output is empty something was wrong here and just bailout.
        if (Object.keys(output).length === 0) {
            return;
        }
        // If nothing has changed bailout.
        if (JSON.stringify(currentStorageFinal) === JSON.stringify(output)) {
            return;
        }
        // Add timestamp to the new output.
        const finalOutput = {
            ...output,
            timestamp: newStorage.timestamp.toString()
        };
        // Update localStorage with the new item.
        localStorage?.setItem(storageName, JSON.stringify(finalOutput));
    }
    /**
	 * Get localStorage data.
	 *
	 * @param {string} storageName Storage name.
	 *
	 * @returns {object}
	 */ getLocalStorage(storageName) {
        if (!this.state.getStateEnrichmentIsUsed() || !this.state.getStateEnrichmentIsLocalStorageUsed()) {
            return null;
        }
        if (!localStorage) {
            return null;
        }
        return localStorage?.getItem(storageName);
    }
    /**
	 * Delete localStorage data.
	 *
	 * @param {string} storageName Storage name.
	 *
	 * @returns {void}
	 */ deleteLocalStorage(storageName) {
        if (!this.state.getStateEnrichmentIsUsed() || !this.state.getStateEnrichmentIsLocalStorageUsed()) {
            return;
        }
        if (!localStorage) {
            return;
        }
        localStorage?.removeItem(storageName);
    }
    /**
	 * Filter all url params based on the allowed tags list.
	 *
	 * @param {array} allowedTags List of allowed tags from config.
	 *
	 * @returns {object}
	 */ getUrlAllowedParams(allowedTags) {
        const output = {};
        // Bailout if nothing is set in the url.
        if (!window.location.search) {
            return output;
        }
        // Find url params.
        const searchParams = new URLSearchParams(window.location.search);
        allowedTags.forEach((element)=>{
            const item = searchParams.get(element);
            if (item) {
                output[element] = item.toString();
            }
        });
        return output;
    }
    /**
	 * Filter all set cookies based on the allowed tags list.
	 *
	 * @param {array} allowedTags List of allowed tags from config.
	 *
	 * @returns {object}
	 */ getCookiesAllowedParams(allowedTags) {
        const output = {};
        allowedTags.forEach((element)=>{
            const item = _eightshift_frontend_libs_scripts_helpers__WEBPACK_IMPORTED_MODULE_0__.cookies.getCookie(element);
            if (item) {
                output[element] = item.toString();
            }
        });
        return output;
    }
    /**
	 * Prefill form fields with data - url params.
	 *
	 * @param {string} formId Form ID.
	 * @param {array} data Field data.
	 *
	 * Note:
	 * Field divider is / and value divider is ==.
	 *
	 * Fields:
	 * - checkboxes (checkboxes==check1---test). If the value is not in the checkboxes group, it will be added to the input field if it exists.
	 * - input (input==test).
	 * - range (range==10).
	 * - rating (rating==1).
	 * - textarea (textarea==test test).
	 * - radios (radios==radio-2). If the value is not in the radio group, it will be added to the input field if it exists.
	 * - date (date==2021-01-01).
	 * - datetime (datetime==2021-01-01 12:00).
	 * - select (select==option-1---option-2).
	 * - phone (phone==123456789---385). Value and prefix.
	 * - country (country==hr---de). Country code.
	 *
	 * Example:
	 * ?form-840=checkboxes==check1---check2/input==test/range==10
	 *
	 * @returns {void}
	 */ prefillByUrlData(formId, data) {
        this.utils.dispatchFormEventForm(this.state.getStateEvent('beforeEnrichmentUrlPrefill'), formId, data);
        data.forEach((param)=>{
            const paramItem = param.split('==');
            if (!paramItem.length) {
                return;
            }
            const name = paramItem[0];
            const value = paramItem[1];
            if (!name || !value) {
                return;
            }
            switch(this.state.getStateElementTypeField(name, formId)){
                case 'phone':
                    const phoneValue = value.split('---');
                    if (!phoneValue.length) {
                        break;
                    }
                    const newPhoneValue = {
                        prefix: phoneValue[1] || '',
                        value: phoneValue[0]
                    };
                    this.utils.setManualPhoneValue(formId, name, newPhoneValue);
                    break;
                case 'date':
                case 'dateTime':
                    this.utils.setManualDateValue(formId, name, value);
                    break;
                case 'select':
                    const selectValue = value.split('---');
                    if (!selectValue.length) {
                        break;
                    }
                    this.utils.setManualSelectValue(formId, name, selectValue);
                    break;
                case 'country':
                    const countryValue = value.split('---');
                    if (!countryValue.length) {
                        break;
                    }
                    this.utils.setManualCountryValue(formId, name, countryValue);
                    break;
                case 'checkbox':
                    const checkboxValue = value.split('---');
                    if (!checkboxValue.length) {
                        break;
                    }
                    this.utils.setManualCheckboxValue(formId, name, checkboxValue);
                    break;
                case 'radio':
                    this.utils.setManualRadioValue(formId, name, value);
                    break;
                case 'rating':
                    this.utils.setManualRatingValue(formId, name, value);
                    break;
                case 'range':
                    this.utils.setManualRangeValue(formId, name, value);
                    break;
                default:
                    this.utils.setManualInputValue(formId, name, value);
                    break;
            }
        });
        this.utils.dispatchFormEventForm(this.state.getStateEvent('afterEnrichmentUrlPrefill'), formId, data);
    }
    /**
	 * Prefill form fields with data - localstorage.
	 *
	 * @param {string} formId Form ID.
	 * @param {object} data Field data.
	 *
	 * @returns {void}
	 */ prefillByLocalstorageData(formId, data) {
        this.utils.dispatchFormEventForm(this.state.getStateEvent('beforeEnrichmentLocalstoragePrefill'), formId, data);
        Object.entries(data).forEach(([name, value])=>{
            if (name === 'timestamp') {
                return;
            }
            switch(this.state.getStateElementTypeField(name, formId)){
                case 'phone':
                    this.utils.setManualPhoneValue(formId, name, value);
                    break;
                case 'date':
                case 'dateTime':
                    this.utils.setManualDateValue(formId, name, value);
                    break;
                case 'select':
                    this.utils.setManualSelectValue(formId, name, value);
                    break;
                case 'country':
                    this.utils.setManualCountryValue(formId, name, value);
                    break;
                case 'checkbox':
                    this.utils.setManualCheckboxValue(formId, name, value);
                    break;
                case 'radio':
                    this.utils.setManualRadioValue(formId, name, value);
                    break;
                case 'rating':
                    this.utils.setManualRatingValue(formId, name, value);
                    break;
                case 'range':
                    this.utils.setManualRangeValue(formId, name, value);
                    break;
                default:
                    this.utils.setManualInputValue(formId, name, value);
                    break;
            }
        });
        this.utils.dispatchFormEventForm(this.state.getStateEvent('afterEnrichmentLocalstoragePrefill'), formId, data);
    }
    ////////////////////////////////////////////////////////////////
    // Other
    ////////////////////////////////////////////////////////////////
    /**
	 * Remove all event listeners from elements.
	 *
	 * @returns {void}
	 */ removeEvents() {
        window?.removeEventListener(this.state.getStateEvent('formJsLoaded'), this.onLocalstoragePrefillEvent);
        window?.removeEventListener(this.state.getStateEvent('formJsLoaded'), this.onUrlParamsPrefillEvent);
    }
    ////////////////////////////////////////////////////////////////
    // Events callback
    ////////////////////////////////////////////////////////////////
    /**
	 * Set url params value for every field.
	 *
	 * @param {object} event Event callback.
	 *
	 * @returns {void}
	 */ onUrlParamsPrefillEvent = (event)=>{
        const { formId } = event.detail;
        // Bailout if nothing is set in the url.
        if (!window.location.search) {
            return;
        }
        // Find url params.
        const searchParams = new URLSearchParams(window.location.search);
        let params = searchParams.get(`form-${this.state.getStateFormFid(formId)}`);
        if (!params) {
            return;
        }
        params = params.split('/');
        if (!params.length) {
            return;
        }
        this.prefillByUrlData(formId, params);
    };
    /**
	 * Set localStorage value for every field.
	 *
	 * @param {object} event Event callback.
	 *
	 * @returns {void}
	 */ onLocalstoragePrefillEvent = (event)=>{
        const { formId } = event.detail;
        try {
            if (this.state.getStateEnrichmentAllowedSmart().length) {
                const smartData = JSON.parse(this.getLocalStorage(this.state.getStateEnrichmentSmartStorageName()));
                if (smartData) {
                    this.prefillByLocalstorageData(formId, smartData);
                }
            }
            if (this.state.getStateEnrichmentIsPrefillUsed()) {
                const formData = JSON.parse(this.getLocalStorage(this.state.getStateEnrichmentFormPrefillStorageName(formId)));
                if (formData) {
                    this.prefillByLocalstorageData(formId, formData);
                }
            }
        } catch  {
            return;
        }
    };
    ////////////////////////////////////////////////////////////////
    // Private methods - not shared to the public window object.
    ////////////////////////////////////////////////////////////////
    /**
	 * Set all public methods.
	 *
	 * @returns {void}
	 */ publicMethods() {
        (0,_state_init__WEBPACK_IMPORTED_MODULE_1__.setStateWindow)();
        if (window[_state_init__WEBPACK_IMPORTED_MODULE_1__.prefix].enrichment) {
            return;
        }
        window[_state_init__WEBPACK_IMPORTED_MODULE_1__.prefix].enrichment = {
            init: ()=>{
                this.init();
            },
            setLocalStorageEnrichment: ()=>{
                this.setLocalStorageEnrichment();
            },
            setLocalStorageFormPrefill: ()=>{
                this.setLocalStorageFormPrefill();
            },
            setUrlParamsFormPrefill: (formId)=>{
                this.setUrlParamsFormPrefill(formId);
            },
            setLocalStorageFormPrefillField: (formId, name)=>{
                this.setLocalStorageFormPrefillField(formId, name);
            },
            setLocalStorageFormPrefillFieldItem: (formId, name)=>{
                this.setLocalStorageFormPrefillFieldItem(formId, name);
            },
            setLocalStorageFormPrefillFieldSmart: (formId, name)=>{
                this.setLocalStorageFormPrefillFieldSmart(formId, name);
            },
            setLocalStorage: (newStorage, storageName, expiration)=>{
                this.setLocalStorage(newStorage, storageName, expiration);
            },
            getLocalStorage: (storageName)=>{
                return this.getLocalStorage(storageName);
            },
            deleteLocalStorage: (storageName)=>{
                this.deleteLocalStorage(storageName);
            },
            getUrlAllowedParams: (allowedTags)=>{
                return this.getUrlAllowedParams(allowedTags);
            },
            getCookiesAllowedParams: (allowedTags)=>{
                return this.getCookiesAllowedParams(allowedTags);
            },
            prefillByUrlData: (formId, data)=>{
                this.prefillByUrlData(formId, data);
            },
            prefillByLocalstorageData: (formId, data)=>{
                this.prefillByLocalstorageData(formId, data);
            },
            removeEvents: ()=>{
                this.removeEvents();
            },
            onUrlParamsPrefillEvent: (event)=>{
                this.onUrlParamsPrefillEvent(event);
            },
            onLocalstoragePrefillEvent: (event)=>{
                this.onLocalstoragePrefillEvent(event);
            }
        };
    }
}


/***/ }),

/***/ "./src/Blocks/components/form/assets/geolocation.js":
/*!**********************************************************!*\
  !*** ./src/Blocks/components/form/assets/geolocation.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Geolocation: () => (/* binding */ Geolocation)
/* harmony export */ });
/* harmony import */ var _eightshift_frontend_libs_scripts_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @eightshift/frontend-libs/scripts/helpers */ "./node_modules/@eightshift/frontend-libs/scripts/helpers/cookies.js");
/* harmony import */ var _state_init__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./state-init */ "./src/Blocks/components/form/assets/state-init.js");


/**
 * Geolocation class.
 */ class Geolocation {
    constructor(utils){
        /** @type {import('./utils').Utils} */ this.utils = utils;
        /** @type {import('./state').State} */ this.state = this.utils.getState();
        // Set all public methods.
        this.publicMethods();
    }
    ////////////////////////////////////////////////////////////////
    // Public methods
    ////////////////////////////////////////////////////////////////
    /**
	 * Init one action.
	 *
	 * @returns {void}
	 */ initOne() {
        // Check if enrichment is used.
        if (!this.state.getStateGeolocationIsUsed()) {
            return;
        }
        // Set select fields based on geolocation.
        window?.addEventListener(this.state.getStateEvent('formJsLoaded'), this.onSetSelectField);
    }
    ////////////////////////////////////////////////////////////////
    // Other
    ////////////////////////////////////////////////////////////////
    /**
	 * Remove all event listeners from elements.
	 *
	 * @returns {void}
	 */ removeEvents() {
        window?.removeEventListener(this.state.getStateEvent('formJsLoaded'), this.onSetSelectField);
    }
    ////////////////////////////////////////////////////////////////
    // Events callback
    ////////////////////////////////////////////////////////////////
    /**
	 * Detect if we have country cookie and set value to the select.
	 *
	 * @param {object} event Event callback.
	 *
	 * @returns {void}
	 */ onSetSelectField = (event)=>{
        const { formId } = event.detail;
        const countryCookie = _eightshift_frontend_libs_scripts_helpers__WEBPACK_IMPORTED_MODULE_0__.cookies?.getCookie('esForms-country')?.toLocaleLowerCase();
        if (!countryCookie || countryCookie.length !== 2) {
            return;
        }
        [
            ...this.state.getStateElementByTypeField('country', formId),
            ...this.state.getStateElementByTypeField('phone', formId)
        ].forEach((select)=>{
            const name = select.name;
            const type = this.state.getStateElementTypeField(name, formId);
            switch(type){
                case 'country':
                    this.utils.setManualSelectByAttributeValue(formId, name, [
                        countryCookie
                    ], this.state.getStateAttribute('countryCode'));
                    break;
                case 'phone':
                    this.utils.setManualPhonePrefixByAttributeValue(formId, name, countryCookie, this.state.getStateAttribute('countryCode'));
                    break;
            }
        });
    };
    ////////////////////////////////////////////////////////////////
    // Private methods - not shared to the public window object.
    ////////////////////////////////////////////////////////////////
    /**
	 * Set all public methods.
	 *
	 * @returns {void}
	 */ publicMethods() {
        (0,_state_init__WEBPACK_IMPORTED_MODULE_1__.setStateWindow)();
        if (window[_state_init__WEBPACK_IMPORTED_MODULE_1__.prefix].geolocation) {
            return;
        }
        window[_state_init__WEBPACK_IMPORTED_MODULE_1__.prefix].geolocation = {
            initOne: ()=>{
                this.initOne();
            },
            removeEvents: (formId)=>{
                this.removeEvents(formId);
            },
            onSetSelectField: (event)=>{
                this.onSetSelectField(event);
            }
        };
    }
}


/***/ }),

/***/ "./src/Blocks/components/form/assets/index.js":
/*!****************************************************!*\
  !*** ./src/Blocks/components/form/assets/index.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_dom_ready__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/dom-ready */ "./node_modules/@wordpress/dom-ready/build-module/index.js");
/* harmony import */ var _state_init__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./state-init */ "./src/Blocks/components/form/assets/state-init.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils */ "./src/Blocks/components/form/assets/utils.js");
/* global esFormsLocalization */ 


// Global variable must be set for everything to work.
if (typeof esFormsLocalization === 'undefined') {
    throw Error('Your project is missing global variable "esFormsLocalization" called from the enqueue script in the forms.');
}
// Set initial state.
(0,_state_init__WEBPACK_IMPORTED_MODULE_1__.setStateInitial)();
// Load state helpers.
const utils = new _utils__WEBPACK_IMPORTED_MODULE_2__.Utils();
const state = utils.getState();
(0,_wordpress_dom_ready__WEBPACK_IMPORTED_MODULE_0__["default"])(()=>{
    // Load captcha if using initial.
    if (state.getStateCaptchaIsUsed()) {
        __webpack_require__.e(/*! import() */ "src_Blocks_components_form_assets_captcha_js").then(__webpack_require__.bind(__webpack_require__, /*! ./captcha */ "./src/Blocks/components/form/assets/captcha.js")).then(({ Captcha })=>{
            new Captcha(utils).init();
        });
    }
    if (!state.getStateSettingsFormDisableAutoInit()) {
        if (document.querySelectorAll(state.getStateSelector('form', true))?.length) {
            __webpack_require__.e(/*! import() */ "src_Blocks_components_form_assets_form_js").then(__webpack_require__.bind(__webpack_require__, /*! ./form */ "./src/Blocks/components/form/assets/form.js")).then(({ Form })=>{
                new Form(utils).init();
            });
        }
    } else {
        __webpack_require__.e(/*! import() */ "src_Blocks_components_form_assets_form_js").then(__webpack_require__.bind(__webpack_require__, /*! ./form */ "./src/Blocks/components/form/assets/form.js")).then(({ Form })=>{
            new Form(utils);
            utils.dispatchFormEventWindow(state.getStateEvent('formManualInitLoaded'));
        });
    }
});


/***/ }),

/***/ "./src/Blocks/components/form/assets/state-init.js":
/*!*********************************************************!*\
  !*** ./src/Blocks/components/form/assets/state-init.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ROUTES: () => (/* binding */ ROUTES),
/* harmony export */   StateEnum: () => (/* binding */ StateEnum),
/* harmony export */   getRestUrl: () => (/* binding */ getRestUrl),
/* harmony export */   getRestUrlByType: () => (/* binding */ getRestUrlByType),
/* harmony export */   getState: () => (/* binding */ getState),
/* harmony export */   getStateAttribute: () => (/* binding */ getStateAttribute),
/* harmony export */   getStateEvent: () => (/* binding */ getStateEvent),
/* harmony export */   getStateFieldType: () => (/* binding */ getStateFieldType),
/* harmony export */   getStateParam: () => (/* binding */ getStateParam),
/* harmony export */   getStateResponseOutputKey: () => (/* binding */ getStateResponseOutputKey),
/* harmony export */   getStateRoute: () => (/* binding */ getStateRoute),
/* harmony export */   getStateSelector: () => (/* binding */ getStateSelector),
/* harmony export */   getStateSelectorAdmin: () => (/* binding */ getStateSelectorAdmin),
/* harmony export */   getStateSuccessRedirectUrlKey: () => (/* binding */ getStateSuccessRedirectUrlKey),
/* harmony export */   getStateTop: () => (/* binding */ getStateTop),
/* harmony export */   getUtilsIcons: () => (/* binding */ getUtilsIcons),
/* harmony export */   prefix: () => (/* binding */ prefix),
/* harmony export */   removeStateForm: () => (/* binding */ removeStateForm),
/* harmony export */   setState: () => (/* binding */ setState),
/* harmony export */   setStateConditionalTags: () => (/* binding */ setStateConditionalTags),
/* harmony export */   setStateConditionalTagsInner: () => (/* binding */ setStateConditionalTagsInner),
/* harmony export */   setStateConditionalTagsItems: () => (/* binding */ setStateConditionalTagsItems),
/* harmony export */   setStateFormInitial: () => (/* binding */ setStateFormInitial),
/* harmony export */   setStateInitial: () => (/* binding */ setStateInitial),
/* harmony export */   setStateValues: () => (/* binding */ setStateValues),
/* harmony export */   setStateWindow: () => (/* binding */ setStateWindow),
/* harmony export */   setSteps: () => (/* binding */ setSteps),
/* harmony export */   simpleDecode: () => (/* binding */ simpleDecode)
/* harmony export */ });
/* harmony import */ var _manifest_json__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../manifest.json */ "./src/Blocks/manifest.json");
/* global esFormsLocalization */ 
////////////////////////////////////////////////////////////////
// Constants
////////////////////////////////////////////////////////////////
// Prefix all forms JS with this string.
const prefix = 'esForms';
// Enum object for all state items.
const StateEnum = {
    // State names.
    IS_LOADED: 'isLoaded',
    IS_PROCESSING: 'isProcessing',
    ELEMENTS: 'elements',
    ELEMENTS_FIELDS: 'elementsFields',
    FORM: 'form',
    FORMS: 'forms',
    FORM_FID: 'formFid',
    POST_ID: 'postId',
    METHOD: 'method',
    ACTION: 'action',
    ACTION_EXTERNAL: 'actionExternal',
    MULTISTEP_SKIP_SCROLL: 'multistepSkipScroll',
    SECURE_DATA: 'secureData',
    FIELD: 'field',
    FIELDSET: 'fieldset',
    RANGE_CURRENT: 'rangeCurrent',
    FILE_BUTTON: 'fileButton',
    VALUE: 'value',
    INITIAL: 'initial',
    VALUES: 'values',
    INPUT: 'input',
    INPUT_SELECT: 'inputSelect',
    ITEMS: 'items',
    CUSTOM: 'custom',
    CUSTOM_NAME: 'customName',
    IS_DISABLED: 'disabled',
    TYPE: 'type',
    TYPE_SETTINGS: 'typeSettings',
    TYPE_FIELD: 'typeField',
    TYPE_CUSTOM: 'typeCustom',
    NAME: 'name',
    ERROR: 'error',
    GLOBAL_MSG: 'globalMsg',
    HAS_ERROR: 'hasError',
    HAS_CHANGED: 'hasChanged',
    LOADED: 'loaded',
    LOADER: 'loader',
    ELEMENT: 'element',
    HEADING_SUCCESS: 'headingSuccess',
    HEADING_ERROR: 'headingError',
    IS_ADMIN_SINGLE_SUBMIT: 'isAdminSingleSubmit',
    SAVE_AS_JSON: 'saveAsJson',
    IS_ADMIN: 'isAdmin',
    IS_USED: 'isUsed',
    IS_USED_LOCALSTORAGE: 'isUsedLocalStorage',
    IS_USED_PREFILL: 'isUsedPrefill',
    IS_USED_PREFILL_URL: 'isUsedPrefillUrl',
    NONCE: 'nonce',
    // Conditional tags
    CONDITIONAL_TAGS: 'conditionalTags',
    CONDITIONAL_TAGS_INNER: 'conditionalTagsInner',
    TAGS: 'tags',
    TAGS_REF: 'reference',
    TAGS_DEFAULTS: 'defaults',
    TAGS_EVENTS: 'events',
    CONDITIONAL_TAGS_FORM: 'conditionalTagsForm',
    CONDITIONAL_TAGS_EVENTS: 'conditionalTagsEvents',
    CONDITIONAL_TAGS_STATE_FORM_HIDE: 'conditionalTagsStateFormHide',
    CONDITIONAL_TAGS_STATE_FORM_SHOW: 'conditionalTagsStateFormShow',
    CONDITIONAL_TAGS_STATE_CT: 'conditionalTagsStateCt',
    CONDITIONAL_TAGS_INNER_EVENTS: 'conditionalTagsInnerEvents',
    CONFIG: 'config',
    CONFIG_SELECT_USE_SEARCH: 'useSearch',
    CONFIG_SELECT_USE_MULTIPLE: 'useMultiple',
    CONFIG_PHONE_DISABLE_PICKER: 'disablePhoneCountryPicker',
    CONFIG_USE_SINGLE_SUBMIT: 'useSingleSubmit',
    SETTINGS: 'settings',
    SETTINGS_LABELS: 'labels',
    SETTINGS_DISABLE_SCROLL_TO_GLOBAL_MSG_ON_SUCCESS: 'disableScrollToGlobalMsgOnSuccess',
    SETTINGS_DISABLE_SCROLL_TO_FIELD_ON_ERROR: 'disableScrollToFieldOnError',
    SETTINGS_DISABLE_SCROLL_TO_FIELD_ON_FOCUS: 'disableScrollToFieldOnFocus',
    SETTINGS_FORM_RESET_ON_SUCCESS: 'formResetOnSuccess',
    SETTINGS_REDIRECTION_TIMEOUT: 'redirectionTimeout',
    SETTINGS_HIDE_GLOBAL_MESSAGE_TIMEOUT: 'hideGlobalMessageTimeout',
    SETTINGS_FORM_DISABLE_AUTO_INIT: 'formDisableAutoInit',
    SETTINGS_FORM_SERVER_ERROR_MSG: 'formServerErrorMsg',
    SETTINGS_FORM_CAPTCHA_ERROR_MSG: 'formCaptchaErrorMsg',
    SETTINGS_FORM_MISCONFIGURED_MSG: 'formMisconfigured',
    CAPTCHA: 'captcha',
    CAPTCHA_SITE_KEY: 'site_key',
    CAPTCHA_IS_ENTERPRISE: 'isEnterprise',
    CAPTCHA_SUBMIT_ACTION: 'submitAction',
    CAPTCHA_INIT_ACTION: 'initAction',
    CAPTCHA_LOAD_ON_INIT: 'loadOnInit',
    CAPTCHA_HIDE_BADGE: 'hideBadge',
    ENRICHMENT: 'enrichment',
    ENRICHMENT_FORM_PREFILL: 'formPrefill',
    ENRICHMENT_EXPIRATION: 'expiration',
    ENRICHMENT_EXPIRATION_PREFILL: 'expirationPrefill',
    ENRICHMENT_ALLOWED: 'allowed',
    ENRICHMENT_ALLOWED_SMART: 'allowedSmart',
    GEOLOCATION: 'geolocation',
    TRACKING: 'tracking',
    STEPS: 'steps',
    STEPS_FLOW: 'flow',
    STEPS_CURRENT: 'current',
    STEPS_ITEMS: 'items',
    STEPS_ORDER: 'order',
    STEPS_ELEMENTS: 'elements',
    STEPS_IS_MULTIFLOW: 'isMultiflow',
    STEPS_PROGRESS_BAR_COUNT: 'progressBarCount',
    STEPS_PROGRESS_BAR_COUNT_INITIAL: 'progressBarCountInitial',
    STEPS_PROGRESS_BAR: 'progressBar',
    STEPS_ELEMENTS_PROGRESS_BAR: 'elementsProgressBar',
    ROUTES: 'routes',
    ATTRIBUTES: 'attributes',
    PARAMS: 'params',
    FIELD_TYPE: 'fieldType',
    EVENTS: 'events',
    SELECTORS: 'selectors',
    SELECTORS_ADMIN: 'selectorsAdmin',
    RESPONSE_OUTPUT_KEYS: 'responseOutputKeys',
    SUCCESS_REDIRECT_URL_KEYS: 'successRedirectUrlKey'
};
/**
 * Routes enum connected to enqueued object.
 * Used as a constant to be able to be reused on block editor because we don't have this state there.
 */ const ROUTES = esFormsLocalization?.restRoutes ?? {};
////////////////////////////////////////////////////////////////
// Initial states.
////////////////////////////////////////////////////////////////
/**
 * Set state initial window if it doesn't exist.
 *
 * @returns {void}
 */ function setStateWindow() {
    if (!window[prefix]) {
        window[prefix] = {};
    }
}
/**
 * Set state initial values.
 *
 * @returns {void}
 */ function setStateInitial() {
    setStateWindow();
    // Don't set initial state if it already exists.
    if (window[prefix].state && Object.keys(window[prefix].state).length) {
        return;
    }
    window[prefix].state = {};
    window[prefix].state = {
        [StateEnum.FORMS]: [],
        [StateEnum.CAPTCHA]: {},
        [StateEnum.ENRICHMENT]: {},
        [StateEnum.GEOLOCATION]: {},
        [StateEnum.SETTINGS]: {},
        [StateEnum.EVENTS]: {},
        [StateEnum.SELECTORS]: {},
        [StateEnum.SELECTORS_ADMIN]: {},
        [StateEnum.ATTRIBUTES]: {},
        [StateEnum.RESPONSE_OUTPUT_KEYS]: {},
        [StateEnum.SUCCESS_REDIRECT_URL_KEYS]: {},
        [StateEnum.PARAMS]: {},
        [StateEnum.FIELD_TYPE]: {},
        [StateEnum.CONFIG]: {},
        [StateEnum.ROUTES]: {}
    };
    // Selectors.
    for (const [key, item] of Object.entries(_manifest_json__WEBPACK_IMPORTED_MODULE_0__.enums.selectors ?? {})){
        setState([
            key
        ], item, StateEnum.SELECTORS);
    }
    // Selectors Admin.
    for (const [key, item] of Object.entries(_manifest_json__WEBPACK_IMPORTED_MODULE_0__.enums.selectorsAdmin ?? {})){
        setState([
            key
        ], item, StateEnum.SELECTORS_ADMIN);
    }
    // Response output keys.
    for (const [key, item] of Object.entries(_manifest_json__WEBPACK_IMPORTED_MODULE_0__.enums.responseOutputKeys ?? {})){
        setState([
            key
        ], item, StateEnum.RESPONSE_OUTPUT_KEYS);
    }
    // Success Redirect Url keys.
    for (const [key, item] of Object.entries(_manifest_json__WEBPACK_IMPORTED_MODULE_0__.enums.successRedirectUrlKeys ?? {})){
        setState([
            key
        ], item, StateEnum.SUCCESS_REDIRECT_URL_KEYS);
    }
    // Attributes.
    for (const [key, item] of Object.entries(_manifest_json__WEBPACK_IMPORTED_MODULE_0__.enums.attrs ?? {})){
        setState([
            key
        ], item, StateEnum.ATTRIBUTES);
    }
    // Params.
    for (const [key, item] of Object.entries(_manifest_json__WEBPACK_IMPORTED_MODULE_0__.enums.params ?? {})){
        setState([
            key
        ], item, StateEnum.PARAMS);
    }
    // Type Int.
    for (const [key, item] of Object.entries(_manifest_json__WEBPACK_IMPORTED_MODULE_0__.enums.events ?? {})){
        setState([
            key
        ], item, StateEnum.EVENTS);
    }
    // Type Int.
    for (const [key, item] of Object.entries(_manifest_json__WEBPACK_IMPORTED_MODULE_0__.enums.typeInternal ?? {})){
        setState([
            key
        ], item, StateEnum.FIELD_TYPE);
    }
    // Routes.
    for (const [key, item] of Object.entries(ROUTES)){
        setState([
            key
        ], item, StateEnum.ROUTES);
    }
    // Config.
    setState([
        StateEnum.IS_ADMIN
    ], esFormsLocalization.isAdmin, StateEnum.CONFIG);
    setState([
        StateEnum.NONCE
    ], esFormsLocalization.nonce, StateEnum.CONFIG);
    // Global settings.
    setState([
        StateEnum.SETTINGS_DISABLE_SCROLL_TO_GLOBAL_MSG_ON_SUCCESS
    ], Boolean(esFormsLocalization.formDisableScrollToGlobalMessageOnSuccess), StateEnum.SETTINGS);
    setState([
        StateEnum.SETTINGS_DISABLE_SCROLL_TO_FIELD_ON_ERROR
    ], Boolean(esFormsLocalization.formDisableScrollToFieldOnError), StateEnum.SETTINGS);
    setState([
        StateEnum.SETTINGS_DISABLE_SCROLL_TO_FIELD_ON_FOCUS
    ], Boolean(esFormsLocalization.formDisableScrollToFieldOnFocus), StateEnum.SETTINGS);
    setState([
        StateEnum.SETTINGS_FORM_RESET_ON_SUCCESS
    ], Boolean(esFormsLocalization.formResetOnSuccess), StateEnum.SETTINGS);
    setState([
        StateEnum.SETTINGS_REDIRECTION_TIMEOUT
    ], esFormsLocalization.redirectionTimeout ?? 600, StateEnum.SETTINGS);
    setState([
        StateEnum.SETTINGS_HIDE_GLOBAL_MESSAGE_TIMEOUT
    ], esFormsLocalization.hideGlobalMessageTimeout ?? 6000, StateEnum.SETTINGS);
    setState([
        StateEnum.SETTINGS_LABELS
    ], esFormsLocalization.labels ?? {}, StateEnum.SETTINGS);
    setState([
        StateEnum.SETTINGS_FORM_DISABLE_AUTO_INIT
    ], Boolean(esFormsLocalization.formDisableAutoInit), StateEnum.SETTINGS);
    setState([
        StateEnum.SETTINGS_FORM_SERVER_ERROR_MSG
    ], esFormsLocalization.formServerErrorMsg ?? '', StateEnum.SETTINGS);
    setState([
        StateEnum.SETTINGS_FORM_CAPTCHA_ERROR_MSG
    ], esFormsLocalization.formCaptchaErrorMsg ?? '', StateEnum.SETTINGS);
    setState([
        StateEnum.SETTINGS_FORM_MISCONFIGURED_MSG
    ], esFormsLocalization.formMisconfigured ?? '', StateEnum.SETTINGS);
    // Captcha.
    const captcha = esFormsLocalization.captcha ?? {};
    setState([
        StateEnum.IS_USED
    ], Boolean(captcha.isUsed), StateEnum.CAPTCHA);
    if (captcha.isUsed) {
        setState([
            StateEnum.CAPTCHA_SITE_KEY
        ], captcha.siteKey, StateEnum.CAPTCHA);
        setState([
            StateEnum.CAPTCHA_IS_ENTERPRISE
        ], Boolean(captcha.isEnterprise), StateEnum.CAPTCHA);
        setState([
            StateEnum.CAPTCHA_SUBMIT_ACTION
        ], captcha.submitAction, StateEnum.CAPTCHA);
        setState([
            StateEnum.CAPTCHA_INIT_ACTION
        ], captcha.initAction, StateEnum.CAPTCHA);
        setState([
            StateEnum.CAPTCHA_LOAD_ON_INIT
        ], Boolean(captcha.loadOnInit), StateEnum.CAPTCHA);
        setState([
            StateEnum.CAPTCHA_HIDE_BADGE
        ], Boolean(captcha.hideBadge), StateEnum.CAPTCHA);
    }
    // Geolocation.
    const geolocation = esFormsLocalization.geolocation ?? {};
    setState([
        StateEnum.IS_USED
    ], Boolean(geolocation.isUsed), StateEnum.GEOLOCATION);
    // Enrichment.
    const enrichment = esFormsLocalization.enrichment ?? {};
    setState([
        StateEnum.IS_USED
    ], Boolean(enrichment.isUsed), StateEnum.ENRICHMENT);
    if (enrichment.isUsed) {
        setState([
            StateEnum.IS_USED_LOCALSTORAGE
        ], isLocalStorageAvailable(), StateEnum.ENRICHMENT);
        setState([
            StateEnum.IS_USED_PREFILL
        ], Boolean(enrichment.isUsedPrefill), StateEnum.ENRICHMENT);
        setState([
            StateEnum.IS_USED_PREFILL_URL
        ], Boolean(enrichment.isUsedPrefillUrl), StateEnum.ENRICHMENT);
        setState([
            StateEnum.ENRICHMENT_EXPIRATION
        ], enrichment.expiration, StateEnum.ENRICHMENT);
        setState([
            StateEnum.ENRICHMENT_EXPIRATION_PREFILL
        ], enrichment.expirationPrefill, StateEnum.ENRICHMENT);
        setState([
            StateEnum.ENRICHMENT_ALLOWED
        ], Object.values(enrichment.allowed), StateEnum.ENRICHMENT);
        setState([
            StateEnum.ENRICHMENT_ALLOWED_SMART
        ], Object.values(enrichment.allowedSmart), StateEnum.ENRICHMENT);
        setState([
            StateEnum.NAME
        ], 'es-storage', StateEnum.ENRICHMENT);
    }
}
/**
 * Set state initial form values.
 *
 * @param {string} formId Form ID.
 *
 * @returns {void}
 */ function setStateFormInitial(formId) {
    setStateWindow();
    window[prefix].state[`form_${formId}`] = {};
    window[prefix].state[`form_${formId}`] = {
        [StateEnum.ELEMENTS]: {},
        [StateEnum.ELEMENTS_FIELDS]: {},
        [StateEnum.FORM]: {}
    };
    // Push only form ID if it doesn't exist.
    if (window[prefix].state[StateEnum.FORMS].indexOf(formId) === -1) {
        window[prefix].state[StateEnum.FORMS].push(formId);
    }
    let formElement = '';
    if (formId === 0) {
        formElement = document.querySelector(getStateSelector('form', true));
    } else {
        formElement = document.querySelector(`${getStateSelector('form', true)}[${getStateAttribute('formId')}="${formId}"]`);
    }
    setState([
        StateEnum.FORM,
        StateEnum.POST_ID
    ], formElement?.getAttribute(getStateAttribute('postId')), formId);
    setState([
        StateEnum.FORM,
        StateEnum.FORM_FID
    ], formElement?.getAttribute(getStateAttribute('formFid')), formId);
    setState([
        StateEnum.FORM,
        StateEnum.IS_LOADED
    ], false, formId);
    setState([
        StateEnum.FORM,
        StateEnum.IS_PROCESSING
    ], false, formId);
    setState([
        StateEnum.FORM,
        StateEnum.IS_ADMIN_SINGLE_SUBMIT
    ], false, formId);
    setState([
        StateEnum.FORM,
        StateEnum.ELEMENT
    ], formElement, formId);
    setState([
        StateEnum.FORM,
        StateEnum.TYPE
    ], formElement?.getAttribute(getStateAttribute('formType')), formId);
    setState([
        StateEnum.FORM,
        StateEnum.CUSTOM_NAME
    ], formElement?.getAttribute(getStateAttribute('formCustomName')), formId);
    setState([
        StateEnum.FORM,
        StateEnum.METHOD
    ], formElement?.getAttribute('method'), formId);
    setState([
        StateEnum.FORM,
        StateEnum.ACTION
    ], formElement?.getAttribute('action'), formId);
    setState([
        StateEnum.FORM,
        StateEnum.ACTION_EXTERNAL
    ], formElement?.getAttribute(getStateAttribute('actionExternal')), formId);
    setState([
        StateEnum.FORM,
        StateEnum.MULTISTEP_SKIP_SCROLL
    ], Boolean(formElement?.getAttribute(getStateAttribute('multistepSkipScroll'))), formId);
    setState([
        StateEnum.FORM,
        StateEnum.SECURE_DATA
    ], formElement?.getAttribute(getStateAttribute('formSecureData')), formId);
    setState([
        StateEnum.FORM,
        StateEnum.TYPE_SETTINGS
    ], formElement?.getAttribute(getStateAttribute('settingsType')), formId);
    setState([
        StateEnum.FORM,
        StateEnum.LOADER
    ], formElement?.querySelector(getStateSelector('loader', true)), formId);
    // Form settings
    setState([
        StateEnum.FORM,
        StateEnum.CONFIG,
        StateEnum.CONFIG_PHONE_DISABLE_PICKER
    ], Boolean(formElement?.getAttribute(getStateAttribute('phoneDisablePicker'))), formId);
    setState([
        StateEnum.FORM,
        StateEnum.CONFIG,
        StateEnum.CONFIG_USE_SINGLE_SUBMIT
    ], Boolean(formElement?.getAttribute(getStateAttribute('singleSubmit'))), formId);
    const globalMsg = formElement?.querySelector(getStateSelector('globalMsg', true));
    setState([
        StateEnum.FORM,
        StateEnum.GLOBAL_MSG,
        StateEnum.ELEMENT
    ], globalMsg, formId);
    setState([
        StateEnum.FORM,
        StateEnum.GLOBAL_MSG,
        StateEnum.HEADING_SUCCESS
    ], globalMsg?.getAttribute(getStateAttribute('globalMsgHeadingSuccess')), formId);
    setState([
        StateEnum.FORM,
        StateEnum.GLOBAL_MSG,
        StateEnum.HEADING_ERROR
    ], globalMsg?.getAttribute(getStateAttribute('globalMsgHeadingError')), formId);
    // Conditional tags
    setState([
        StateEnum.FORM,
        StateEnum.CONDITIONAL_TAGS_EVENTS
    ], {}, formId);
    setState([
        StateEnum.FORM,
        StateEnum.CONDITIONAL_TAGS_INNER_EVENTS
    ], {}, formId);
    setState([
        StateEnum.FORM,
        StateEnum.CONDITIONAL_TAGS_FORM
    ], JSON.parse(simpleDecode(formElement?.getAttribute(getStateAttribute('conditionalTags')) ?? '{}')), formId);
    setState([
        StateEnum.FORM,
        StateEnum.CONDITIONAL_TAGS_STATE_FORM_HIDE
    ], {}, formId);
    setState([
        StateEnum.FORM,
        StateEnum.CONDITIONAL_TAGS_STATE_FORM_SHOW
    ], {}, formId);
    setState([
        StateEnum.FORM,
        StateEnum.CONDITIONAL_TAGS_STATE_CT
    ], {}, formId);
    // Steps.
    setSteps(formElement, formId);
    const formFields = formElement?.querySelectorAll('input, select, textarea') ?? [];
    // Loop all fields.
    [
        ...formFields
    ].forEach((item)=>{
        const { value, name, type, disabled } = item;
        if (name === 'search_terms' || !name) {
            return;
        }
        const field = formElement.querySelector(`${getStateSelector('field', true)}[${getStateAttribute('fieldName')}="${name}"]`);
        const fieldType = field?.getAttribute(getStateAttribute('fieldType'));
        const fieldset = field?.closest('fieldset');
        // Make changes depending on the field type.
        switch(type){
            case 'radio':
            case 'checkbox':
            case 'rating':
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.INPUT
                ], '', formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.ITEMS,
                    value,
                    StateEnum.VALUE
                ], value, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.ITEMS,
                    value,
                    StateEnum.FIELD
                ], item.parentNode.parentNode, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.ITEMS,
                    value,
                    StateEnum.INPUT
                ], item, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.ITEMS,
                    value,
                    StateEnum.NAME
                ], name, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.IS_DISABLED,
                    value
                ], disabled, formId);
                if (type === 'radio' || type === 'rating') {
                    if (!getState([
                        StateEnum.ELEMENTS,
                        name,
                        StateEnum.INITIAL
                    ], formId)) {
                        setState([
                            StateEnum.ELEMENTS,
                            name,
                            StateEnum.INITIAL
                        ], item.checked ? value : '', formId);
                    }
                    if (!getState([
                        StateEnum.ELEMENTS,
                        name,
                        StateEnum.VALUE
                    ], formId)) {
                        setState([
                            StateEnum.ELEMENTS,
                            name,
                            StateEnum.VALUE
                        ], item.checked ? value : '', formId);
                    }
                    setState([
                        StateEnum.ELEMENTS,
                        name,
                        StateEnum.TRACKING
                    ], field.getAttribute(getStateAttribute('tracking')), formId);
                }
                if (type === 'checkbox') {
                    setState([
                        StateEnum.ELEMENTS,
                        name,
                        StateEnum.VALUE,
                        value
                    ], item.checked ? value : '', formId);
                    setState([
                        StateEnum.ELEMENTS,
                        name,
                        StateEnum.INITIAL,
                        value
                    ], item.checked ? value : '', formId);
                    setState([
                        StateEnum.ELEMENTS,
                        name,
                        StateEnum.TRACKING,
                        value
                    ], item.parentNode.parentNode.getAttribute(getStateAttribute('tracking')), formId);
                }
                break;
            case 'select-one':
            case 'select-multiple':
                const selectedValues = [
                    ...item.selectedOptions
                ].map((option)=>option?.value).filter((option)=>option !== '');
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.VALUE
                ], selectedValues, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.INITIAL
                ], selectedValues, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.IS_DISABLED
                ], disabled, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.INPUT
                ], item, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.CONFIG,
                    StateEnum.CONFIG_SELECT_USE_SEARCH
                ], Boolean(item.getAttribute(getStateAttribute('selectAllowSearch'))), formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.CONFIG,
                    StateEnum.CONFIG_SELECT_USE_MULTIPLE
                ], Boolean(item.getAttribute(getStateAttribute('selectIsMultiple'))), formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.TRACKING
                ], field.getAttribute(getStateAttribute('tracking')), formId);
                break;
            case 'tel':
                if (getState([
                    StateEnum.FORM,
                    StateEnum.CONFIG,
                    StateEnum.CONFIG_PHONE_DISABLE_PICKER
                ], formId)) {
                    setState([
                        StateEnum.ELEMENTS,
                        name,
                        StateEnum.INITIAL
                    ], {
                        prefix: '',
                        value: value
                    }, formId);
                    setState([
                        StateEnum.ELEMENTS,
                        name,
                        StateEnum.VALUE
                    ], {
                        prefix: '',
                        value: value
                    }, formId);
                } else {
                    const newPhoneValue = {
                        prefix: getState([
                            StateEnum.ELEMENTS,
                            name,
                            StateEnum.VALUE
                        ], formId)?.[0] ?? '',
                        value: value
                    };
                    setState([
                        StateEnum.ELEMENTS,
                        name,
                        StateEnum.INITIAL
                    ], newPhoneValue, formId);
                    setState([
                        StateEnum.ELEMENTS,
                        name,
                        StateEnum.VALUE
                    ], newPhoneValue, formId);
                }
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.INPUT
                ], item, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.IS_DISABLED
                ], disabled, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.INPUT_SELECT
                ], field.querySelector('select'), formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.TRACKING
                ], field.getAttribute(getStateAttribute('tracking')), formId);
                break;
            case 'date':
            case 'datetime-local':
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.INITIAL
                ], value, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.VALUE
                ], value, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.INPUT
                ], item, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.IS_DISABLED
                ], disabled, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.TRACKING
                ], field.getAttribute(getStateAttribute('tracking')), formId);
                break;
            case 'range':
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.INITIAL
                ], value, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.VALUE
                ], value, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.INPUT
                ], item, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.CUSTOM
                ], item?.nextElementSibling, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.IS_DISABLED
                ], disabled, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.RANGE_CURRENT
                ], field.querySelectorAll(getStateSelector('inputRangeCurrent', true)), formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.TRACKING
                ], field.getAttribute(getStateAttribute('tracking')), formId);
                break;
            case 'file':
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.INITIAL
                ], value, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.VALUE
                ], value, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.INPUT
                ], item, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.IS_DISABLED
                ], disabled, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.FILE_BUTTON
                ], field.querySelector(getStateSelector('fileButton', true)), formId);
                break;
            default:
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.INITIAL
                ], value, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.VALUE
                ], value, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.INPUT
                ], item, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.IS_DISABLED
                ], disabled, formId);
                setState([
                    StateEnum.ELEMENTS,
                    name,
                    StateEnum.TRACKING
                ], field?.getAttribute(getStateAttribute('tracking')), formId);
                if (fieldset) {
                    setState([
                        StateEnum.ELEMENTS,
                        fieldset.getAttribute(getStateAttribute('fieldName')),
                        StateEnum.CUSTOM
                    ], item, formId);
                }
                if (field?.getAttribute(getStateAttribute('fieldPreventSubmit'))) {
                    setState([
                        StateEnum.ELEMENTS,
                        name,
                        StateEnum.IS_DISABLED
                    ], Boolean(field.getAttribute(getStateAttribute('fieldPreventSubmit'))), formId);
                }
                break;
        }
        setState([
            StateEnum.ELEMENTS,
            name,
            StateEnum.TYPE_FIELD
        ], fieldType, formId);
        setState([
            StateEnum.ELEMENTS,
            name,
            StateEnum.HAS_ERROR
        ], false, formId);
        setState([
            StateEnum.ELEMENTS,
            name,
            StateEnum.HAS_CHANGED
        ], false, formId);
        setState([
            StateEnum.ELEMENTS,
            name,
            StateEnum.LOADED
        ], false, formId);
        setState([
            StateEnum.ELEMENTS,
            name,
            StateEnum.NAME
        ], name, formId);
        setState([
            StateEnum.ELEMENTS,
            name,
            StateEnum.FIELD
        ], field, formId);
        setState([
            StateEnum.ELEMENTS,
            name,
            StateEnum.FIELDSET
        ], fieldset, formId);
        setState([
            StateEnum.ELEMENTS,
            name,
            StateEnum.ERROR
        ], field?.querySelector(getStateSelector('error', true)), formId);
        setState([
            StateEnum.ELEMENTS,
            name,
            StateEnum.IS_ADMIN_SINGLE_SUBMIT
        ], item?.classList?.contains(getStateSelector('submitSingle', true).substring(1)), formId);
        setState([
            StateEnum.ELEMENTS,
            name,
            StateEnum.TYPE_CUSTOM
        ], field?.getAttribute(getStateAttribute('fieldTypeCustom')), formId);
        setState([
            StateEnum.ELEMENTS,
            name,
            StateEnum.SAVE_AS_JSON
        ], Boolean(item.getAttribute(getStateAttribute('saveAsJson'))), formId);
    });
    // Loop all fields for conditional tags later because we need to have all state set.
    for (const item of Object.values(formFields)){
        const { value, name, type } = item;
        if (name === 'search_terms') {
            continue;
        }
        const field = formElement.querySelector(`${getStateSelector('field', true)}[${getStateAttribute('fieldName')}="${name}"]`);
        if (type === 'radio' || type === 'checkbox') {
            setStateConditionalTagsItems(item.parentNode.parentNode.getAttribute(getStateAttribute('conditionalTags')), name, value, formId);
        }
        if (type === 'select-one' || type === 'select-multiple') {
            [
                ...item?.options
            ]?.map((option)=>{
                setStateConditionalTagsItems(option.getAttribute(getStateAttribute('conditionalTags')), name, option.value, formId);
            });
        }
        // Conditional tags.
        if (field) {
            setStateConditionalTags(field, name, false, formId);
        }
    }
    const customFields = formElement?.querySelectorAll(getStateSelector('fieldNoFormsBlock', true)) ?? [];
    // Loop all fields for conditional tags later because we need to have all state set beforehand.
    [
        ...customFields
    ].forEach((field)=>{
        const name = field.getAttribute(getStateAttribute('fieldName'));
        // Conditional tags.
        if (name) {
            setState([
                StateEnum.ELEMENTS_FIELDS,
                name,
                StateEnum.NAME
            ], name, formId);
            setState([
                StateEnum.ELEMENTS_FIELDS,
                name,
                StateEnum.FIELD
            ], field, formId);
            setStateConditionalTags(field, name, true, formId);
        }
    });
}
/**
 * Set state for steps.
 *
 * @param {object} formElement Form element.
 * @param {string} formId Form ID.
 *
 * * @returns {void}
 */ function setSteps(formElement, formId) {
    const steps = formElement?.querySelectorAll(getStateSelector('step', true));
    setState([
        StateEnum.FORM,
        StateEnum.STEPS,
        StateEnum.IS_USED
    ], false, formId);
    if (steps?.length) {
        setState([
            StateEnum.FORM,
            StateEnum.STEPS,
            StateEnum.IS_USED
        ], true, formId);
        setState([
            StateEnum.FORM,
            StateEnum.STEPS,
            StateEnum.STEPS_FLOW
        ], [], formId);
        setState([
            StateEnum.FORM,
            StateEnum.STEPS,
            StateEnum.STEPS_CURRENT
        ], '', formId);
        setState([
            StateEnum.FORM,
            StateEnum.STEPS,
            StateEnum.STEPS_ITEMS
        ], {}, formId);
        setState([
            StateEnum.FORM,
            StateEnum.STEPS,
            StateEnum.STEPS_ORDER
        ], [], formId);
        setState([
            StateEnum.FORM,
            StateEnum.STEPS,
            StateEnum.STEPS_ELEMENTS
        ], {}, formId);
        setState([
            StateEnum.FORM,
            StateEnum.STEPS,
            StateEnum.STEPS_IS_MULTIFLOW
        ], false, formId);
        const stepsOrder = [];
        Object.values(steps).forEach((item, index)=>{
            const stepFields = item?.querySelectorAll(getStateSelector('field', true));
            const stepId = String(item.getAttribute(getStateAttribute('stepId')));
            const stepOutput = [];
            stepFields.forEach((stepField)=>{
                const stepFieldName = stepField.getAttribute(getStateAttribute('fieldName'));
                if (stepFieldName) {
                    stepOutput.push(stepFieldName);
                }
            });
            setState([
                StateEnum.FORM,
                StateEnum.STEPS,
                StateEnum.STEPS_ELEMENTS,
                stepId
            ], item, formId);
            setState([
                StateEnum.FORM,
                StateEnum.STEPS,
                StateEnum.STEPS_ITEMS,
                stepId
            ], stepOutput, formId);
            if (index === 0) {
                setState([
                    StateEnum.FORM,
                    StateEnum.STEPS,
                    StateEnum.STEPS_CURRENT
                ], stepId, formId);
            }
            if (stepFields) {
                stepsOrder.push(stepId);
            }
        });
        setState([
            StateEnum.FORM,
            StateEnum.STEPS,
            StateEnum.STEPS_ORDER
        ], stepsOrder, formId);
        const stepsProgressBarMultiflow = formElement.querySelector(getStateSelector('stepProgressBarMultiflow', true));
        if (stepsProgressBarMultiflow) {
            setState([
                StateEnum.FORM,
                StateEnum.STEPS,
                StateEnum.STEPS_PROGRESS_BAR
            ], stepsProgressBarMultiflow, formId);
            setState([
                StateEnum.FORM,
                StateEnum.STEPS,
                StateEnum.STEPS_PROGRESS_BAR_COUNT
            ], stepsProgressBarMultiflow?.children?.length, formId);
            setState([
                StateEnum.FORM,
                StateEnum.STEPS,
                StateEnum.STEPS_PROGRESS_BAR_COUNT_INITIAL
            ], stepsProgressBarMultiflow?.children?.length, formId);
            setState([
                StateEnum.FORM,
                StateEnum.STEPS,
                StateEnum.STEPS_IS_MULTIFLOW
            ], true, formId);
        }
        const stepsProgressBar = formElement.querySelector(getStateSelector('stepProgressBar', true));
        if (stepsProgressBar) {
            setState([
                StateEnum.FORM,
                StateEnum.STEPS,
                StateEnum.STEPS_PROGRESS_BAR
            ], stepsProgressBar, formId);
            setState([
                StateEnum.FORM,
                StateEnum.STEPS,
                StateEnum.STEPS_ELEMENTS_PROGRESS_BAR
            ], {}, formId);
            [
                ...stepsProgressBar.children
            ].forEach((item)=>{
                const stepId = item.getAttribute(getStateAttribute('stepId'));
                setState([
                    StateEnum.FORM,
                    StateEnum.STEPS,
                    StateEnum.STEPS_ELEMENTS_PROGRESS_BAR,
                    stepId
                ], item, formId);
            });
        }
    }
}
/**
 * Set state values when the field changes.
 *
 * @param {object} item Item/field to check.
 * @param {string} formId Form ID.
 *
 * @returns {void}
 */ function setStateValues(name, value, formId) {
    setState([
        StateEnum.ELEMENTS,
        name,
        StateEnum.HAS_CHANGED
    ], true, formId);
    setState([
        StateEnum.ELEMENTS,
        name,
        StateEnum.VALUE
    ], value, formId);
}
/**
 * Set state conditional tags on one field.
 *
 * @param {object} field Field object.
 * @param {string} name Field name.
 * @param {boolean} isNoneFormBlock Is none form block.
 * @param {string} formId Form ID.
 *
 * @returns {void}
 */ function setStateConditionalTags(field, name, isNoneFormBlock = false, formId) {
    const conditionalTags = field?.getAttribute(getStateAttribute('conditionalTags'));
    const parentStorage = isNoneFormBlock ? StateEnum.ELEMENTS_FIELDS : StateEnum.ELEMENTS;
    setState([
        parentStorage,
        name,
        StateEnum.CONDITIONAL_TAGS,
        StateEnum.TAGS_DEFAULTS
    ], _manifest_json__WEBPACK_IMPORTED_MODULE_0__.comparatorActions.SHOW, formId);
    setState([
        parentStorage,
        name,
        StateEnum.CONDITIONAL_TAGS,
        StateEnum.TAGS
    ], [], formId);
    setState([
        parentStorage,
        name,
        StateEnum.CONDITIONAL_TAGS,
        StateEnum.TAGS_REF
    ], [], formId);
    if (!conditionalTags) {
        return;
    }
    const tag = JSON.parse(simpleDecode(conditionalTags));
    // Check if fields exist and remove conditional tags if not.
    // This can happen if the user deletes a field and the conditional tag is still there on other field.
    const output = tag[1].map((item)=>item.filter((inner)=>{
            const itemName = inner[0] ?? '';
            return itemName !== '' && getState([
                StateEnum.ELEMENTS,
                itemName
            ], formId);
        })).filter((outputInner)=>outputInner.length > 0);
    if (!output.length) {
        return;
    }
    setState([
        parentStorage,
        name,
        StateEnum.CONDITIONAL_TAGS,
        StateEnum.TAGS_DEFAULTS
    ], tag[0], formId);
    setState([
        parentStorage,
        name,
        StateEnum.CONDITIONAL_TAGS,
        StateEnum.TAGS
    ], output, formId);
    setStateConditionalTagsInner(name, formId, output, isNoneFormBlock);
}
/**
 * Set state conditional tags inner items on one field.
 *
 * @param {object} conditionalTags Field object.
 * @param {string} name Field name.
 * @param {string} innerName Conditional tag inner name.
 * @param {string} formId Form ID.
 *
 * @returns {void}
 */ function setStateConditionalTagsItems(conditionalTags, name, innerName, formId) {
    if (!innerName) {
        return;
    }
    setState([
        StateEnum.ELEMENTS,
        name,
        StateEnum.CONDITIONAL_TAGS_INNER,
        innerName,
        StateEnum.TAGS_DEFAULTS
    ], _manifest_json__WEBPACK_IMPORTED_MODULE_0__.comparatorActions.SHOW, formId);
    setState([
        StateEnum.ELEMENTS,
        name,
        StateEnum.CONDITIONAL_TAGS_INNER,
        innerName,
        StateEnum.TAGS
    ], [], formId);
    setState([
        StateEnum.ELEMENTS,
        name,
        StateEnum.CONDITIONAL_TAGS_INNER,
        innerName,
        StateEnum.TAGS_REF
    ], [], formId);
    if (!conditionalTags) {
        return;
    }
    const tag = JSON.parse(simpleDecode(conditionalTags));
    // Check if fields exist and remove conditional tags if not.
    // This can happen if the user deletes a field and the conditional tag is still there on other field.
    const output = tag[1].map((item)=>item.filter((inner)=>{
            const itemName = inner[0] ?? '';
            return itemName !== '' && getState([
                StateEnum.ELEMENTS,
                itemName
            ], formId);
        })).filter((outputInner)=>outputInner.length > 0);
    if (!output.length) {
        return;
    }
    setState([
        StateEnum.ELEMENTS,
        name,
        StateEnum.CONDITIONAL_TAGS_INNER,
        innerName,
        StateEnum.TAGS_DEFAULTS
    ], tag[0], formId);
    setState([
        StateEnum.ELEMENTS,
        name,
        StateEnum.CONDITIONAL_TAGS_INNER,
        innerName,
        StateEnum.TAGS
    ], output, formId);
    setStateConditionalTagsInner(name, formId, output, false, innerName);
}
/**
 * Set state conditional tags inner item on one field.
 *
 * @param {string} name Field name.
 * @param {string} formId Form ID.
 * @param {array} tags Tags array.
 * @param {boolean} isNoneFormBlock Is none form block.
 * @param {string} innerName Conditional tag inner name.
 *
 * @returns {void}
 */ function setStateConditionalTagsInner(name, formId, tags, isNoneFormBlock = false, innerName = '') {
    const refOutput = [];
    const parentStorage = isNoneFormBlock ? StateEnum.ELEMENTS_FIELDS : StateEnum.ELEMENTS;
    const isInner = Boolean(innerName);
    const events = isInner ? getState([
        StateEnum.FORM,
        StateEnum.CONDITIONAL_TAGS_INNER_EVENTS
    ], formId) : getState([
        StateEnum.FORM,
        StateEnum.CONDITIONAL_TAGS_EVENTS
    ], formId);
    const eventsOutput = {
        ...events ?? {}
    };
    tags.forEach((item)=>{
        refOutput.push(Array(item.length).fill(false));
        // Loop inner fields.
        item.forEach((inner)=>{
            eventsOutput[inner[0]] = [
                ...eventsOutput[inner[0]] ?? [],
                isInner ? `${name}---${innerName}` : name
            ];
        });
    });
    if (isInner) {
        setState([
            StateEnum.FORM,
            StateEnum.CONDITIONAL_TAGS_INNER_EVENTS
        ], eventsOutput, formId);
        setState([
            parentStorage,
            name,
            StateEnum.CONDITIONAL_TAGS_INNER,
            innerName,
            StateEnum.TAGS_REF
        ], refOutput, formId);
    } else {
        setState([
            StateEnum.FORM,
            StateEnum.CONDITIONAL_TAGS_EVENTS
        ], eventsOutput, formId);
        setState([
            parentStorage,
            name,
            StateEnum.CONDITIONAL_TAGS,
            StateEnum.TAGS_REF
        ], refOutput, formId);
    }
}
////////////////////////////////////////////////////////////////
// Helpers.
////////////////////////////////////////////////////////////////
/**
 * Set state helper.
 *
 * @param {array} keyArray Array of keys of object.
 * @param {mixed} value Any mixed value to store.
 * @param {string} formId Form Id.
 *
 * @returns {void}
 */ function setState(keyArray, value, formId) {
    const formKey = isNaN(formId) ? formId : `form_${formId}`;
    let stateObject = window[prefix].state[formKey];
    keyArray.forEach((key, index)=>{
        if (index === keyArray.length - 1) {
            stateObject[key] = value;
        } else {
            stateObject[key] = stateObject[key] || {};
            stateObject = stateObject[key];
        }
    });
    if (keyArray.length > 1) {
        window[prefix].state[formKey] = {
            ...window[prefix].state[formKey],
            ...stateObject[keyArray[0]]
        };
    } else {
        window[prefix].state[formKey] = {
            ...window[prefix].state[formKey]
        };
    }
}
/**
 * Remove form state helper.
 *
 * @param {string} formId Form Id.
 *
 * @returns {void}
 */ function removeStateForm(formId) {
    const { state } = window[prefix];
    if (state && `form_${formId}` in state) {
        delete state[`form_${formId}`];
        window[prefix].state = {
            ...state
        };
    }
    const index = state[StateEnum.FORMS].indexOf(formId);
    const forms = state[StateEnum.FORMS];
    if (index > -1) {
        forms.splice(index, 1);
        window[prefix].state[StateEnum.FORMS] = [
            ...forms
        ];
    }
}
/**
 * Get state helper.
 *
 * @param {array} keys Array of keys of object.
 * @param {string} formId Form Id.
 *
 * @returns {mixed}
 */ function getState(keys, formId) {
    const formKey = isNaN(formId) ? formId : `form_${formId}`;
    let stateObject = window?.[prefix]?.state?.[formKey];
    if (!stateObject) {
        return undefined;
    }
    keys.forEach((key)=>{
        stateObject = stateObject?.[key];
        if (!stateObject) {
            return undefined;
        }
    });
    return stateObject;
}
/**
 * Get state top level key.
 *
 * @param {string} name Name key to get.
 *
 * @returns {mixed}
 */ function getStateTop(name) {
    return window?.[prefix]?.state?.[name];
}
/**
 * Get state event name with prefix.
 *
 * @param {string} name Name key to get.
 *
 * @returns {string}
 */ function getStateEvent(name) {
    return getStateTop(StateEnum.EVENTS)[name];
}
/**
 * Get state route name.
 *
 * @param {string} name Name key to get.
 *
 * @returns {string}
 */ function getStateRoute(name) {
    return getStateTop(StateEnum.ROUTES)[name];
}
/**
 * Get state selector.
 *
 * @param {string} name Name key to get.
 *
 * @returns {string}
 */ function getStateResponseOutputKey(name) {
    return getStateTop(StateEnum.RESPONSE_OUTPUT_KEYS)[name];
}
/**
 * Get state selector.
 *
 * @param {string} name Name key to get.
 * @param {boolean} usePrefix Use prefix.
 *
 * @returns {string}
 */ function getStateSelector(name, usePrefix = false) {
    return usePrefix ? `.${getStateTop(StateEnum.SELECTORS)[name]}` : getStateTop(StateEnum.SELECTORS)[name];
}
/**
 * Get state selector admin.
 *
 * @param {string} name Name key to get.
 * @param {boolean} usePrefix Use prefix.
 *
 * @returns {string}
 */ function getStateSelectorAdmin(name, usePrefix = false) {
    return usePrefix ? `.${getStateTop(StateEnum.SELECTORS_ADMIN)[name]}` : getStateTop(StateEnum.SELECTORS_ADMIN)[name];
}
/**
 * Get state attribute.
 *
 * @returns {string}
 */ function getStateAttribute(name) {
    return getStateTop(StateEnum.ATTRIBUTES)[name];
}
/**
 * Get state field type.
 *
 * @returns {string}
 */ function getStateFieldType(name) {
    return getStateTop(StateEnum.FIELD_TYPE)[name];
}
/**
 * Get state Params.
 *
 * @returns {string}
 */ function getStateParam(name) {
    return getStateTop(StateEnum.PARAMS)[name];
}
/**
 * Get state Success Redirect Url Key.
 *
 * @returns {string}
 */ function getStateSuccessRedirectUrlKey(name) {
    return getStateTop(StateEnum.SUCCESS_REDIRECT_URL_KEYS)[name];
}
/**
 * Get rest api url link.
 *
 * @param {string} value Value to get
 * @param {bool} isPartial Is relative or absolute url.
 *
 * @returns {string}
 */ function getRestUrl(value, isPartial = false) {
    const prefix = isPartial ? ROUTES?.prefixProject : ROUTES?.prefix;
    const url = prefix.replace(/\/$/, ''); // Remove trailing slash.
    const suffix = ROUTES?.[value].replace(/^\/+/, ''); // Remove leading slash.
    return `${url}/${suffix}`;
}
/**
 * Get rest api url link with integration prefix.
 *
 * @param {string} type Integration type.
 * @param {string} value Value to get
 * @param {bool} isPartial Is relative or absolute url.
 * @param {bool} checkRef Check if value is reference.
 *
 * @returns {string}
 */ function getRestUrlByType(type, value, isPartial = false, checkRef = false) {
    const prefix = isPartial ? ROUTES?.prefixProject : ROUTES?.prefix;
    const newVal = checkRef ? ROUTES?.[value] : value;
    const url = prefix.replace(/\/$/, ''); // Remove trailing slash.
    const suffix = newVal.replace(/^\/+/, ''); // Remove leading slash.
    const typePrefix = ROUTES?.[type].replace(/^\/|\/$/g, ''); // Remove leading and trailing slash.
    return `${url}/${typePrefix}/${suffix}`;
}
/**
 * Simple decode.
 *
 * @param {string} str String to decode.
 *
 * @returns {string}
 */ function simpleDecode(str) {
    return str.replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
}
////////////////////////////////////////////////////////////////
// Block editor only.
////////////////////////////////////////////////////////////////
/**
 * Get utils icons, used in the block editor only.
 *
 * @returns {string}
 */ function getUtilsIcons(name) {
    return _manifest_json__WEBPACK_IMPORTED_MODULE_0__?.icons?.[name];
}
////////////////////////////////////////////////////////////////
// Internal helpers.
////////////////////////////////////////////////////////////////
/**
 * Check if local storage is available.
 *
 * @returns {boolean}
 */ function isLocalStorageAvailable() {
    const test = 'test';
    try {
        localStorage.setItem(test, test);
        localStorage.removeItem(test);
        return true;
    } catch (e) {
        return false;
    }
}


/***/ }),

/***/ "./src/Blocks/components/form/assets/state.js":
/*!****************************************************!*\
  !*** ./src/Blocks/components/form/assets/state.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   State: () => (/* binding */ State)
/* harmony export */ });
/* harmony import */ var _state_init__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./state-init */ "./src/Blocks/components/form/assets/state-init.js");

class State {
    constructor(){
        // Set all public methods.
        this.publicMethods();
    }
    ////////////////////////////////////////////////////////////////
    // Helpers getters.
    ////////////////////////////////////////////////////////////////
    setState = (keyArray, value, formId)=>{
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.setState)(keyArray, value, formId);
    };
    getState = (keys, formId)=>{
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)(keys, formId);
    };
    ////////////////////////////////////////////////////////////////
    // Config getters.
    ////////////////////////////////////////////////////////////////
    getStateConfigIsAdmin = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_ADMIN
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONFIG);
    };
    getStateConfigNonce = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.NONCE
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONFIG);
    };
    ////////////////////////////////////////////////////////////////
    // Form getters.
    ////////////////////////////////////////////////////////////////
    getStateForms = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getStateTop)(_state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORMS);
    };
    getStateForm = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM
        ], formId);
    };
    getStateFormElement = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENT
        ], formId);
    };
    getStateFormPostId = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.POST_ID
        ], formId);
    };
    getStateFormFid = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM_FID
        ], formId);
    };
    getStateFormCustomName = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CUSTOM_NAME
        ], formId);
    };
    getStateFormIsAdminSingleSubmit = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_ADMIN_SINGLE_SUBMIT
        ], formId);
    };
    getStateFormType = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.TYPE
        ], formId);
    };
    getStateFormMethod = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.METHOD
        ], formId);
    };
    getStateFormAction = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ACTION
        ], formId);
    };
    getStateFormActionExternal = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ACTION_EXTERNAL
        ], formId);
    };
    getStateFormMultistepSkipScroll = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.MULTISTEP_SKIP_SCROLL
        ], formId);
    };
    getStateFormSecureData = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SECURE_DATA
        ], formId);
    };
    getStateFormTypeSettings = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.TYPE_SETTINGS
        ], formId);
    };
    getStateFormLoader = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.LOADER
        ], formId);
    };
    getStateFormIsProcessing = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_PROCESSING
        ], formId);
    };
    setStateFormIsLoaded = (value, formId)=>{
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.setState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_LOADED
        ], value, formId);
    };
    setStateFormIsProcessing = (value, formId)=>{
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.setState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_PROCESSING
        ], value, formId);
    };
    setStateFormIsAdminSingleSubmit = (value, formId)=>{
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.setState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_ADMIN_SINGLE_SUBMIT
        ], value, formId);
    };
    ////////////////////////////////////////////////////////////////
    // Conditional tags getters.
    ////////////////////////////////////////////////////////////////
    getStateFormConditionalTagsEvents = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS_EVENTS
        ], formId);
    };
    getStateFormConditionalTagsStateHideForms = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS_STATE_FORM_HIDE
        ], formId);
    };
    getStateFormConditionalTagsStateCt = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS_STATE_CT
        ], formId);
    };
    getStateFormConditionalTagsInnerEvents = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS_INNER_EVENTS
        ], formId);
    };
    getStateFormConditionalTagsForm = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS_FORM
        ], formId);
    };
    ////////////////////////////////////////////////////////////////
    // Global msg getters.
    ////////////////////////////////////////////////////////////////
    getStateFormGlobalMsgElement = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.GLOBAL_MSG,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENT
        ], formId);
    };
    getStateFormGlobalMsgHeadingSuccess = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.GLOBAL_MSG,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.HEADING_SUCCESS
        ], formId);
    };
    getStateFormGlobalMsgHeadingError = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.GLOBAL_MSG,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.HEADING_ERROR
        ], formId);
    };
    ////////////////////////////////////////////////////////////////
    // Config getters.
    ////////////////////////////////////////////////////////////////
    getStateFormConfigPhoneDisablePicker = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONFIG,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONFIG_PHONE_DISABLE_PICKER
        ], formId);
    };
    getStateFormConfigUseSingleSubmit = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONFIG,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONFIG_USE_SINGLE_SUBMIT
        ], formId);
    };
    ////////////////////////////////////////////////////////////////
    // Steps getters.
    ////////////////////////////////////////////////////////////////
    getStateFormStepsFlow = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS_FLOW
        ], formId);
    };
    getStateFormStepsCurrent = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS_CURRENT
        ], formId);
    };
    getStateFormStepsFirstStep = (formId)=>{
        const items = (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS_ORDER
        ], formId);
        return typeof items !== 'undefined' ? items[0] : '';
    };
    getStateFormStepsLastStep = (formId)=>{
        const items = (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS_ORDER
        ], formId);
        return typeof items !== 'undefined' ? items?.[items?.length - 1] : '';
    };
    getStateFormStepsItem = (stepId, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS_ITEMS,
            stepId
        ], formId);
    };
    getStateFormStepsItems = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS_ITEMS
        ], formId);
    };
    getStateFormStepsOrder = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS_ORDER
        ], formId);
    };
    getStateFormStepsElements = (formId)=>{
        const items = (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS_ELEMENTS
        ], formId);
        return items ? Object.values(items) : [];
    };
    getStateFormStepsElement = (stepId, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS_ELEMENTS,
            stepId
        ], formId);
    };
    getStateFormStepsElementsProgressBar = (formId)=>{
        const items = (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS_ELEMENTS_PROGRESS_BAR
        ], formId);
        return items ? Object.values(items) : [];
    };
    getStateFormStepsElementProgressBar = (stepId, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS_ELEMENTS_PROGRESS_BAR,
            stepId
        ], formId);
    };
    getStateFormStepsProgressBar = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS_PROGRESS_BAR
        ], formId);
    };
    getStateFormStepsProgressBarCountInitial = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS_PROGRESS_BAR_COUNT_INITIAL
        ], formId);
    };
    getStateFormStepsProgressBarCount = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS_PROGRESS_BAR_COUNT
        ], formId);
    };
    getStateFormStepsIsUsed = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_USED
        ], formId);
    };
    getStateFormStepsIsMultiflow = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS_IS_MULTIFLOW
        ], formId);
    };
    setStateFormStepsCurrent = (value, formId)=>{
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.setState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS_CURRENT
        ], value, formId);
    };
    setStateFormStepsFlow = (value, formId)=>{
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.setState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS_FLOW
        ], value, formId);
    };
    setStateFormStepsProgressBarCount = (value, formId)=>{
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.setState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS_PROGRESS_BAR_COUNT
        ], value, formId);
    };
    setStateFormStepsProgressBarCountInitial = (value, formId)=>{
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.setState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FORM,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.STEPS_PROGRESS_BAR_COUNT_INITIAL
        ], value, formId);
    };
    ////////////////////////////////////////////////////////////////
    // Settings getters.
    ////////////////////////////////////////////////////////////////
    getStateSettingsDisableScrollToGlobalMsgOnSuccess = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS_DISABLE_SCROLL_TO_GLOBAL_MSG_ON_SUCCESS
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS);
    };
    getStateSettingsDisableScrollToFieldOnError = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS_DISABLE_SCROLL_TO_FIELD_ON_ERROR
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS);
    };
    getStateSettingsDisableScrollToFieldOnFocus = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS_DISABLE_SCROLL_TO_FIELD_ON_FOCUS
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS);
    };
    getStateSettingsResetOnSuccess = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS_FORM_RESET_ON_SUCCESS
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS);
    };
    getStateSettingsRedirectionTimeout = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS_REDIRECTION_TIMEOUT
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS);
    };
    getStateSettingsHideGlobalMessageTimeout = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS_HIDE_GLOBAL_MESSAGE_TIMEOUT
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS);
    };
    getStateSettingsLabels = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS_LABELS
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS);
    };
    getStateSettingsFormDisableAutoInit = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS_FORM_DISABLE_AUTO_INIT
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS);
    };
    getStateSettingsFormServerErrorMsg = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS_FORM_SERVER_ERROR_MSG
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS);
    };
    getStateSettingsFormCaptchaErrorMsg = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS_FORM_CAPTCHA_ERROR_MSG
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS);
    };
    getStateSettingsFormMisconfiguredMsg = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS_FORM_MISCONFIGURED_MSG
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SETTINGS);
    };
    ////////////////////////////////////////////////////////////////
    // Element getters.
    ////////////////////////////////////////////////////////////////
    getStateElementByTypeField = (type, formId)=>{
        const intType = this.getStateFieldType(type);
        return this.getStateFilteredByKey(_state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS, _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.TYPE_FIELD, intType, formId);
    };
    getStateElementByHasError = (type, formId)=>{
        return this.getStateFilteredByKey(_state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS, _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.HAS_ERROR, type, formId);
    };
    getStateElementByLoaded = (type, formId)=>{
        return this.getStateFilteredByKey(_state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS, _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.LOADED, type, formId);
    };
    getStateElementsObject = (formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS
        ], formId);
    };
    getStateElements = (formId)=>{
        const items = this.getStateElementsObject(formId);
        return items ? Object.entries(items) : [];
    };
    getStateElementsFields = (formId)=>{
        const items = (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS_FIELDS
        ], formId);
        return items ? Object.entries(items) : [];
    };
    getStateElementConditionalTagsDefaults = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.TAGS_DEFAULTS
        ], formId);
    };
    getStateElementFieldConditionalTagsDefaults = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS_FIELDS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.TAGS_DEFAULTS
        ], formId);
    };
    getStateElementConditionalTagsDefaultsInner = (name, innerName, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS_INNER,
            innerName,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.TAGS_DEFAULTS
        ], formId);
    };
    getStateElementConditionalTagsRef = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.TAGS_REF
        ], formId);
    };
    getStateElementFieldConditionalTagsRef = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS_FIELDS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.TAGS_REF
        ], formId);
    };
    getStateElementConditionalTagsRefInner = (name, innerName, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS_INNER,
            innerName,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.TAGS_REF
        ], formId);
    };
    getStateElementConditionalTagsTags = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.TAGS
        ], formId);
    };
    getStateElementFieldConditionalTagsTags = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS_FIELDS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.TAGS
        ], formId);
    };
    getStateElementConditionalTagsTagsInner = (name, innerName, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONDITIONAL_TAGS_INNER,
            innerName,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.TAGS
        ], formId);
    };
    getStateElementConfig = (name, type, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONFIG,
            type
        ], formId);
    };
    getStateElementField = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FIELD
        ], formId);
    };
    getStateElementFieldset = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FIELDSET
        ], formId);
    };
    getStateElementIsDisabled = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_DISABLED
        ], formId);
    };
    getStateElementLoaded = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.LOADED
        ], formId);
    };
    getStateElementTypeField = (name, formId)=>{
        return this.getStateFieldType((0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.TYPE_FIELD
        ], formId));
    };
    getStateElementTypeCustom = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.TYPE_CUSTOM
        ], formId);
    };
    getStateElementCustom = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CUSTOM
        ], formId);
    };
    getStateElementIsSingleSubmit = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_ADMIN_SINGLE_SUBMIT
        ], formId);
    };
    getStateElementSaveAsJson = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.SAVE_AS_JSON
        ], formId);
    };
    getStateElementInitial = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.INITIAL
        ], formId);
    };
    getStateElementItems = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ITEMS
        ], formId);
    };
    getStateElementItem = (name, value, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ITEMS,
            value
        ], formId);
    };
    getStateElementInput = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.INPUT
        ], formId);
    };
    getStateElementRangeCurrent = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.RANGE_CURRENT
        ], formId);
    };
    getStateElementItemsInput = (name, nameItem, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ITEMS,
            nameItem,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.INPUT
        ], formId);
    };
    getStateElementItemsField = (name, nameItem, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ITEMS,
            nameItem,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FIELD
        ], formId);
    };
    getStateElementValue = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.VALUE
        ], formId);
    };
    getStateElementError = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ERROR
        ], formId);
    };
    getStateElementTracking = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.TRACKING
        ], formId);
    };
    getStateElementInputSelect = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.INPUT_SELECT
        ], formId);
    };
    getStateElementHasChanged = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.HAS_CHANGED
        ], formId);
    };
    getStateElementFileButton = (name, formId)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.FILE_BUTTON
        ], formId);
    };
    setStateElementValue = (name, value, formId)=>{
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.setState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.VALUE
        ], value, formId);
    };
    setStateElementLoaded = (name, value, formId)=>{
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.setState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.LOADED
        ], value, formId);
    };
    setStateElementInitial = (name, value, formId)=>{
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.setState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.INITIAL
        ], value, formId);
    };
    setStateElementCustom = (name, value, formId)=>{
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.setState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CUSTOM
        ], value, formId);
    };
    setStateElementHasError = (name, value, formId)=>{
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.setState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ELEMENTS,
            name,
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.HAS_ERROR
        ], value, formId);
    };
    ////////////////////////////////////////////////////////////////
    // Captcha getters.
    ////////////////////////////////////////////////////////////////
    getStateCaptchaIsUsed = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_USED
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CAPTCHA);
    };
    getStateCaptchaSiteKey = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CAPTCHA_SITE_KEY
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CAPTCHA);
    };
    getStateCaptchaIsEnterprise = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CAPTCHA_IS_ENTERPRISE
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CAPTCHA);
    };
    getStateCaptchaSubmitAction = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CAPTCHA_SUBMIT_ACTION
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CAPTCHA);
    };
    getStateCaptchaInitAction = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CAPTCHA_INIT_ACTION
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CAPTCHA);
    };
    getStateCaptchaLoadOnInit = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CAPTCHA_LOAD_ON_INIT
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CAPTCHA);
    };
    getStateCaptchaHideBadge = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CAPTCHA_HIDE_BADGE
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CAPTCHA);
    };
    ////////////////////////////////////////////////////////////////
    // Geolocation getters.
    ////////////////////////////////////////////////////////////////
    getStateGeolocationIsUsed = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_USED
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.GEOLOCATION) && !(0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_ADMIN
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONFIG);
    };
    ////////////////////////////////////////////////////////////////
    // Enrichment getters.
    ////////////////////////////////////////////////////////////////
    getStateEnrichmentIsUsed = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_USED
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ENRICHMENT) && !(0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_ADMIN
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONFIG);
    };
    getStateEnrichmentIsLocalStorageUsed = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_USED_LOCALSTORAGE
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ENRICHMENT) && (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_USED
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ENRICHMENT) && !(0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_ADMIN
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONFIG) // eslint-disable-line max-len
        ;
    };
    getStateEnrichmentIsPrefillUsed = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_USED_PREFILL
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ENRICHMENT) && (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_USED
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ENRICHMENT) && !(0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_ADMIN
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONFIG); // eslint-disable-line max-len
    };
    getStateEnrichmentIsPrefillUrlUsed = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_USED_PREFILL_URL
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ENRICHMENT) && (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_USED
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ENRICHMENT) && !(0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.IS_ADMIN
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.CONFIG) // eslint-disable-line max-len
        ;
    };
    getStateEnrichmentExpiration = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ENRICHMENT_EXPIRATION
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ENRICHMENT);
    };
    getStateEnrichmentExpirationPrefill = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ENRICHMENT_EXPIRATION_PREFILL
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ENRICHMENT);
    };
    getStateEnrichmentAllowed = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ENRICHMENT_ALLOWED
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ENRICHMENT);
    };
    getStateEnrichmentAllowedSmart = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ENRICHMENT_ALLOWED_SMART
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ENRICHMENT);
    };
    getStateEnrichmentStorageName = ()=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.NAME
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ENRICHMENT);
    };
    getStateEnrichmentSmartStorageName = ()=>{
        return `${(0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.NAME
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ENRICHMENT)}-smart`;
    };
    getStateEnrichmentFormPrefillStorageName = (formId)=>{
        return `${(0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.NAME
        ], _state_init__WEBPACK_IMPORTED_MODULE_0__.StateEnum.ENRICHMENT)}-${this.getStateFormFid(formId)}`;
    };
    ////////////////////////////////////////////////////////////////
    // Event getters.
    ////////////////////////////////////////////////////////////////
    getStateEvent = (name)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getStateEvent)(name);
    };
    ////////////////////////////////////////////////////////////////
    // Route getters.
    ////////////////////////////////////////////////////////////////
    getStateRoute = (name)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getStateRoute)(name);
    };
    getStateResponseOutputKey = (name)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getStateResponseOutputKey)(name);
    };
    ////////////////////////////////////////////////////////////////
    // Selector getters.
    ////////////////////////////////////////////////////////////////
    getStateSelector = (name, usePrefix = false)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getStateSelector)(name, usePrefix);
    };
    getStateSelectorAdmin = (name, usePrefix = false)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getStateSelectorAdmin)(name, usePrefix);
    };
    ////////////////////////////////////////////////////////////////
    // Attributes getters.
    ////////////////////////////////////////////////////////////////
    getStateAttribute = (name)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getStateAttribute)(name);
    };
    ////////////////////////////////////////////////////////////////
    // Success redirect getters.
    ////////////////////////////////////////////////////////////////
    getStateSuccessRedirectUrlKey = (name)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getStateSuccessRedirectUrlKey)(name);
    };
    ////////////////////////////////////////////////////////////////
    // Params getters.
    ////////////////////////////////////////////////////////////////
    getStateParam = (name)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getStateParam)(name);
    };
    ////////////////////////////////////////////////////////////////
    // Field Type getters.
    ////////////////////////////////////////////////////////////////
    getStateFieldType = (name)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getStateFieldType)(name);
    };
    ////////////////////////////////////////////////////////////////
    // Other getters.
    ////////////////////////////////////////////////////////////////
    getStateFilteredByKey = (obj, targetKey, findItem, formId)=>{
        return Object?.values(Object?.fromEntries(Object?.entries((0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getState)([
            obj
        ], formId) ?? {})?.filter(([key, value])=>value[targetKey] === findItem)));
    };
    getFormElementByChild = (element)=>{
        return element?.closest(this.getStateSelector('form', true));
    };
    getFormFieldElementByChild = (element)=>{
        return element?.closest(this.getStateSelector('field', true));
    };
    getFormId = (element)=>{
        return element?.getAttribute(this.getStateAttribute('formId'));
    };
    getFormIdByElement = (element)=>{
        return this.getFormElementByChild(element)?.getAttribute(this.getStateAttribute('formId'));
    };
    getFormFidByElement = (element)=>{
        return this.getFormElementByChild(element)?.getAttribute(this.getStateAttribute('formFid'));
    };
    getFieldNameByElement = (element)=>{
        return this.getFormFieldElementByChild(element)?.getAttribute(this.getStateAttribute('fieldName'));
    };
    getRestUrl = (value, isPartial = false)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getRestUrl)(value, isPartial);
    };
    getRestUrlByType = (type, value, isPartial = false, checkRef = false)=>{
        return (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.getRestUrlByType)(type, value, isPartial, checkRef);
    };
    ////////////////////////////////////////////////////////////////
    // Private methods - not shared to the public window object.
    ////////////////////////////////////////////////////////////////
    /**
	 * Set all public methods.
	 *
	 * @returns {void}
	 */ publicMethods() {
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.setStateWindow)();
        if (window[_state_init__WEBPACK_IMPORTED_MODULE_0__.prefix].store) {
            return;
        }
        window[_state_init__WEBPACK_IMPORTED_MODULE_0__.prefix].store = this;
    }
}


/***/ }),

/***/ "./src/Blocks/components/form/assets/step.js":
/*!***************************************************!*\
  !*** ./src/Blocks/components/form/assets/step.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Steps: () => (/* binding */ Steps)
/* harmony export */ });
/* harmony import */ var _state_init__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./state-init */ "./src/Blocks/components/form/assets/state-init.js");

/**
 * Main step class.
 */ class Steps {
    constructor(utils){
        /** @type {import('./utils').Utils} */ this.utils = utils;
        /** @type {import('./state').State} */ this.state = this.utils.getState();
        this.STEP_DIRECTION_PREV = 'prev';
        this.STEP_DIRECTION_NEXT = 'next';
        // Set all public methods.
        this.publicMethods();
    }
    ////////////////////////////////////////////////////////////////
    // Public methods
    ////////////////////////////////////////////////////////////////
    /**
	 * Init steps.
	 *
	 * @param {string} formId Form Id.
	 * 
	 * @returns {void}
	 */ initOne(formId) {
        if (this.state.getStateConfigIsAdmin(formId)) {
            return;
        }
        window.addEventListener(this.state.getStateEvent('formJsLoaded'), this.onInitEvent);
    }
    /**
	 * Handle form submit in case of the step used and all logic.
	 * 
	 * @param {string} formId Form Id.
	 * @param {object} response Response from the API..
	 *
	 * @returns {void}
	 */ formStepSubmit(formId, response) {
        const { status, message, data } = response;
        if (status === 'success') {
            this.goToNextStep(formId, data?.[this.state.getStateResponseOutputKey('stepNextStep')], parseInt(data?.[this.state.getStateResponseOutputKey('stepProgressBarItems')], 10), Boolean(data?.[this.state.getStateResponseOutputKey('stepIsDisableNextButton')]));
        } else {
            const validationOutputKey = this.state.getStateResponseOutputKey('validation');
            if (data?.[validationOutputKey] !== undefined) {
                this.utils.outputErrors(formId, data?.[validationOutputKey]);
            }
            this.utils.setGlobalMsg(formId, message, status, data);
        }
    }
    /**
	 * Actions to run after form submit.
	 *
	 * @param {string} formId Form Id.
	 * @param {object} response Api response.
	 *
	 * @returns {void}
	 */ formStepSubmitAfter(formId, response) {
        // Reset timeout for after each submit.
        if (typeof this.GLOBAL_MSG_TIMEOUT_ID === "number") {
            clearTimeout(this.GLOBAL_MSG_TIMEOUT_ID);
        }
        // Hide global msg in any case after some time.
        this.GLOBAL_MSG_TIMEOUT_ID = setTimeout(()=>{
            this.utils.unsetGlobalMsg(formId);
        }, parseInt(this.state.getStateSettingsHideGlobalMessageTimeout(formId), 10));
        // Dispatch event.
        this.utils.dispatchFormEventForm(this.state.getStateEvent('afterFormSubmitEnd'), formId, response);
    }
    /**
	 * Go to next step in the flow.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} nextStep Next step Id.
	 * @param {int} progressBarItems Progress bar number of items.
	 * @param {boolean} disableNextButton Disable next button.
	 *
	 * @returns {void}
	 */ goToNextStep(formId, nextStep, progressBarItems = 0, disableNextButton = false) {
        if (!nextStep) {
            return;
        }
        const currentStep = this.state.getStateFormStepsCurrent(formId);
        const flow = [
            ...this.state.getStateFormStepsFlow(formId),
            currentStep
        ];
        this.setChangeStep(formId, nextStep, flow, progressBarItems, !this.state.getStateFormMultistepSkipScroll(formId));
        // Hide next button on last step.
        if (nextStep === this.state.getStateFormStepsLastStep(formId)) {
            this.state.getStateFormStepsElement(nextStep, formId).querySelector(`${this.state.getStateSelector('field', true)}[${this.state.getStateAttribute('submitStepDirection')}="${this.STEP_DIRECTION_NEXT}"]`)?.classList?.add(this.state.getStateSelector('isHidden'));
        }
        // Hide next button directed from the api.
        if (disableNextButton) {
            this.state.getStateFormStepsElement(nextStep, formId).querySelector(`${this.state.getStateSelector('field', true)}[${this.state.getStateAttribute('submitStepDirection')}="${this.STEP_DIRECTION_NEXT}"]`)?.classList?.add(this.state.getStateSelector('isHidden'));
        }
        this.utils.dispatchFormEventForm(this.state.getStateEvent('stepsGoToNextStep'), formId);
    }
    /**
	 * Go to prev step in the flow.
	 *
	 * @param {string} formId Form Id.
	 *
	 * @returns {void}
	 */ goToPrevStep(formId) {
        const flow = this.state.getStateFormStepsFlow(formId);
        const nextStep = flow.pop();
        const newFlow = [
            ...flow
        ];
        this.setChangeStep(formId, nextStep, newFlow, 0, !this.state.getStateFormMultistepSkipScroll(formId));
        this.utils.dispatchFormEventForm(this.state.getStateEvent('stepsGoToPrevStep'), formId);
    }
    /**
	 * Go to step with error if integration returns error after our validation.
	 *
	 * @param {string} formId Form Id.
	 * @param {object} errors Error object.
	 *
	 * @returns {void}
	 */ goToStepWithError(formId, errors) {
        const flow = this.state.getStateFormStepsFlow(formId);
        const nextStep = Object.entries(this.state.getStateFormStepsItems(formId)).find(([key, arr])=>arr.includes(Object.keys(errors)[0]))?.[0] || null;
        const nextStepIndex = flow.findIndex((item)=>item === nextStep);
        const newFlow = [
            ...this.state.getStateFormStepsFlow(formId)
        ];
        // If index is found, remove all steps after that index.
        if (nextStepIndex >= 0) {
            newFlow.splice(nextStepIndex, flow.length);
        }
        this.setChangeStep(formId, nextStep, newFlow, 0, !this.state.getStateFormMultistepSkipScroll(formId));
    }
    /**
	 * Reset steps to first step.
	 *
	 * @param {string} formId Form Id.
	 * @param {boolean} shouldScroll Should scroll to the first step.
	 *
	 * @returns {void}
	 */ resetSteps(formId, shouldScroll = true) {
        const firstStep = this.state.getStateFormStepsFirstStep(formId);
        if (!firstStep) {
            return;
        }
        this.setChangeStep(formId, firstStep, [], 0, shouldScroll);
        // Hide prev button.
        this.state.getStateFormStepsElement(firstStep, formId).querySelector(`${this.state.getStateSelector('field', true)}[${this.state.getStateAttribute('submitStepDirection')}="${this.STEP_DIRECTION_PREV}"]`)?.classList?.add(this.state.getStateSelector('isHidden'));
        this.utils.dispatchFormEventForm(this.state.getStateEvent('stepsResetSteps'), formId);
    }
    /**
	 * Update state with next step.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} nextStep Next step Id.
	 * @param {array} flow Flow to update.
	 * @param {int} progressBarItems Progress bar number of items.
	 * @param {boolean} shouldScroll Should scroll to the next step.
	 *
	 * @returns {void}
	 */ setChangeStep(formId, nextStep, flow = [], progressBarItems = 0, shouldScroll = true) {
        if (!nextStep) {
            return;
        }
        // Find current step.
        const currentStep = this.state.getStateFormStepsCurrent(formId);
        // Remove active from current step.
        const currentStepElement = this.state.getStateFormStepsElement(currentStep, formId);
        currentStepElement?.classList?.remove(this.state.getStateSelector('isActive'));
        currentStepElement?.setAttribute('aria-hidden', 'true');
        // Add active to new step.
        const nextStepElement = this.state.getStateFormStepsElement(nextStep, formId);
        nextStepElement?.classList?.add(this.state.getStateSelector('isActive'));
        nextStepElement?.setAttribute('aria-hidden', 'false');
        // Scroll to the next step.
        if (shouldScroll) {
            this.utils.scrollAction(nextStepElement);
        }
        // Reset filled steps.
        this.state.getStateFormStepsElements(formId).forEach((item)=>item?.classList?.remove(this.state.getStateSelector('isFilled')));
        // Add filled to all filled steps.
        flow.forEach((item)=>{
            this.state.getStateFormStepsElement(item, formId)?.classList?.add(this.state.getStateSelector('isFilled'));
        });
        // Set progress bar.
        this.setProgressBar(formId, nextStep, flow, progressBarItems);
        // Update state with the new current step.
        this.state.setStateFormStepsCurrent(nextStep, formId);
        // Update state with the new flow.
        this.state.setStateFormStepsFlow(flow, formId);
    }
    /**
	 * Set progress bar.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} nextStep Next step Id.
	 * @param {array} flow Flow to update.
	 * @param {int} progressBarItems Progress bar number of items.
	 *
	 * @returns {void}
	 */ setProgressBar(formId, nextStep, flow, progressBarItems = 0) {
        if (this.state.getStateFormStepsIsMultiflow(formId)) {
            // Multiflow setup.
            // Update count state when we have something from api.
            if (progressBarItems > 0) {
                this.state.setStateFormStepsProgressBarCount(progressBarItems, formId);
            }
            // Clear current progress bar.
            this.state.getStateFormStepsProgressBar(formId).innerHTML = '';
            // Loop items count from state and output empty divs.
            for(let index = 0; index < this.state.getStateFormStepsProgressBarCount(formId); index++){
                // Create div element.
                const node = document.createElement("div");
                // Output active elements.
                if (flow?.length === 0 && index === 0 || flow?.length > 0 && index <= flow?.length) {
                    node.classList.add(this.state.getStateSelector('isFilled'));
                }
                // Append div element to progress bar.
                this.state.getStateFormStepsProgressBar(formId).append(node);
            }
        } else {
            // Multistep setup.
            // Find current step.
            const currentStep = this.state.getStateFormStepsCurrent(formId);
            // Remove active from current step.
            this.state.getStateFormStepsElementProgressBar(currentStep, formId)?.classList?.remove(this.state.getStateSelector('isActive'));
            // Add active to new step.
            this.state.getStateFormStepsElementProgressBar(nextStep, formId)?.classList?.add(this.state.getStateSelector('isActive'));
            // Reset filled steps.
            this.state.getStateFormStepsElementsProgressBar(formId).forEach((item)=>item?.classList?.remove(this.state.getStateSelector('isFilled')));
            // Add filled to all filled steps.
            flow.forEach((item)=>{
                this.state.getStateFormStepsElementProgressBar(item, formId)?.classList?.add(this.state.getStateSelector('isFilled'));
            });
        }
    }
    /**
	 * Get fields to ignore on form submit.
	 *
	 * @param {string} formId Form Id.
	 *
	 * @returns {array}
	 */ getIgnoreFields(formId) {
        const flow = [
            ...this.state.getStateFormStepsFlow(formId)
        ];
        flow.push(this.state.getStateFormStepsLastStep(formId));
        const items = this.state.getStateFormStepsItems(formId);
        const filteredArray = [];
        Object.keys(items).forEach((key)=>{
            if (!flow.includes(key)) {
                filteredArray.push(...items[key]);
            }
        });
        return filteredArray;
    }
    ////////////////////////////////////////////////////////////////
    // Other
    ////////////////////////////////////////////////////////////////
    /**
	 * Remove all event listeners from elements.
	 * 
	 * @returns {void}
	 */ removeEvents() {
        window?.removeEventListener(this.state.getStateEvent('formJsLoaded'), this.onInitEvent);
    }
    /**
	 * Toggle debug preview.
	 *
	 * @returns {void}
	 */ toggleDebugPreview() {
        const debug = document.querySelectorAll(this.state.getStateSelector('stepDebugPreview', true));
        debug.forEach((item)=>item?.addEventListener('click', this.onToggleDebugPreview));
    }
    ////////////////////////////////////////////////////////////////
    // Events callback
    ////////////////////////////////////////////////////////////////
    /**
	 * On init event callback.
	 *
	 * @param {CustomEvent} event Event object.
	 *
	 * @returns {void}
	 */ onInitEvent = (event)=>{
        const { formId } = event.detail;
        // Set fields logic.
        this.resetSteps(formId, false);
        // Toggle Debug Preview.
        this.toggleDebugPreview();
    };
    /**
	 * On toggle debug preview.
	 *
	 * @param {CustomEvent} event Event object.
	 *
	 * @returns {void}
	 */ onToggleDebugPreview = (event)=>{
        event.preventDefault();
        const formId = this.state.getFormIdByElement(event.target);
        const form = this.state.getStateFormElement(formId);
        if (!form) {
            return;
        }
        form.classList.toggle(this.state.getStateSelector('isStepPreviewActive'));
    };
    ////////////////////////////////////////////////////////////////
    // Private methods - not shared to the public window object.
    ////////////////////////////////////////////////////////////////
    /**
	 * Set all public methods.
	 *
	 * @returns {void}
	 */ publicMethods() {
        (0,_state_init__WEBPACK_IMPORTED_MODULE_0__.setStateWindow)();
        if (window[_state_init__WEBPACK_IMPORTED_MODULE_0__.prefix].step) {
            return;
        }
        window[_state_init__WEBPACK_IMPORTED_MODULE_0__.prefix].step = {
            STEP_DIRECTION_PREV: this.STEP_DIRECTION_PREV,
            STEP_DIRECTION_NEXT: this.STEP_DIRECTION_NEXT,
            initOne: (formId)=>{
                this.initOne(formId);
            },
            formStepSubmit: (formId, response)=>{
                this.formStepSubmit(formId, response);
            },
            formStepSubmitAfter: (formId, response)=>{
                this.formStepSubmitAfter(formId, response);
            },
            goToNextStep: (formId, nextStep, progressBarItems = 0, disableNextButton = false)=>{
                this.goToNextStep(formId, nextStep, progressBarItems, disableNextButton);
            },
            goToPrevStep: (formId)=>{
                this.goToPrevStep(formId);
            },
            goToStepWithError: (formId, errors)=>{
                this.goToStepWithError(formId, errors);
            },
            resetSteps: (formId, shouldScroll = true)=>{
                this.resetSteps(formId, shouldScroll);
            },
            setChangeStep: (formId, nextStep, flow, progressBarItems = 0, shouldScroll = true)=>{
                this.setChangeStep(formId, nextStep, flow, progressBarItems, shouldScroll);
            },
            setProgressBar: (formId, nextStep, flow, progressBarItems = 0)=>{
                this.setProgressBar(formId, nextStep, flow, progressBarItems);
            },
            getIgnoreFields: (formId)=>{
                return this.getIgnoreFields(formId);
            },
            removeEvents: (formId)=>{
                this.removeEvents(formId);
            },
            toggleDebugPreview: ()=>{
                this.toggleDebugPreview();
            },
            onInitEvent: (event)=>{
                this.onInitEvent(event);
            },
            onToggleDebugPreview: (event)=>{
                this.onToggleDebugPreview(event);
            }
        };
    }
}


/***/ }),

/***/ "./src/Blocks/components/form/assets/utils.js":
/*!****************************************************!*\
  !*** ./src/Blocks/components/form/assets/utils.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Utils: () => (/* binding */ Utils)
/* harmony export */ });
/* harmony import */ var _eightshift_ui_components_utilities__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @eightshift/ui-components/utilities */ "./node_modules/@eightshift/ui-components/dist/utilities/es-dash.js");
/* harmony import */ var _conditional_tags__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./conditional-tags */ "./src/Blocks/components/form/assets/conditional-tags.js");
/* harmony import */ var _enrichment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./enrichment */ "./src/Blocks/components/form/assets/enrichment.js");
/* harmony import */ var _geolocation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./geolocation */ "./src/Blocks/components/form/assets/geolocation.js");
/* harmony import */ var _state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./state */ "./src/Blocks/components/form/assets/state.js");
/* harmony import */ var _state_init__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./state-init */ "./src/Blocks/components/form/assets/state-init.js");
/* harmony import */ var _step__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./step */ "./src/Blocks/components/form/assets/step.js");
/* harmony import */ var _manifest_json__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./../../../manifest.json */ "./src/Blocks/manifest.json");








/**
 * Main Utilities class.
 */ class Utils {
    constructor(){
        /** @type {import('./state').State} */ this.state = new _state__WEBPACK_IMPORTED_MODULE_4__.State();
        /** @type {import('./enrichment').Enrichment} */ this.enrichment = new _enrichment__WEBPACK_IMPORTED_MODULE_2__.Enrichment(this);
        /** @type {import('./conditional-tags').ConditionalTags}*/ this.conditionalTags = new _conditional_tags__WEBPACK_IMPORTED_MODULE_1__.ConditionalTags(this);
        /** @type {import('./steps').Steps}*/ this.steps = new _step__WEBPACK_IMPORTED_MODULE_6__.Steps(this);
        /** @type {import('./geolocation').Geolocation}*/ this.geolocation = new _geolocation__WEBPACK_IMPORTED_MODULE_3__.Geolocation(this);
        this.GLOBAL_MSG_TIMEOUT_ID = undefined;
        // Set all public methods.
        this.publicMethods();
    }
    ////////////////////////////////////////////////////////////////
    // Getters methods
    ////////////////////////////////////////////////////////////////
    /**
	 * Get state class.
	 *
	 * @returns {State}
	 */ getState() {
        return this.state;
    }
    /**
	 * Get enrichment class.
	 *
	 * @returns {Enrichment}
	 */ getEnrichment() {
        return this.enrichment;
    }
    /**
	 * Get conditional tags class.
	 *
	 * @returns {ConditionalTags}
	 */ getConditionalTags() {
        return this.conditionalTags;
    }
    /**
	 * Get steps class.
	 *
	 * @returns {Steps}
	 */ getSteps() {
        return this.steps;
    }
    /**
	 * Get geolocation class.
	 *
	 * @returns {Geolocation}
	 */ getGeolocation() {
        return this.geolocation;
    }
    ////////////////////////////////////////////////////////////////
    // Public methods
    ////////////////////////////////////////////////////////////////
    /**
	 * Reset form in general.
	 *
	 * @param {string} formId Form Id.
	 *
	 * @returns {void}
	 */ resetErrors(formId) {
        for (const [name] of this.state.getStateElements(formId)){
            this.unsetFieldError(formId, name);
        }
        this.unsetGlobalMsg(formId);
    }
    /**
	 * Create custom event.
	 *
	 * @param {string} eventName Event name.
	 * @param {string} formId Form Id.
	 * @param {object} additional Additional data to add to event.
	 *
	 * @returns {Event}
	 */ createCustomEvent(eventName, formId = null, additional = null) {
        const options = {
            bubbles: true,
            detail: {
                [_state_init__WEBPACK_IMPORTED_MODULE_5__.prefix]: window?.[_state_init__WEBPACK_IMPORTED_MODULE_5__.prefix]
            }
        };
        if (formId) {
            options.detail.formId = formId;
        }
        if (additional) {
            options.detail.additional = additional;
        }
        return new CustomEvent(eventName, options);
    }
    /**
	 * Dispatch custom event - window
	 *
	 * @param {string} eventName Event name.
	 * @param {object} additional Additional data to add to event.
	 *
	 * @returns {void}
	 */ dispatchFormEventWindow(eventName, additional = null) {
        window.dispatchEvent(this.createCustomEvent(eventName, additional));
    }
    /**
	 * Dispatch custom event - form
	 *
	 * @param {string} eventName Event name.
	 * @param {string} formId Form Id.
	 * @param {object} additional Additional data to add to event.
	 *
	 * @returns {void}
	 */ dispatchFormEventForm(eventName, formId, additional = null) {
        window.dispatchEvent(this.createCustomEvent(eventName, formId, additional));
    }
    /**
	 * Dispatch custom event - field
	 *
	 * @param {string} eventName Event name.
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 * @param {object|string|array} value Field value.
	 *
	 * @returns {void}
	 */ dispatchFormEventField(eventName, formId, name, value) {
        window.dispatchEvent(this.createCustomEvent(eventName, formId, {
            name,
            value
        }));
    }
    /**
	 * Scroll to specific element.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 *
	 * @returns {void}
	 */ scrollToElement(formId, name) {
        const field = this.state.getStateElementField(name, formId);
        const type = this.state.getStateElementTypeField(name, formId);
        if (field) {
            this.scrollAction(field);
            switch(type){
                case 'file':
                    this.state.getStateElementFileButton(name, formId)?.focus();
                    break;
                case 'select':
                case 'country':
                    this.state.getStateElementCustom(name, formId)?.showDropdown();
                    break;
                case 'date':
                case 'dateTime':
                    this.state.getStateElementCustom(name, formId)?.open();
                    break;
                case 'file':
                    this.state.getStateElementFileButton(name, formId)?.focus();
                    break;
                case 'checkbox':
                case 'radio':
                case 'rating':
                    const firstKey = Object.keys(this.state.getStateElementItems(name, formId))?.[0];
                    this.state.getStateElementItems(name, formId)?.[firstKey]?.input?.focus();
                    break;
                default:
                    this.state.getStateElementInput(name, formId).focus();
            }
        }
    }
    /**
	 * Scroll to element action.
	 *
	 * @param {Element} element Element to scroll to.
	 * @param {object} options Scroll options.
	 *
	 * @returns {void}
	 */ scrollAction(element, options = {
        behavior: 'smooth',
        block: 'start'
    }) {
        element?.scrollIntoView(options);
    }
    /**
	 * Show loader.
	 *
	 * @param {string} formId Form Id.
	 *
	 * @returns {void}
	 */ showLoader(formId) {
        this.state.getStateFormElement(formId)?.classList?.add(this.state.getStateSelector('isLoading'));
        this.state.getStateFormLoader(formId)?.classList?.add(this.state.getStateSelector('isActive'));
    }
    /**
	 * Hide loader.
	 *
	 * @param {string} formId Form Id.
	 *
	 * @returns {void}
	 */ hideLoader(formId) {
        this.state.getStateFormElement(formId)?.classList?.remove(this.state.getStateSelector('isLoading'));
        this.state.getStateFormLoader(formId)?.classList?.remove(this.state.getStateSelector('isActive'));
    }
    /**
	 * Unset all error for fields by name.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 *
	 * @returns {void}
	 */ unsetFieldError(formId, name) {
        const error = this.state.getStateElementError(name, formId);
        if (!error) {
            return;
        }
        const input = this.state.getStateElementInput(name, formId);
        this.state.getStateElementField(name, formId)?.classList?.remove(this.state.getStateSelector('hasError'));
        this.state.setStateElementHasError(name, false, formId);
        error.innerHTML = '';
        if (input) {
            input.setAttribute('aria-invalid', 'false');
        }
    }
    /**
	 * Set all error for fields.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 * @param {string} msg Error msg.
	 *
	 * @returns {void}
	 */ setFieldError(formId, name, msg) {
        const error = this.state.getStateElementError(name, formId);
        if (!error) {
            return;
        }
        const input = this.state.getStateElementInput(name, formId);
        this.state.getStateElementField(name, formId)?.classList?.add(this.state.getStateSelector('hasError'));
        this.state.setStateElementHasError(name, true, formId);
        error.innerHTML = msg;
        if (input) {
            input.setAttribute('aria-invalid', 'true');
        }
    }
    /**
	 * Output all error for fields.
	 *
	 * @param {string} formId Form Id.
	 * @param {object} data Form response data.
	 *
	 * @returns {void}
	 */ outputErrors(formId, data) {
        for (const [name, msg] of Object.entries(data)){
            this.setFieldError(formId, name, msg);
        }
        // Scroll to element if the condition is right.
        const firstItemWithErrorName = this.state.getStateElementByHasError(true, formId)?.[0]?.[_state_init__WEBPACK_IMPORTED_MODULE_5__.StateEnum.NAME];
        if (firstItemWithErrorName && !this.state.getStateSettingsDisableScrollToFieldOnError()) {
            this.scrollToElement(formId, firstItemWithErrorName);
        }
    }
    /**
	 * Unset global msg.
	 *
	 * @param {string} formId Form Id.
	 *
	 * @returns {void}
	 */ unsetGlobalMsg(formId) {
        const messageContainer = this.state.getStateFormGlobalMsgElement(formId);
        if (!messageContainer) {
            return;
        }
        messageContainer?.classList?.remove(this.state.getStateSelector('isActive'), this.state.getStateSelector('hasError'));
        messageContainer.dataset.status = '';
        messageContainer.innerHTML = '';
    }
    /**
	 * Set global msg.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} msg Message text.
	 * @param {string} status Message status.
	 * @param {object} responseData Additional responseData.
	 *
	 * @returns {void}
	 */ setGlobalMsg(formId, msg, status, responseData = {}) {
        const messageContainer = this.state.getStateFormGlobalMsgElement(formId);
        if (!messageContainer) {
            return;
        }
        // Scroll to msg if the condition is matched.
        if (status === 'success') {
            if (responseData?.[this.state.getStateResponseOutputKey('hideGlobalMsgOnSuccess')]) {
                return;
            }
            messageContainer?.classList?.add(this.state.getStateSelector('isActive'));
            messageContainer.dataset.status = status;
            if (!this.state.getStateSettingsDisableScrollToGlobalMsgOnSuccess(formId)) {
                this.scrollAction(this.state.getStateFormGlobalMsgElement(formId));
            }
            const headingSuccess = this.state.getStateFormGlobalMsgHeadingSuccess(formId);
            if (headingSuccess) {
                messageContainer.innerHTML = `<div><div>${headingSuccess}</div><span>${msg}</span></div>`;
            } else {
                messageContainer.innerHTML = `<div><span>${msg}</span></div>`;
            }
        } else {
            messageContainer?.classList?.add(this.state.getStateSelector('isActive'), this.state.getStateSelector('hasError'));
            messageContainer.dataset.status = status;
            const headingError = this.state.getStateFormGlobalMsgHeadingError(formId);
            if (headingError) {
                messageContainer.innerHTML = `<div><div>${headingError}</div><span>${msg}</span></div>`;
            } else {
                messageContainer.innerHTML = `<div><span>${msg}</span></div>`;
            }
        }
    }
    /**
	 *  Build GTM data for the data layer.
	 *
	 * @param {string} formId Form Id.
	 *
	 * @returns {object}
	 */ getGtmData(formId) {
        const output = {};
        for (const [name] of this.state.getStateElements(formId)){
            const value = this.state.getStateElementValue(name, formId);
            const trackingName = this.state.getStateElementTracking(name, formId);
            const field = this.state.getStateElementField(name, formId);
            if (!trackingName) {
                continue;
            }
            switch(this.state.getStateElementTypeField(name, formId)){
                case 'checkbox':
                    for (const [checkName, checkValue] of Object.entries(value)){
                        const trackingCheckName = trackingName?.[checkName];
                        if (!trackingCheckName) {
                            continue;
                        }
                        if (!(trackingCheckName in output)) {
                            output[trackingCheckName] = '';
                        }
                        if (checkValue) {
                            output[trackingCheckName] = checkValue;
                        }
                    }
                    break;
                case 'file':
                    const fileList = this.state.getStateElementCustom(name, formId)?.files ?? [];
                    output[trackingName] = fileList?.map((file)=>file?.upload?.uuid);
                    break;
                case 'phone':
                    output[trackingName] = this.getPhoneCombinedValue(formId, name);
                    break;
                default:
                    output[trackingName] = value;
                    break;
            }
        }
        return output;
    }
    /**
	 * Get GTM event with data and push to dataLayer.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} status Response status.
	 * @param {object} responseData Additional responseData.
	 *
	 * @returns {void}
	 */ gtmSubmit(formId, status, responseData = {}) {
        const eventName = responseData?.[this.state.getStateResponseOutputKey('trackingEventName')];
        const errors = responseData?.[this.state.getStateResponseOutputKey('validation')];
        if (!eventName) {
            return;
        }
        const gtmData = {
            event: eventName,
            ...this.getGtmData(formId)
        };
        const additionalData = responseData?.[this.state.getStateResponseOutputKey('trackingAdditionalData')];
        let additionalDataItems = additionalData?.general;
        if (status === 'success') {
            additionalDataItems = {
                ...additionalDataItems,
                ...additionalData?.success
            };
        }
        if (status === 'error') {
            additionalDataItems = {
                ...additionalDataItems,
                ...additionalData?.error
            };
        }
        if (errors) {
            for (const [key, value] of Object.entries(additionalDataItems)){
                if (value === '{invalidFieldsString}') {
                    additionalDataItems[key] = Object.keys(errors).join(',');
                }
                if (value === '{invalidFieldsArray}') {
                    additionalDataItems[key] = Object.keys(errors);
                }
            }
        }
        if (window?.dataLayer && gtmData?.event) {
            window.dataLayer.push({
                ...gtmData,
                ...additionalDataItems
            });
            this.dispatchFormEventForm(this.state.getStateEvent('afterGtmDataPush'), formId, {
                gtmData,
                additionalDataItems
            });
        }
    }
    /**
	 * Prefill inputs active/filled.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 *
	 * @returns {void}
	 */ setFieldFilledState(formId, name) {
        this.unsetActiveState(formId, name);
        const type = this.state.getStateElementTypeField(name, formId);
        const value = this.state.getStateElementValue(name, formId);
        switch(type){
            case 'checkbox':
                this.setFieldFilledStateByName(formId, name, Object.values(value).filter((item)=>item !== '').length > 0);
                break;
            case 'phone':
                this.setFieldFilledStateByName(formId, name, value?.value);
                break;
            default:
                this.setFieldFilledStateByName(formId, name, value && value.length);
                break;
        }
    }
    /**
	 * Prefill inputs active/filled.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 * @param {bool} condition Condition.
	 *
	 * @returns {void}
	 */ setFieldFilledStateByName(formId, name, condition) {
        if (condition) {
            this.setFilledState(formId, name);
        } else {
            this.unsetFilledState(formId, name);
        }
    }
    /**
	 * Set active state.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 *
	 * @returns {void}
	 */ setActiveState(formId, name) {
        this.state.getStateElementField(name, formId)?.classList?.add(this.state.getStateSelector('isActive'));
    }
    /**
	 * Unset active state.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 *
	 * @returns {void}
	 */ unsetActiveState(formId, name) {
        this.state.getStateElementField(name, formId)?.classList?.remove(this.state.getStateSelector('isActive'));
    }
    /**
	 * Set filled state.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 *
	 * @returns {void}
	 */ setFilledState(formId, name) {
        this.state.getStateElementField(name, formId)?.classList?.add(this.state.getStateSelector('isFilled'));
    }
    /**
	 * Unset filled state.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 *
	 * @returns {void}
	 */ unsetFilledState(formId, name) {
        this.state.getStateElementField(name, formId)?.classList?.remove(this.state.getStateSelector('isFilled'));
    }
    /**
	 *  Reset form values to the initial state.
	 *
	 * @param {string} formId Form Id.
	 *
	 * @returns {void}
	 */ resetForm(formId) {
        if (!this.state.getStateSettingsResetOnSuccess(formId)) {
            return;
        }
        if (this.state.getStateFormIsAdminSingleSubmit(formId)) {
            return;
        }
        if (this.state.getStateFormConfigUseSingleSubmit(formId)) {
            return;
        }
        for (const [name] of this.state.getStateElements(formId)){
            const initial = this.state.getStateElementInitial(name, formId);
            switch(this.state.getStateElementTypeField(name, formId)){
                case 'phone':
                    this.setManualPhoneValue(formId, name, initial);
                    break;
                case 'date':
                case 'dateTime':
                    this.setManualDateValue(formId, name, initial);
                    break;
                case 'country':
                    this.setManualCountryValue(formId, name, initial);
                    break;
                case 'select':
                    this.setManualSelectValue(formId, name, initial);
                    break;
                case 'checkbox':
                    this.setManualCheckboxValue(formId, name, initial);
                    break;
                case 'radio':
                    this.setManualRadioValue(formId, name, initial);
                    break;
                case 'rating':
                    this.setManualRatingValue(formId, name, initial);
                    break;
                case 'range':
                    this.setManualRangeValue(formId, name, initial);
                    break;
                case 'file':
                    this.state.getStateElementCustom(name, formId)?.removeAllFiles();
                    break;
                default:
                    this.setManualInputValue(formId, name, initial);
                    break;
            }
        }
        // Remove focus from last input.
        document.activeElement.blur();
        // Dispatch event.
        this.dispatchFormEventForm(this.state.getStateEvent('afterFormSubmitReset'), formId);
    }
    /**
	 * Redirect to url by provided path.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} redirectUrl Redirect url.
	 * @param {bool} reload Do we reload or not.
	 *
	 * @returns {void}
	 */ redirectToUrlByReference(formId, redirectUrl, reload = false) {
        this.dispatchFormEventForm(this.state.getStateEvent('afterFormSubmitSuccessBeforeRedirect'), formId, redirectUrl);
        // Do the actual redirect after some time.
        setTimeout(()=>{
            window.location = redirectUrl;
            if (reload) {
                window.location.reload();
            }
        }, parseInt(this.state.getStateSettingsRedirectionTimeout(formId), 10));
    }
    /**
	 * Check if form is fully loaded.
	 *
	 * @param {string} formId Form Id.
	 *
	 * @returns {void}
	 */ isFormLoaded(formId) {
        var iterations = 0;
        const interval = setInterval(()=>{
            if (iterations >= 20) {
                clearInterval(interval);
            }
            if (this.state.getStateElementByLoaded(false, formId)?.length === 0) {
                clearInterval(interval);
                this.state.setStateFormIsLoaded(true, formId);
                // Trigger event that form is fully loaded.
                this.dispatchFormEventForm(this.state.getStateEvent('formJsLoaded'), formId);
            }
            iterations++;
        }, 100);
    }
    /**
	 * Get textarea json object to save.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 *
	 * @returns {object}
	 */ getSaveAsJsonFormatOutput(formId, name) {
        const output = [];
        const items = this.state.getStateElementValue(name, formId).split(/\r\n|\r|\n/);
        if (items.length) {
            items.forEach((item)=>{
                if (!item) {
                    return;
                }
                const innerItem = item.split(':');
                const innerOutput = [];
                if (innerItem) {
                    innerItem.forEach((inner)=>{
                        const innerItem = inner.trim();
                        if (!innerItem) {
                            return;
                        }
                        innerOutput.push(innerItem.trim());
                    });
                }
                output.push(innerOutput);
            });
        }
        return output;
    }
    /**
	 * Check if form is fully loaded.
	 *
	 * @param {object} file File object.
	 *
	 * @returns {string}
	 */ getFileNameFromFileObject(file) {
        if (!file) {
            return '';
        }
        if (!file?.xhr?.response) {
            return '';
        }
        return JSON.parse(file.xhr.response)?.data?.fileName || '';
    }
    /**
	 * Actions to run if api response returns an error.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} actionName Action name.
	 * @param {string} errorName Error name.
	 * @param {string} errorMessage Error message.
	 *
	 * @returns {string}
	 */ formSubmitResponseError(formId, actionName, errorName, errorMessage) {
        if (formId !== null) {
            // Clear all errors.
            this.resetErrors(formId);
            // Remove loader.
            this.hideLoader(formId);
            // Set global msg.
            this.setGlobalMsg(formId, this.state.getStateSettingsFormServerErrorMsg(), 'error');
            // Reset timeout for after each submit.
            if (typeof this.GLOBAL_MSG_TIMEOUT_ID === 'number') {
                clearTimeout(this.GLOBAL_MSG_TIMEOUT_ID);
            }
            // Hide global msg in any case after some time.
            this.GLOBAL_MSG_TIMEOUT_ID = setTimeout(()=>{
                this.unsetGlobalMsg(formId);
            }, parseInt(this.state.getStateSettingsHideGlobalMessageTimeout(formId), 10));
        }
        return `API response returned an error. Function used: "${actionName}" with error: "${errorName}" and a message: "${errorMessage}" for form id: "${formId}"`;
    }
    /**
	 * Remove forms that don't have forms block.
	 *
	 * @returns {void}
	 */ removeFormsWithMissingFormsBlock() {
        [
            ...document.querySelectorAll(this.state.getStateSelector('form', true))
        ].forEach((form)=>{
            if (!form?.closest(this.state.getStateSelector('forms', true))) {
                form.innerHTML = this.state.getStateSettingsFormMisconfiguredMsg();
            }
        });
    }
    /**
	 * Set on focus change event.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 *
	 * @returns {void}
	 */ setOnFocus(target) {
        const formId = this.state.getFormIdByElement(target);
        const field = this.state.getFormFieldElementByChild(target);
        const name = field.getAttribute(this.state.getStateAttribute('fieldName'));
        this.setActiveState(formId, name);
    }
    /**
	 * Set on blur change event.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 *
	 * @returns {void}
	 */ setOnBlur(target) {
        const formId = this.state.getFormIdByElement(target);
        const field = this.state.getFormFieldElementByChild(target);
        const name = field.getAttribute(this.state.getStateAttribute('fieldName'));
        this.unsetActiveState(formId, name);
    }
    /**
	 * Set mandatory field state.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 * @param {string} value Field value.
	 * @param {bool} fullSet Full set value.
	 *
	 * @returns {void}
	 */ setMandatoryFieldState(formId, name, value, fullSet = true) {
        this.setFieldFilledState(formId, name);
        this.enrichment.setLocalStorageFormPrefillField(formId, name);
        if (fullSet) {
            this.conditionalTags.setField(formId, name);
        }
        this.unsetFieldError(formId, name);
        this.dispatchFormEventField(this.state.getStateEvent('onFieldChange'), formId, name, value);
    }
    /**
	 * Set manual field value - Phone.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 * @param {object} value Field value.
	 * @param {bool} fullSet Full set value.
	 * @param {bool} set Set value.
	 *
	 * Expected value format:
	 * {
	 *  prefix: '1',
	 *  value: '1234567890'
	 * }
	 *
	 * @returns {void}
	 */ setManualPhoneValue(formId, name, value, fullSet = true, set = true) {
        if (typeof value !== 'object') {
            return;
        }
        if (!(name in this.state.getStateElementsObject(formId))) {
            return;
        }
        const phoneDisablePicker = this.state.getStateFormConfigPhoneDisablePicker(formId);
        let newValue = value?.value ?? this.state.getStateElementValue(name, formId)?.value ?? '';
        let newPrefix = value?.prefix ?? this.state.getStateElementValue(name, formId)?.prefix ?? '';
        const isValueEmpty = (0,_eightshift_ui_components_utilities__WEBPACK_IMPORTED_MODULE_0__.isEmpty)(value);
        // For manual setting.
        if (!phoneDisablePicker) {
            const custom = this.state.getStateElementCustom(name, formId);
            if (custom) {
                if (isValueEmpty || newPrefix === '') {
                    custom.removeActiveItems();
                } else {
                    if (set) {
                        custom.setChoiceByValue(newPrefix);
                    }
                }
            }
        }
        const input = this.state.getStateElementInput(name, formId);
        if (input) {
            if (isValueEmpty) {
                input.value = '';
                newValue = '';
                newPrefix = '';
            } else {
                if (set) {
                    input.value = newValue;
                }
            }
        }
        const outputValue = {
            value: newValue,
            prefix: newPrefix
        };
        (0,_state_init__WEBPACK_IMPORTED_MODULE_5__.setStateValues)(name, outputValue, formId);
        this.setMandatoryFieldState(formId, name, outputValue, fullSet);
    }
    /**
	 * Set manual field value - Phone prefix by attribute value.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 * @param {string} value Field value.
	 * @param {string} attribute Attribute name.
	 * @param {bool} fullSet Full set value.
	 *
	 * Expected value format:
	 * 'hr'
	 *
	 * @returns {void}
	 */ setManualPhonePrefixByAttributeValue(formId, name, value, attribute, fullSet = true) {
        if (typeof value !== 'string') {
            return;
        }
        if (!(name in this.state.getStateElementsObject(formId))) {
            return;
        }
        const phoneDisablePicker = this.state.getStateFormConfigPhoneDisablePicker(formId);
        if (phoneDisablePicker) {
            return;
        }
        let newPrefix = value ?? '';
        const custom = this.state.getStateElementCustom(name, formId);
        const option = [
            ...custom?.passedElement?.element?.options
        ].find((option)=>option.getAttribute(attribute) === value);
        if (option) {
            custom.setChoiceByValue(option.value);
            newPrefix = option.value;
        }
        const outputValue = {
            value: this.state.getStateElementValue(name, formId)?.value ?? '',
            prefix: newPrefix
        };
        (0,_state_init__WEBPACK_IMPORTED_MODULE_5__.setStateValues)(name, outputValue, formId);
        this.setMandatoryFieldState(formId, name, outputValue, fullSet);
    }
    /**
	 * Set manual field value - Date.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 * @param {string} value Field value.
	 * @param {bool} fullSet Full set value.
	 * @param {bool} set Set value.
	 *
	 * Expected value format:
	 * '2021-01-01'
	 * '2021-01-01 12:00'
	 *
	 * @returns {void}
	 */ setManualDateValue(formId, name, value, fullSet = true, set = true) {
        if (typeof value !== 'string') {
            return;
        }
        if (!(name in this.state.getStateElementsObject(formId))) {
            return;
        }
        // For manual setting.
        const custom = this.state.getStateElementCustom(name, formId);
        if (custom) {
            if (set) {
                custom.setDate(value, true, custom?.config?.dateFormat);
            }
        }
        (0,_state_init__WEBPACK_IMPORTED_MODULE_5__.setStateValues)(name, value, formId);
        this.setMandatoryFieldState(formId, name, value, fullSet);
    }
    /**
	 * Set manual field value - Select.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 * @param {array} value Field value.
	 * @param {bool} fullSet Full set value.
	 * @param {bool} set Set value.
	 *
	 * Expected value format:
	 * ['option-1', 'option-2']
	 *
	 * @returns {void}
	 */ setManualSelectValue(formId, name, value, fullSet = true, set = true) {
        if (!Array.isArray(value)) {
            return;
        }
        if (!(name in this.state.getStateElementsObject(formId))) {
            return;
        }
        const newValue = value;
        // For manual setting.
        if (set) {
            const custom = this.state.getStateElementCustom(name, formId);
            if (custom) {
                if (newValue.length) {
                    newValue.forEach((item, index)=>{
                        const option = [
                            ...custom.passedElement?.element?.options
                        ].find((option)=>option.value === item);
                        if (option) {
                            custom.setChoiceByValue(item);
                        } else {
                            newValue.splice(index, 1);
                        }
                    });
                } else {
                    custom.removeActiveItems();
                }
            }
        }
        (0,_state_init__WEBPACK_IMPORTED_MODULE_5__.setStateValues)(name, newValue, formId);
        this.setMandatoryFieldState(formId, name, newValue, fullSet);
    }
    /**
	 * Set manual field value - Select by attribute value.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 * @param {array} value Field value.
	 * @param {string} attribute Attribute name.
	 * @param {bool} fullSet Full set value.
	 *
	 * Expected value format:
	 * ['hr', 'de']
	 *
	 * @returns {void}
	 */ setManualSelectByAttributeValue(formId, name, value, attribute, fullSet = true) {
        if (!Array.isArray(value)) {
            return;
        }
        if (!(name in this.state.getStateElementsObject(formId))) {
            return;
        }
        let newValue = value;
        // For manual setting.
        const custom = this.state.getStateElementCustom(name, formId);
        if (custom) {
            if (newValue.length) {
                newValue.forEach((item, index)=>{
                    const option = [
                        ...custom.passedElement?.element?.options
                    ].find((option)=>option.getAttribute(attribute) === item);
                    if (option) {
                        custom.setChoiceByValue(option.value);
                        newValue[index] = option.value;
                    } else {
                        newValue.splice(index, 1);
                    }
                });
            } else {
                custom.removeActiveItems();
            }
        }
        (0,_state_init__WEBPACK_IMPORTED_MODULE_5__.setStateValues)(name, newValue, formId);
        this.setMandatoryFieldState(formId, name, newValue, fullSet);
    }
    /**
	 * Set manual field value - Country.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 * @param {array} value Field value.
	 * @param {bool} fullSet Full set value.
	 * @param {bool} set Set value.
	 *
	 * Expected value format:
	 * ['hr', 'de']
	 *
	 * @returns {void}
	 */ setManualCountryValue(formId, name, value, fullSet = true, set = true) {
        this.setManualSelectValue(formId, name, value, fullSet, set);
    }
    /**
	 * Set manual field value - Checkboxes.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 * @param {array} value Field value.
	 * @param {bool} fullSet Full set value.
	 *
	 * Expected value format:
	 * {
	 *  checkbox-1: checkbox-1,
	 *  checkbox-2: checkbox-2,
	 * }
	 *
	 * @returns {void}
	 */ setManualCheckboxValue(formId, name, value, fullSet = true) {
        let initValue = value;
        if (Array.isArray(value)) {
            initValue = value.reduce((acc, item)=>{
                acc[item] = item;
                return acc;
            }, {});
        }
        if (typeof initValue !== 'object') {
            return;
        }
        if (!(name in this.state.getStateElementsObject(formId))) {
            return;
        }
        const isValueEmpty = (0,_eightshift_ui_components_utilities__WEBPACK_IMPORTED_MODULE_0__.isEmpty)(initValue);
        let newValue = this.state.getStateElementValue(name, formId);
        const custom = this.state.getStateElementCustom(name, formId);
        let hasCustomChanged = false;
        const inner = this.state.getStateElementItems(name, formId);
        if (inner) {
            if (isValueEmpty) {
                Object.values(inner).forEach((item)=>{
                    item.input.checked = false;
                    newValue[item.value] = '';
                });
                if (custom) {
                    custom.value = '';
                    hasCustomChanged = true;
                }
            } else {
                let customValue = '';
                Object.values(inner).forEach((item)=>{
                    if (initValue?.[item.value]) {
                        item.input.checked = true;
                        newValue[item.value] = item.value;
                    }
                    if (initValue?.[item.value] === '') {
                        item.input.checked = false;
                        newValue[item.value] = '';
                    }
                });
                Object.values(initValue).forEach((item)=>{
                    if (!inner[item]) {
                        customValue = item;
                    }
                });
                if (custom && customValue !== '') {
                    custom.value = customValue;
                    hasCustomChanged = true;
                }
            }
        }
        (0,_state_init__WEBPACK_IMPORTED_MODULE_5__.setStateValues)(name, newValue, formId);
        this.setMandatoryFieldState(formId, name, newValue, fullSet);
        if (hasCustomChanged && custom) {
            (0,_state_init__WEBPACK_IMPORTED_MODULE_5__.setStateValues)(custom.name, custom.value, formId);
            this.setMandatoryFieldState(formId, custom.name, custom.value, fullSet);
        }
    }
    /**
	 * Set manual field value - Radios.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 * @param {string} value Field value.
	 * @param {bool} fullSet Full set value.
	 *
	 * Expected value format:
	 * 'radio-1'
	 *
	 * @returns {void}
	 */ setManualRadioValue(formId, name, value, fullSet = true) {
        if (typeof value !== 'string') {
            return;
        }
        if (!(name in this.state.getStateElementsObject(formId))) {
            return;
        }
        const custom = this.state.getStateElementCustom(name, formId);
        let newValue = this.state.getStateElementValue(name, formId);
        let hasCustomChanged = false;
        const inner = this.state.getStateElementItems(name, formId);
        if (inner) {
            if (value === '') {
                Object.values(inner).forEach((item)=>{
                    item.input.checked = false;
                    newValue = '';
                });
                if (custom) {
                    custom.value = '';
                    hasCustomChanged = true;
                }
            } else {
                Object.values(inner).forEach((item)=>{
                    item.input.checked = false;
                });
                if (inner[value]) {
                    inner[value].input.checked = true;
                    newValue = value;
                    if (custom) {
                        custom.value = '';
                        hasCustomChanged = true;
                    }
                } else {
                    if (custom) {
                        custom.value = value;
                        newValue = '';
                        hasCustomChanged = true;
                    }
                }
            }
        }
        (0,_state_init__WEBPACK_IMPORTED_MODULE_5__.setStateValues)(name, newValue, formId);
        this.setMandatoryFieldState(formId, name, newValue, fullSet);
        if (hasCustomChanged && custom) {
            (0,_state_init__WEBPACK_IMPORTED_MODULE_5__.setStateValues)(custom.name, custom.value, formId);
            this.setMandatoryFieldState(formId, custom.name, custom.value, fullSet);
        }
    }
    /**
	 * Set manual field value - Input/Textarea/Email/Text/Tel/Number/Password/Hidden.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 * @param {string} value Field value.
	 * @param {bool} fullSet Full set value.
	 * @param {bool} set Set value.
	 *
	 * Expected value format:
	 * 'value'
	 *
	 * @returns {void}
	 */ setManualInputValue(formId, name, value, fullSet = true, set = true) {
        if (typeof value !== 'string') {
            return;
        }
        if (!(name in this.state.getStateElementsObject(formId))) {
            return;
        }
        const input = this.state.getStateElementInput(name, formId);
        if (input) {
            if (set) {
                input.value = value;
            }
        }
        (0,_state_init__WEBPACK_IMPORTED_MODULE_5__.setStateValues)(name, value, formId);
        this.setMandatoryFieldState(formId, name, value, fullSet);
        const fieldset = this.state.getStateElementFieldset(name, formId);
        if (fieldset) {
            const customRadioInputName = fieldset.getAttribute(this.state.getStateAttribute('fieldName'));
            const customRadioInputType = fieldset.getAttribute(this.state.getStateAttribute('fieldType'));
            if (customRadioInputName && customRadioInputType === 'radio' && value !== '') {
                const inner = this.state.getStateElementItems(customRadioInputName, formId);
                Object.values(inner).forEach((item)=>{
                    item.input.checked = false;
                });
                (0,_state_init__WEBPACK_IMPORTED_MODULE_5__.setStateValues)(customRadioInputName, '', formId);
                this.setMandatoryFieldState(formId, customRadioInputName, '', fullSet);
            }
        }
    }
    /**
	 * Set manual field value - Rating.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 * @param {string} value Field value.
	 * @param {bool} fullSet Full set value.
	 *
	 * Expected value format:
	 * '5'
	 *
	 * @returns {void}
	 */ setManualRatingValue(formId, name, value, fullSet = true) {
        this.setManualRadioValue(formId, name, value, fullSet);
    }
    /**
	 * Set manual field value - Range
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 * @param {string} value Field value.
	 * @param {bool} fullSet Full set value.
	 * @param {bool} set Set value.
	 *
	 * Expected value format:
	 * '50'
	 *
	 * @returns {void}
	 */ setManualRangeValue(formId, name, value, fullSet = true, set = true) {
        if (typeof value !== 'string') {
            return;
        }
        if (!(name in this.state.getStateElementsObject(formId))) {
            return;
        }
        this.setManualInputValue(formId, name, value, fullSet, set);
        this.setRangeCurrentValue(formId, name);
    }
    /**
	 * Set range current value.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 *
	 * @returns {void}
	 */ setRangeCurrentValue(formId, name) {
        const current = this.state.getStateElementRangeCurrent(name, formId);
        const input = this.state.getStateElementInput(name, formId);
        const custom = this.state.getStateElementCustom(name, formId);
        const value = this.state.getStateElementValue(name, formId);
        // Set range current value as css variable due to inconsistency in browsers.
        if (input) {
            const min = input.min || 0;
            const max = input.max || 100;
            const parsedProgress = Number((value - min) * 100 / (max - min)).toFixed(2);
            input.style.setProperty('--es-form-range-progress', `${parsedProgress}%`);
            if (custom) {
                custom.value = value;
            }
        }
        if (current.length) {
            current.forEach((item)=>{
                item.innerHTML = value;
            });
        }
    }
    /**
	 * Set output results.
	 *
	 * @param {string} formId Form Id.
	 * @param {object} response Api response.
	 *
	 * @returns {void}
	 */ setResultsOutput(formId, data) {
        const formFid = this.state.getStateFormFid(formId);
        // Check if we have output element - block.
        const outputElement = document.querySelector(`${this.state.getStateSelector('resultOutput', true)}[${this.state.getStateAttribute('formId')}="${formFid}"]`);
        // If no output element, bailout.
        if (!outputElement) {
            return;
        }
        this.resetResultsOutput(formFid);
        // Check if we have output items.
        const outputItems = data?.[this.state.getStateResponseOutputKey('variation')] ?? {};
        if (Object.keys(outputItems).length) {
            for (const [key, value] of Object.entries(outputItems)){
                const itemElements = outputElement.querySelectorAll(`${this.state.getStateSelector('resultOutputItem', true)}[${this.state.getStateAttribute('resultOutputItemKey')}="${key}"]`);
                itemElements.forEach((item)=>{
                    const operator = item.getAttribute(this.state.getStateAttribute('resultOutputItemOperator')) || _manifest_json__WEBPACK_IMPORTED_MODULE_7__.comparator.IS;
                    const startValue = item.getAttribute(this.state.getStateAttribute('resultOutputItemValueStart'));
                    const endValue = item.getAttribute(this.state.getStateAttribute('resultOutputItemValueEnd'));
                    if (this.getComparator()[operator](String(startValue), String(value), String(endValue))) {
                        item.classList.remove(this.state.getStateSelector('isHidden'));
                    }
                });
                const partElement = outputElement.querySelectorAll(`${this.state.getStateSelector('resultOutputPart', true)}[${this.state.getStateAttribute('resultOutputPart')}="${key}"]`);
                if (partElement.length && value) {
                    partElement.forEach((item)=>{
                        item.classList.remove(this.state.getStateSelector('isHidden'));
                        item.innerHTML = value;
                    });
                }
            }
        }
        // Check if output block is hidden.
        const outputElementIsHidden = outputElement.classList.contains(this.state.getStateSelector('isHidden'));
        // If hidden, show it.
        if (outputElementIsHidden) {
            outputElement.classList.remove(this.state.getStateSelector('isHidden'));
        }
        // Show form elements.
        const showFormElement = outputElement.querySelectorAll(`${this.state.getStateSelector('resultOutputShowForm', true)}`);
        if (showFormElement) {
            showFormElement.forEach((item)=>{
                item.addEventListener('click', this.onFormShowEvent);
            });
        }
        this.dispatchFormEventForm(this.state.getStateEvent('afterResultsOutput'), formId, data);
    }
    /**
	 * Reset output results.
	 *
	 * @param {string} formId Form Id.
	 *
	 * @returns {void}
	 */ resetResultsOutput(formId) {
        // Check if we have output element - block.
        const outputElement = document.querySelector(`${this.state.getStateSelector('resultOutput', true)}[${this.state.getStateAttribute('formId')}="${formId}"]`);
        if (!outputElement) {
            return;
        }
        // Reset items.
        const itemElements = outputElement.querySelectorAll(this.state.getStateSelector('resultOutputItem', true));
        if (itemElements.length) {
            itemElements.forEach((item)=>{
                item.classList.add(this.state.getStateSelector('isHidden'));
            });
        }
        // Reset parts.
        const partElements = outputElement.querySelectorAll(this.state.getStateSelector('resultOutputPart', true));
        if (partElements.length) {
            partElements.forEach((item)=>{
                if (item.hasAttribute(this.state.getStateAttribute('resultOutputPartDefault'))) {
                    item.innerHTML = item.getAttribute(this.state.getStateAttribute('resultOutputPartDefault'));
                }
            });
        }
    }
    /**
	 * Get comparator object with all available operators.
	 *
	 * is  - is                               - if value is exact match.
	 * isn - is not                           - if value is not exact match.
	 * gt  - greater than                     - if value is greater than.
	 * gte - greater/equal than               - if value is greater/equal than.
	 * lt  - less than                        - if value is less than.
	 * lte - less/equal than                  - if value is less/equal than.
	 * c   - contains                         - if value contains value.
	 * cn  - contains not                     - if value doesn't contain value.
	 * sw  - starts with                      - if value starts with value.
	 * ew  - ends with                        - if value ends with value.
	 * b   - between range                    - if value is between two values.
	 * bs  - between range strict             - if value is between two values strict.
	 * bn  - not between range                - if value is not between two values.
	 * bns - not between between range strict - if value is not between two values strict.
	 *
	 * @returns {object}
	 */ getComparator() {
        return {
            [_manifest_json__WEBPACK_IMPORTED_MODULE_7__.comparator.IS]: (start, value)=>value === start,
            [_manifest_json__WEBPACK_IMPORTED_MODULE_7__.comparator.ISN]: (start, value)=>value !== start,
            [_manifest_json__WEBPACK_IMPORTED_MODULE_7__.comparator.GT]: (start, value)=>parseFloat(String(value)) > parseFloat(String(start)),
            [_manifest_json__WEBPACK_IMPORTED_MODULE_7__.comparator.GTE]: (start, value)=>parseFloat(String(value)) >= parseFloat(String(start)),
            [_manifest_json__WEBPACK_IMPORTED_MODULE_7__.comparator.LT]: (start, value)=>parseFloat(String(value)) < parseFloat(String(start)),
            [_manifest_json__WEBPACK_IMPORTED_MODULE_7__.comparator.LTE]: (start, value)=>parseFloat(String(value)) <= parseFloat(String(start)),
            [_manifest_json__WEBPACK_IMPORTED_MODULE_7__.comparator.C]: (start, value)=>String(value).includes(String(start)),
            [_manifest_json__WEBPACK_IMPORTED_MODULE_7__.comparator.CN]: (start, value)=>!String(value).includes(String(start)),
            [_manifest_json__WEBPACK_IMPORTED_MODULE_7__.comparator.SW]: (start, value)=>String(value).startsWith(String(start)),
            [_manifest_json__WEBPACK_IMPORTED_MODULE_7__.comparator.EW]: (start, value)=>String(value).endsWith(String(start)),
            [_manifest_json__WEBPACK_IMPORTED_MODULE_7__.comparatorExtended.B]: (start, value, end)=>parseFloat(String(value)) > parseFloat(String(start)) && parseFloat(String(value)) < parseFloat(String(end)),
            [_manifest_json__WEBPACK_IMPORTED_MODULE_7__.comparatorExtended.BS]: (start, value, end)=>parseFloat(String(value)) >= parseFloat(String(start)) && parseFloat(String(value)) <= parseFloat(String(end)),
            [_manifest_json__WEBPACK_IMPORTED_MODULE_7__.comparatorExtended.BN]: (start, value, end)=>parseFloat(String(value)) < parseFloat(String(start)) || parseFloat(String(value)) > parseFloat(String(end)),
            [_manifest_json__WEBPACK_IMPORTED_MODULE_7__.comparatorExtended.BNS]: (start, value, end)=>parseFloat(String(value)) <= parseFloat(String(start)) || parseFloat(String(value)) >= parseFloat(String(end))
        };
    }
    /**
	 * Get phone combined value.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 *
	 * @returns {string}
	 */ getPhoneCombinedValue(formId, name) {
        const data = this.state.getStateElementValue(name, formId);
        if (!data || data?.value === '') {
            return '';
        }
        if (!this.state.getStateFormConfigPhoneDisablePicker(formId)) {
            const option = this.state.getStateElementCustom(name, formId).passedElement?.element?.selectedOptions?.[0];
            const type = this.state.getStateElementCustom(name, formId).passedElement?.element?.getAttribute(this.state.getStateAttribute('countryOutputType'));
            const prefixOutput = this.getCountryCombinedValue(formId, name, option, type);
            return data?.prefix === '' || !prefixOutput ? '' : `${prefixOutput}${data?.value}`;
        }
        return data?.value;
    }
    /**
	 * Get country combined value.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 * @param {object} option Option object.
	 * @param {string} type Type of the country.
	 *
	 * @returns {string|array}
	 */ getCountryCombinedValue(formId, name, option, type) {
        const data = this.state.getStateElementValue(name, formId);
        if (!data || data?.value === '') {
            return '';
        }
        switch(type){
            case 'countryCode':
                return option?.getAttribute(this.state.getStateAttribute('countryCode')) || '';
            case 'countryCodeUppercase':
                return option?.getAttribute(this.state.getStateAttribute('countryCode'))?.toUpperCase() || '';
            case 'countryName':
                return option?.getAttribute(this.state.getStateAttribute('countryName')) || '';
            case 'countryUnlocalizedName':
                return option?.getAttribute(this.state.getStateAttribute('countryUnlocalizedName')) || '';
            case 'countryNumber':
                return option?.getAttribute(this.state.getStateAttribute('countryNumber')) || '';
            case 'countryNumberWithPlusPrefix':
                const countryNumber = option?.getAttribute(this.state.getStateAttribute('countryNumber'));
                return countryNumber ? `+${countryNumber}` : '';
            default:
                return '';
        }
    }
    /**
	 * Get country combined value.
	 *
	 * @param {string} formId Form Id.
	 * @param {string} name Field name.
	 *
	 * @returns {string|array}
	 */ getCountryCombinedValues(formId, name) {
        const data = this.state.getStateElementValue(name, formId);
        if (!data || data?.value === '') {
            return [];
        }
        const options = this.state.getStateElementCustom(name, formId).passedElement?.element?.selectedOptions;
        if (!options.length) {
            return [];
        }
        const type = this.state.getStateElementCustom(name, formId).passedElement?.element?.getAttribute(this.state.getStateAttribute('countryOutputType'));
        const output = [];
        [
            ...options
        ].forEach((option)=>{
            const item = this.getCountryCombinedValue(formId, name, option, type);
            if (item) {
                output.push(item);
            }
        });
        return output;
    }
    /**
	 * Build helper for form data object.
	 *
	 * @param {string} formId Form Id.
	 * @param {object} dataSet Object to build.
	 *
	 * @returns {void}
	 */ buildFormDataItems(data, dataSet) {
        data.forEach((item)=>{
            const { name, value, type = 'hidden', typeCustom = 'hidden', custom = '' } = item;
            dataSet.append(name, JSON.stringify({
                name,
                value,
                type,
                typeCustom,
                custom
            }));
        });
    }
    ////////////////////////////////////////////////////////////////
    // Events callback
    ////////////////////////////////////////////////////////////////
    /**
	 * Handle form show event.
	 *
	 * @param {object} event Event callback.
	 * @returns {void}
	 */ onFormShowEvent = (e)=>{
        const outputs = e?.target?.closest(this.state.getStateSelector('resultOutput', true));
        if (!outputs) {
            return;
        }
        outputs?.classList?.add(this.state.getStateSelector('isHidden'));
        for (const formId of this.state.getStateForms()){
            const form = this.state.getStateFormElement(formId);
            if (!form) {
                continue;
            }
            form?.classList?.remove(this.state.getStateSelector('isHidden'));
        }
    };
    ////////////////////////////////////////////////////////////////
    // Private methods - not shared to the public window object.
    ////////////////////////////////////////////////////////////////
    /**
	 * Set all public methods.
	 *
	 * @returns {string}
	 */ publicMethods() {
        (0,_state_init__WEBPACK_IMPORTED_MODULE_5__.setStateWindow)();
        if (window[_state_init__WEBPACK_IMPORTED_MODULE_5__.prefix].utils) {
            return;
        }
        window[_state_init__WEBPACK_IMPORTED_MODULE_5__.prefix].utils = {
            resetErrors: (formId)=>{
                this.resetErrors(formId);
            },
            createCustomEvent: (eventName, formId = null, additional = null)=>{
                return this.createCustomEvent(eventName, formId, additional);
            },
            dispatchFormEventWindow: (eventName, additional = null)=>{
                this.dispatchFormEventWindow(eventName, additional);
            },
            dispatchFormEventForm: (eventName, formId, additional = null)=>{
                this.dispatchFormEventForm(eventName, formId, additional);
            },
            dispatchFormEventField: (eventName, formId, name, value)=>{
                this.dispatchFormEventField(eventName, formId, name, value);
            },
            scrollToElement: (formId, name)=>{
                this.scrollToElement(formId, name);
            },
            scrollAction: (element)=>{
                this.scrollAction(element);
            },
            showLoader: (formId)=>{
                this.showLoader(formId);
            },
            hideLoader: (formId)=>{
                this.hideLoader(formId);
            },
            unsetFieldError: (formId, name)=>{
                this.unsetFieldError(formId, name);
            },
            setFieldError: (formId, name, msg)=>{
                this.setFieldError(formId, name, msg);
            },
            outputErrors: (formId, data)=>{
                this.outputErrors(formId, data);
            },
            unsetGlobalMsg: (formId)=>{
                this.unsetGlobalMsg(formId);
            },
            setGlobalMsg: (formId, msg, status, responseData = {})=>{
                this.setGlobalMsg(formId, msg, status, responseData);
            },
            getGtmData: (formId)=>{
                this.getGtmData(formId);
            },
            gtmSubmit: (formId, status, responseData = {})=>{
                this.gtmSubmit(formId, status, responseData);
            },
            setFieldFilledState: (formId, name)=>{
                this.setFieldFilledState(formId, name);
            },
            setFieldFilledStateByName: (formId, name, condition)=>{
                this.setFieldFilledStateByName(formId, name, condition);
            },
            setActiveState: (formId, name)=>{
                this.setActiveState(formId, name);
            },
            unsetActiveState: (formId, name)=>{
                this.unsetActiveState(formId, name);
            },
            setFilledState: (formId, name)=>{
                this.setFilledState(formId, name);
            },
            unsetFilledState: (formId, name)=>{
                this.unsetFilledState(formId, name);
            },
            resetForm: (formId)=>{
                this.resetForm(formId);
            },
            redirectToUrlByReference: (formId, redirectUrl, reload = false)=>{
                this.redirectToUrlByReference(formId, redirectUrl, reload);
            },
            isFormLoaded: (formId)=>{
                this.isFormLoaded(formId);
            },
            getSaveAsJsonFormatOutput: (formId, name)=>{
                this.getSaveAsJsonFormatOutput(formId, name);
            },
            getFileNameFromFileObject: (file)=>{
                this.getFileNameFromFileObject(file);
            },
            formSubmitResponseError: (formId, actionName, errorName, errorMessage)=>{
                this.formSubmitResponseError(formId, actionName, errorName, errorMessage);
            },
            removeFormsWithMissingFormsBlock: ()=>{
                this.removeFormsWithMissingFormsBlock();
            },
            setOnFocus: (target)=>{
                this.setOnFocus(target);
            },
            setOnBlur: (target)=>{
                this.setOnBlur(target);
            },
            setMandatoryFieldState: (formId, name, value, fullSet = true)=>{
                this.setMandatoryFieldState(formId, name, value, fullSet);
            },
            setManualPhoneValue: (formId, name, value, fullSet = true, set = true)=>{
                this.setManualPhoneValue(formId, name, value, fullSet, set);
            },
            setManualPhonePrefixByAttributeValue: (formId, name, value, attribute, fullSet = true)=>{
                this.setManualPhonePrefixByAttributeValue(formId, name, value, attribute, fullSet);
            },
            setManualDateValue: (formId, name, value, fullSet = true, set = true)=>{
                this.setManualDateValue(formId, name, value, fullSet, set);
            },
            setManualSelectValue: (formId, name, value, fullSet = true, set = true)=>{
                this.setManualSelectValue(formId, name, value, fullSet, set);
            },
            setManualSelectByAttributeValue: (formId, name, value, attribute, fullSet = true)=>{
                this.setManualSelectByAttributeValue(formId, name, value, attribute, fullSet);
            },
            setManualCountryValue: (formId, name, value, fullSet = true, set = true)=>{
                this.setManualCountryValue(formId, name, value, fullSet, set);
            },
            setManualCheckboxValue: (formId, name, value, fullSet = true)=>{
                this.setManualCheckboxValue(formId, name, value, fullSet);
            },
            setManualRadioValue: (formId, name, value, fullSet = true)=>{
                this.setManualRadioValue(formId, name, value, fullSet);
            },
            setManualInputValue: (formId, name, value, fullSet = true, set = true)=>{
                this.setManualInputValue(formId, name, value, fullSet, set);
            },
            setManualRatingValue: (formId, name, value, fullSet = true)=>{
                this.setManualRatingValue(formId, name, value, fullSet);
            },
            setManualRangeValue: (formId, name, value, fullSet = true, set = true)=>{
                this.setManualRangeValue(formId, name, value, fullSet, set);
            },
            setRangeCurrentValue: (formId, name)=>{
                this.setRangeCurrentValue(formId, name);
            },
            setResultsOutput: (formId, data)=>{
                this.setResultsOutput(formId, data);
            },
            resetResultsOutput: (formId)=>{
                this.resetResultsOutput(formId);
            },
            getComparator: ()=>{
                return this.getComparator();
            },
            getPhoneCombinedValue: (formId, name)=>{
                return this.getPhoneCombinedValue(formId, name);
            },
            getCountryCombinedValue: (formId, name, option, type)=>{
                return this.getCountryCombinedValue(formId, name, option, type);
            },
            getCountryCombinedValues: (formId, name)=>{
                return this.getCountryCombinedValues(formId, name);
            },
            buildFormDataItems: (data, dataSet)=>{
                this.buildFormDataItems(data, dataSet);
            },
            onFormShowEvent: (e)=>{
                this.onFormShowEvent(e);
            }
        };
    }
}


/***/ }),

/***/ "./src/Blocks/manifest.json":
/*!**********************************!*\
  !*** ./src/Blocks/manifest.json ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = /*#__PURE__*/JSON.parse('{"$schema":"https://raw.githubusercontent.com/infinum/eightshift-frontend-libs/develop/schemas/globalManifest.json","namespace":"eightshift-forms","background":"#F4FAFA","foreground":"#29A3A3","blockClassPrefix":"es-block","settingsPageUrl":"admin.php?page=es-settings","globalSettingsPageUrl":"admin.php?page=es-settings-global","dashboardPageUrl":"admin.php?page=es-settings-global&type=dashboard","locationsPageUrl":"admin.php?page=es-forms&type=locations","editFormUrl":"post.php?action=edit","config":{"outputCssSelectorName":"esFormsCssVariables","useWrapper":false,"useVariations":false},"unregisterBlocks":{"forms":["eightshift-forms/result-output-item"],"results":["eightshift-forms/form-selector","eightshift-forms/result-output"],"common":["eightshift-forms/form-selector","eightshift-forms/result-output-item"]},"allowedBlocksList":{"formsCpt":["eightshift-forms/form-selector"],"other":["eightshift-forms/forms","eightshift-forms/result-output","eightshift-forms/result-output-item"],"fieldsNoIntegration":["eightshift-forms/file","eightshift-forms/input","eightshift-forms/radios","eightshift-forms/radio","eightshift-forms/select","eightshift-forms/select-option","eightshift-forms/submit","eightshift-forms/textarea","eightshift-forms/checkboxes","eightshift-forms/checkbox","eightshift-forms/phone","eightshift-forms/date","eightshift-forms/country","eightshift-forms/step","eightshift-forms/rating","eightshift-forms/dynamic"],"fieldsIntegration":["eightshift-forms/step"],"integrationsNoBuilder":["eightshift-forms/mailer","eightshift-forms/jira","eightshift-forms/corvus","eightshift-forms/paycek","eightshift-forms/calculator","eightshift-forms/pipedrive","eightshift-forms/nationbuilder"],"integrationsBuilder":["eightshift-forms/mailchimp","eightshift-forms/greenhouse","eightshift-forms/hubspot","eightshift-forms/mailerlite","eightshift-forms/goodbits","eightshift-forms/activecampaign","eightshift-forms/airtable","eightshift-forms/moments","eightshift-forms/workable","eightshift-forms/talentlyft"]},"showAsMap":{"options":[{"label":"Select","value":"select"},{"label":"Radios","value":"radios"},{"label":"Checkboxes","value":"checkboxes"}],"checkboxes-select":{"names":{"checkboxes":{"top":"select","children":"select-option"},"select":{"top":"checkboxes","children":"checkbox"}},"prefix":{"checkboxes":{"from":"checkboxesCheckboxes","to":"selectSelect"},"select":{"from":"selectSelect","to":"checkboxesCheckboxes"}},"top":{"checkboxesCheckboxesContent":"selectSelectContent","checkboxesCheckboxesName":"selectSelectName","checkboxesCheckboxesIsRequired":"selectSelectIsRequired","checkboxesCheckboxesMeta":"selectSelectMeta","checkboxesCheckboxesDisabledOptions":"selectSelectDisabledOptions","checkboxesCheckboxesTypeCustom":"selectSelectTypeCustom","checkboxesCheckboxesShowAs":"selectSelectShowAs","checkboxesCheckboxesFieldAttrs":"selectSelectFieldAttrs","checkboxesCheckboxesPlaceholder":"selectSelectPlaceholder","checkboxesCheckboxesUseLabelAsPlaceholder":"selectSelectUseLabelAsPlaceholder"},"children":{"checkboxCheckboxLabel":"selectOptionSelectOptionLabel","checkboxCheckboxValue":"selectOptionSelectOptionValue","checkboxCheckboxIsChecked":"selectOptionSelectOptionIsSelected","checkboxCheckboxIsDisabled":"selectOptionSelectOptionIsDisabled","checkboxCheckboxAttrs":"selectOptionSelectOptionAttrs","checkboxCheckboxIsHidden":"selectOptionSelectOptionIsHidden","checkboxCheckboxDisabledOptions":"selectOptionSelectOptionDisabledOptions"},"append":{"checkboxes":{"selectSelectIsMultiple":true}}},"checkboxes-radios":{"names":{"checkboxes":{"top":"radios","children":"radio"},"radios":{"top":"checkboxes","children":"checkbox"}},"prefix":{"checkboxes":{"from":"checkboxesCheckboxes","to":"radiosRadios"},"radios":{"from":"radiosRadios","to":"checkboxesCheckboxes"}},"top":{"checkboxesCheckboxesContent":"radiosRadiosContent","checkboxesCheckboxesName":"radiosRadiosName","checkboxesCheckboxesIsRequired":"radiosRadiosIsRequired","checkboxesCheckboxesMeta":"radiosRadiosMeta","checkboxesCheckboxesDisabledOptions":"radiosRadiosDisabledOptions","checkboxesCheckboxesTypeCustom":"radiosRadiosTypeCustom","checkboxesCheckboxesShowAs":"radiosRadiosShowAs","checkboxesCheckboxesFieldAttrs":"radiosRadiosFieldAttrs"},"children":{"checkboxCheckboxLabel":"radioRadioLabel","checkboxCheckboxValue":"radioRadioValue","checkboxCheckboxIsChecked":"radioRadioIsSelected","checkboxCheckboxIsDisabled":"radioRadioIsDisabled","checkboxCheckboxAttrs":"radioRadioAttrs","checkboxCheckboxIsHidden":"radioRadioIsHidden","checkboxCheckboxDisabledOptions":"radioRadioDisabledOptions"}},"radios-select":{"names":{"select":{"top":"radios","children":"radio"},"radios":{"top":"select","children":"select-option"}},"prefix":{"select":{"from":"selectSelect","to":"radiosRadios"},"radios":{"from":"radiosRadios","to":"selectSelect"}},"top":{"radiosRadiosContent":"selectSelectContent","radiosRadiosName":"selectSelectName","radiosRadiosIsRequired":"selectSelectIsRequired","radiosRadiosMeta":"selectSelectMeta","radiosRadiosDisabledOptions":"selectSelectDisabledOptions","radiosRadiosTypeCustom":"selectSelectTypeCustom","radiosRadiosShowAs":"selectSelectShowAs","radiosRadiosFieldAttrs":"selectSelectFieldAttrs","radiosRadiosPlaceholder":"selectSelectPlaceholder","radiosRadiosUseLabelAsPlaceholder":"selectSelectUseLabelAsPlaceholder"},"children":{"radioRadioLabel":"selectOptionSelectOptionLabel","radioRadioValue":"selectOptionSelectOptionValue","radioRadioIsChecked":"selectOptionSelectOptionIsSelected","radioRadioIsDisabled":"selectOptionSelectOptionIsDisabled","radioRadioAttrs":"selectOptionSelectOptionAttrs","radioRadioIsHidden":"selectOptionSelectOptionIsHidden","radioRadioDisabledOptions":"selectOptionSelectOptionDisabledOptions"}}},"globalVariables":{"customBlocksName":"eightshift-block","esMaxCols":12,"esfSpacingXs":"0.25rem","esfSpacingS":"0.5rem","esfSpacingM":"1rem","esfSpacingL":"1.5rem","esfSpacingXl":"2rem","esfEaseOutCubic":"cubic-bezier(0.215, 0.61, 0.355, 1)","esfBoxShadow":"0 0 0.5rem rgb(0 0 0 / 0.04)","esfBoxShadowL":"0 0 0.125rem rgb(0 0 0 / 0.16), 0 0 0.5rem rgb(0 0 0 / 0.16)","esfMaxWidth":"36rem","esfInputHeight":"2.625rem","breakpoints":{"mobile":480,"tablet":960,"desktop":1920,"large":1921},"colors":[{"name":"Admin accent","slug":"esf-admin-accent","color":"#29A3A3"},{"name":"Admin accent 50%","slug":"esf-admin-accent-50","color":"#29A3A380"},{"name":"Admin accent 30%","slug":"esf-admin-accent-30","color":"#29a3a333"},{"name":"Admin accent 10%","slug":"esf-admin-accent-10","color":"#29A3A31A"},{"name":"Admin accent 5%","slug":"esf-admin-accent-05","color":"#29A3A30D"},{"name":"Admin accent dark","slug":"esf-admin-accent-dark","color":"#218282"},{"name":"ESF border","slug":"esf-border","color":"#DEDEDE"},{"name":"ESF black","slug":"esf-black","color":"#181818"},{"name":"ESF white","slug":"esf-white","color":"#FFFFFF"},{"name":"ESF gray","slug":"esf-gray","color":"#484848"},{"name":"ESF yellow 50","slug":"esf-yellow-50","color":"#FFFBEB"},{"name":"ESF yellow 100","slug":"esf-yellow-100","color":"#FEF3C7"},{"name":"ESF yellow 200","slug":"esf-yellow-200","color":"#FDE68A"},{"name":"ESF yellow 500","slug":"esf-yellow-500","color":"#EAB308"},{"name":"ESF yellow 950","slug":"esf-yellow-950","color":"#451A03"},{"name":"ESF sky 50","slug":"esf-sky-50","color":"#F0F9FF"},{"name":"ESF sky 100","slug":"esf-sky-100","color":"#E0F2FE"},{"name":"ESF sky 200","slug":"esf-sky-200","color":"#BAE6FD"},{"name":"ESF sky 500","slug":"esf-sky-500","color":"#0EA5E9"},{"name":"ESF sky 950","slug":"esf-sky-950","color":"#082F49"},{"name":"ESF gray 50","slug":"esf-gray-50","color":"#F9FAFB"},{"name":"ESF gray 100","slug":"esf-gray-100","color":"#F3F4F6"},{"name":"ESF gray 200","slug":"esf-gray-200","color":"#E5E7EB"},{"name":"ESF gray 300","slug":"esf-gray-300","color":"#D1D5DB"},{"name":"ESF gray 400","slug":"esf-gray-400","color":"#9CA3AF"},{"name":"ESF gray 500","slug":"esf-gray-500","color":"#6B7280"},{"name":"ESF gray 600","slug":"esf-gray-600","color":"#4B5563"},{"name":"ESF gray 950","slug":"esf-gray-950","color":"#030712"},{"name":"ESF red 50","slug":"esf-red-50","color":"#FEF2F2"},{"name":"ESF red 100","slug":"esf-red-100","color":"#FEE2E2"},{"name":"ESF red 200","slug":"esf-red-200","color":"#FECACA"},{"name":"ESF red 500","slug":"esf-red-500","color":"#EF4444"},{"name":"ESF red 400","slug":"esf-red-400","color":"#F87171"},{"name":"ESF red 600","slug":"esf-red-600","color":"#DC2626"},{"name":"ESF red 800","slug":"esf-red-800","color":"#991B1B"},{"name":"ESF red 950","slug":"esf-red-950","color":"#450A0A"},{"name":"ESF green 50","slug":"esf-green-50","color":"#F0FDF4"},{"name":"ESF green 100","slug":"esf-green-100","color":"#DCFCE7"},{"name":"ESF green 200","slug":"esf-green-200","color":"#BBF7D0"},{"name":"ESF green 500","slug":"esf-green-500","color":"#22C55E"},{"name":"ESF green 950","slug":"esf-green-950","color":"#052E16"}]},"enums":{"events":{"beforeFormSubmit":"esFormsBeforeFormSubmit","afterFormSubmit":"esFormsAfterFormSubmit","afterFormSubmitSuccess":"esFormsAfterFormSubmitSuccess","afterFormSubmitError":"esFormsAfterFormSubmitError","afterFormSubmitErrorValidation":"esFormsAfterFormSubmitErrorValidation","afterFormSubmitEnd":"esFormsAfterFormSubmitEnd","afterGtmDataPush":"esFormsAfterGtmDataPush","afterFormSubmitReset":"esFormsAfterFormSubmitReset","afterFormSubmitSuccessBeforeRedirect":"esFormsAfterFormSubmitSuccessBeforeRedirect","formJsLoaded":"esFormsJsFormLoaded","formManualInitLoaded":"esFormsManualInitLoaded","afterCaptchaInit":"esFormsAfterCaptchaInit","stepsGoToNextStep":"esFormsGoToNextStep","stepsGoToPrevStep":"esFormsGoToPrevStep","stepsResetSteps":"esFormsResetSteps","beforeEnrichmentUrlPrefill":"esFormsBeforeEnrichmentUrlPrefill","afterEnrichmentUrlPrefill":"esFormsAfterEnrichmentUrlPrefill","beforeEnrichmentLocalstoragePrefill":"esFormsBeforeEnrichmentLocalstoragePrefill","afterEnrichmentLocalstoragePrefill":"esFormsAfterEnrichmentLocalstoragePrefill","onFieldChange":"esFormsOnFieldChange","afterResultsOutput":"esFormsAfterResultsOutput"},"typeInternal":{"input":"input","textarea":"textarea","radio":"radio","radios":"radio","checkbox":"checkbox","checkboxes":"checkbox","phone":"phone","file":"file","country":"country","date":"date","dateTime":"dateTime","select":"select","rating":"rating","range":"range","submit":"submit"},"selectorsAdmin":{"singleSubmit":"js-es-block-single-submit","listingSearch":"js-es-admin-listing-search","listingPerPage":"js-es-admin-listing-per-page","listingItem":"js-es-admin-listing-item","listingLocations":"js-es-admin-listing-locations","listingBulk":"js-es-admin-listing-bulk","listingBulkItems":"js-es-admin-listing-bulk-items","listingExport":"js-es-admin-listing-export","listingSelectAll":"js-es-admin-listing-select-all","cacheDelete":"js-es-cache-delete","incrementReset":"js-es-increment-reset","migration":"js-es-migration","migrationOutput":"js-es-migration-output","transfer":"js-es-transfer","transferItem":"js-es-transfer-item","transferUpload":"js-es-transfer-upload","transferExisting":"js-es-transfer-existing","testApi":"js-es-api-test","manualSubmitTrigger":"js-es-manual-submit-trigger","manualSubmitData":"js-es-manual-submit-data","tabs":"js-es-tabs","tabsItem":"js-es-tabs-item","debugEncryption":"js-es-debug-encryption","debugEncryptionType":"js-es-debug-encryption-type","debugEncryptionOutput":"js-es-debug-encryption-output","debugEncryptionRun":"js-es-debug-encryption-run"},"selectors":{"isActive":"es-form-is-active","isFilled":"es-form-is-filled","isLoading":"es-form-is-loading","isHidden":"es-form-is-hidden","isDisabled":"es-form-is-disabled","isGeoLoading":"es-form-is-geolocation-loading","hasError":"es-form-has-error","isStepPreviewActive":"es-form-is-step-preview-active","forms":"js-es-block-forms","form":"js-es-block-form","submitSingle":"js-es-block-single-submit","step":"js-es-block-step","stepProgressBar":"js-es-block-step-progress-bar","stepProgressBarMultiflow":"js-es-block-step-progress-bar-multiflow","stepSubmit":"js-es-block-step-trigger","stepDebugPreview":"js-es-block-step-debug-preview","error":"js-es-block-error","loader":"js-es-block-loader","globalMsg":"js-es-block-global-msg","group":"js-es-block-group","field":"js-es-block-field","fieldNoFormsBlock":"js-es-block-field-custom","fileButton":"js-es-block-file-button","rating":"js-es-block-rating","resultOutput":"js-es-block-result-output","resultOutputItem":"js-es-block-result-output-item","resultOutputPart":"js-es-block-result-output-part","resultOutputShowForm":"js-es-block-result-output-show-form","inputRangeMin":"js-es-block-input-range-min","inputRangeMax":"js-es-block-input-range-max","inputRangeCurrent":"js-es-block-input-range-current"},"params":{"formId":"es-form-form-id","postId":"es-form-post-id","type":"es-form-type","name":"es-form-field-name","steps":"es-form-steps","settingsType":"es-form-settings-type","singleSubmit":"es-form-single-submit","storage":"es-form-storage","action":"es-form-action","actionExternal":"es-form-action-external","conditionalTags":"es-form-conditional-tags","fileId":"es-form-file-id","hubspotCookie":"es-form-hubspot-cookie","hubspotPageName":"es-form-hubspot-page-name","hubspotPageUrl":"es-form-hubspot-page-url","mailchimpTags":"es-form-mailchimp-tags","captcha":"es-form-captcha","direct":"es-form-direct","itemId":"es-form-item-id","innerId":"es-form-inner-id","skippedParams":"es-form-skipped","secureData":"es-form-secure-data"},"attrs":{"formType":"data-form-type","formCustomName":"data-form-custom-name","formId":"data-form-id","formFid":"data-form-fid","formGeolocation":"data-form-geolocation","bulkId":"data-bulk-id","bulkType":"data-bulk-type","bulkItems":"data-bulk-items","exportType":"data-export-type","manualSubmitId":"data-manual-submit-id","stepId":"data-step-id","submitStepDirection":"data-step-direction","postId":"data-post-id","fieldId":"data-field-id","fieldName":"data-field-name","fieldType":"data-field-type","fieldPreventSubmit":"data-field-prevent-submit","fieldTypeCustom":"data-type-custom","fieldUncheckedValue":"data-unchecked-value","formSecureData":"data-secure-data","trackingEventName":"data-tracking-event-name","trackingAdditionalData":"data-tracking-additional-data","tracking":"data-tracking","cacheType":"data-cache-type","testApiType":"data-test-api-type","locationsId":"data-locations-id","locationsType":"data-locations-type","migrationType":"data-migration-type","migrationExportItems":"data-migration-export-items","successRedirect":"data-success-redirect","successRedirectVariation":"data-success-redirect-variation","successRedirectDownloads":"data-success-redirect-downloads","conditionalTags":"data-conditional-tags","typeSelector":"data-type-selector","actionExternal":"data-action-external","settingsType":"data-settings-type","groupSaveAsOneField":"data-group-save-as-one-field","multistepSkipScroll":"data-multistep-skip-scroll","datePreviewFormat":"data-preview-format","dateOutputFormat":"data-output-format","dateMode":"data-mode","selectAllowSearch":"data-allow-search","selectIsMultiple":"data-is-multiple","selectPlaceholder":"data-placeholder","selectCustomProperties":"data-custom-properties","selectOptionIsHidden":"data-option-is-hidden","selectId":"data-id","selectValue":"data-value","countryOutputType":"data-country-output-type","countryCode":"data-country-code","countryName":"data-country-name","countryNumber":"data-country-number","countryUnlocalizedName":"data-country-unlocalized-name","ratingValue":"data-rating","phoneSync":"data-phone-sync","phoneDisablePicker":"data-phone-disable-picker","saveAsJson":"data-save-as-json","blockSsr":"data-block-ssr","disabledDefaultStyles":"data-disabled-default-styles","globalMsgHeadingSuccess":"data-msg-heading-success","globalMsgHeadingError":"data-msg-heading-error","globalMsgHideOnSuccess":"data-msg-hide-on-success","formHideOnSuccess":"data-form-hide-on-success","hideCaptchaBadge":"data-hide-captcha-badge","reload":"data-reload","hubspotTypeId":"data-hubspot-type-id","resultOutputItemKey":"data-result-output-item-key","resultOutputItemValueStart":"data-result-output-item-value-start","resultOutputItemValueEnd":"data-result-output-item-value-end","resultOutputItemOperator":"data-result-output-item-operator","resultOutputPart":"data-result-output-part","resultOutputPartDefault":"data-result-output-part-default","singleSubmit":"data-single-submit","adminIntegrationType":"data-integration-type"},"responseOutputKeys":{"validation":"validation","processExternally":"processExternally","postExternallyData":"postExternallyData","addon":"addonData","successRedirectUrl":"successRedirectUrl","successRedirectBaseUrl":"successRedirectBaseUrl","fileName":"fileName","stepType":"stepType","stepNextStep":"stepNextStep","stepProgressBarItems":"stepProgressBarItems","stepIsDisableNextButton":"stepIsDisableNextButton","trackingEventName":"trackingEventName","trackingAdditionalData":"trackingAdditionalData","hideGlobalMsgOnSuccess":"hideGlobalMsgOnSuccess","hideFormOnSuccess":"hideFormOnSuccess","skipResetFormOnSuccess":"skipResetFormOnSuccess","variation":"variation","entry":"entry","formId":"formId","geoId":"geoId","incrementId":"incrementId","captchaIsSpam":"captchaIsSpam","captchaRetry":"captchaRetry","captchaResponse":"captchaResponse","geolocationCountries":"countries","editorIntegrationItems":"integrationItems","editorSyncForm":"syncForm","editorFormFields":"fields","editorFormFieldsSteps":"steps","editorFormFieldsStepsFull":"stepsFull","editorFormFieldsNames":"names","adminNoticeTitle":"noticeTitle","adminEncrypt":"encrypt","adminLocations":"locations","adminTransferName":"transferName","adminTransferContent":"transferContent","adminExportContent":"exportContent","adminMigration":"migration"},"successRedirectUrlKeys":{"variation":"es-variation","entry":"es-entry","customResultOutput":"es-ro","data":"es-data"}},"comparator":{"IS":"is","ISN":"isn","GT":"gt","GTE":"gte","LT":"lt","LTE":"lte","C":"c","CN":"cn","SW":"sw","EW":"ew"},"comparatorExtended":{"B":"b","BS":"bs","BN":"bn","BNS":"bns"},"comparatorActions":{"SHOW":"show","HIDE":"hide"},"comparatorLogic":{"OR":"or","AND":"and"},"icons":{"dashboard":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M7 1H2.5A1.5 1.5 0 0 0 1 2.5V7a1.5 1.5 0 0 0 1.5 1.5H7A1.5 1.5 0 0 0 8.5 7V2.5A1.5 1.5 0 0 0 7 1Zm0 10.5H2.5A1.5 1.5 0 0 0 1 13v4.5A1.5 1.5 0 0 0 2.5 19H7a1.5 1.5 0 0 0 1.5-1.5V13A1.5 1.5 0 0 0 7 11.5ZM17.5 1H13a1.5 1.5 0 0 0-1.5 1.5V7A1.5 1.5 0 0 0 13 8.5h4.5A1.5 1.5 0 0 0 19 7V2.5A1.5 1.5 0 0 0 17.5 1Zm0 10.5H13a1.5 1.5 0 0 0-1.5 1.5v4.5A1.5 1.5 0 0 0 13 19h4.5a1.5 1.5 0 0 0 1.5-1.5V13a1.5 1.5 0 0 0-1.5-1.5Z\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/></svg>","general":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'m2.5 3 1.688 1.75L7 1.25\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'2.5\' y=\'8.46429\' width=\'3.5\' height=\'3.5\' rx=\'1\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'2.5\' y=\'1.46429\' width=\'3.5\' height=\'3.5\' rx=\'1\' stroke=\'currentColor\' stroke-opacity=\'0.12\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'2.5\' y=\'15.4643\' width=\'3.5\' height=\'3.5\' rx=\'1\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M9.5 3.214h8m-8 7H16m-6.5 7h8\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","validation":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M9.151 1.863a1 1 0 0 1 1.698 0l1.136 1.825a1 1 0 0 0 1.075.445l2.093-.487a1 1 0 0 1 1.2 1.2l-.486 2.094a1 1 0 0 0 .445 1.075l1.825 1.136a1 1 0 0 1 0 1.698l-1.825 1.136a1 1 0 0 0-.445 1.075l.487 2.093a1 1 0 0 1-1.2 1.2l-2.094-.486a1 1 0 0 0-1.075.445l-1.136 1.825a1 1 0 0 1-1.698 0l-1.136-1.825a1 1 0 0 0-1.075-.445l-2.093.487a1 1 0 0 1-1.2-1.2l.486-2.094a1 1 0 0 0-.445-1.075l-1.825-1.136a1 1 0 0 1 0-1.698l1.825-1.136a1 1 0 0 0 .445-1.075l-.487-2.093a1 1 0 0 1 1.2-1.2l2.094.486a1 1 0 0 0 1.075-.445l1.136-1.825Z\' stroke=\'currentColor\' fill=\'none\'/><path d=\'m7.5 10 1.875 1.75 3.125-3.5\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","captcha":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M10 3H6.5A1.5 1.5 0 0 0 5 4.5v4A1.5 1.5 0 0 0 6.5 10h7A1.5 1.5 0 0 0 15 8.5v-4A1.5 1.5 0 0 0 13.5 3H10Zm0 0V1\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'m8.5 8 .06-.06a1.5 1.5 0 0 1 1.061-.44h.758a1.5 1.5 0 0 1 1.06.44L11.5 8\' stroke=\'currentColor\' stroke-opacity=\'0.3\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'m2.572 19-.307-3.756A3 3 0 0 1 5.255 12h10.739c.82 0 1.508.532 1.753 1.26\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><circle cx=\'16\' cy=\'17\' r=\'3\' fill=\'currentColor\' fill-opacity=\'0.12\'/><path d=\'m17.5 18.5-3-3m0 3 3-3\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><circle cx=\'8.25\' cy=\'5.75\' r=\'0.75\' fill=\'currentColor\'/><circle cx=\'11.75\' cy=\'5.75\' r=\'0.75\' fill=\'currentColor\'/></svg>","geolocation":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M16 7.36c0 4.627-4.165 9.626-5.827 11.436-.368.4-.978.4-1.346 0C7.165 16.986 3 11.987 3 7.359 3 3.847 5.91 1 9.5 1S16 3.847 16 7.36Z\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><circle cx=\'9.5\' cy=\'7.5\' r=\'1.75\' fill=\'currentColor\' fill-opacity=\'0.3\' stroke=\'currentColor\'/></svg>","enrichment":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M13.256 3.583c.059-.26.43-.26.488 0l.534 2.371a3 3 0 0 0 2.268 2.268l2.371.534c.26.059.26.43 0 .488l-2.371.534a3 3 0 0 0-2.268 2.268l-.534 2.371c-.059.26-.43.26-.488 0l-.534-2.371a3 3 0 0 0-2.268-2.268l-2.371-.534c-.26-.059-.26-.43 0-.488l2.371-.534a3 3 0 0 0 2.268-2.268l.534-2.371ZM4.85 1.166c.036-.16.264-.16.3 0l.42 1.868c.157.695.7 1.239 1.396 1.395l1.868.42c.16.037.16.265 0 .301l-1.868.42c-.695.157-1.239.7-1.395 1.396l-.42 1.868c-.037.16-.265.16-.301 0l-.42-1.868a1.846 1.846 0 0 0-1.396-1.395l-1.868-.42c-.16-.037-.16-.265 0-.301l1.868-.42a1.846 1.846 0 0 0 1.395-1.396l.42-1.868Zm2 11c.036-.16.264-.16.3 0l.329 1.46c.157.695.7 1.239 1.395 1.395l1.46.329c.16.036.16.264 0 .3l-1.46.329c-.695.157-1.238.7-1.395 1.395l-.329 1.46c-.036.16-.264.16-.3 0l-.329-1.46a1.846 1.846 0 0 0-1.395-1.395l-1.46-.329c-.16-.036-.16-.264 0-.3l1.46-.329a1.846 1.846 0 0 0 1.395-1.395l.329-1.46Z\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","blocks":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M9 11V4.5A1.5 1.5 0 0 0 7.5 3h-5A1.5 1.5 0 0 0 1 4.5V11m8 0H1m8 0v8m0-8h6.5a1.5 1.5 0 0 1 1.5 1.5v5a1.5 1.5 0 0 1-1.5 1.5H9m-8-8v6.5A1.5 1.5 0 0 0 2.5 19H9\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M13.096 1.404 9.561 4.939a1.5 1.5 0 0 0 0 2.122l3.535 3.535a1.5 1.5 0 0 0 2.121 0l3.536-3.535a1.5 1.5 0 0 0 0-2.122l-3.536-3.535a1.5 1.5 0 0 0-2.12 0Z\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/></svg>","mailer":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><rect x=\'1\' y=\'4\' width=\'18\' height=\'12\' rx=\'1.5\' stroke=\'currentColor\' fill=\'none\'/><path d=\'m1.5 4.5 7.589 5.803a1.5 1.5 0 0 0 1.822 0L18.5 4.5m-17 11 5.687-6.651M18.5 15.5l-5.687-6.651\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","mailchimp":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M11 2 6.5 5.5l4-1L15 5l1-1V2l-1-1h-1.5L11 2Z\' fill=\'currentColor\' fill-opacity=\'0.3\'/><path d=\'M4.37 4.218 1.907 8.32a1.444 1.444 0 0 0 1.883 2.034l.153-.076a1.5 1.5 0 0 0 .752-.867l.715-2.142a1.5 1.5 0 0 1 .27-.486l2.18-2.616a1.5 1.5 0 0 1 .32-.288l2.001-1.334a.806.806 0 0 0-.605-1.46l-1.704.34a1.5 1.5 0 0 0-.666.319L4.695 3.837a1.5 1.5 0 0 0-.326.38Z\' fill=\'currentColor\' fill-opacity=\'0.12\'/><path d=\'M2.927 11.43c-.615-.488-1.661-1.85-.923-3.408.923-1.947 3.23-5.354 5.076-6.328 2.662-1.404 2.768-.973 4.152 0\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M4.772 9.969c0-1.947 1.044-5.94 8.306-9.005 2.307-.973 4.614 1.541 1.846 4.137\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M14.924 5.101c-2.153-.649-6.737-1.752-9.69 2.92m9.69-2.92c.307.65.923 2.19.923 4.138.922.243 2.491 1.022 1.384 2.19.769.487 1.845 2.142 0 4.868-1.846 2.725-5.076 3.082-6.46 2.92-1.23-.162-3.968-1.265-5.076-4.38\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M15.617 7.535c-.154-.487-1.062-1.655-2.538-.487-1.697 1.343-3.23-1.46-3.692 1.947 0 .325.185 1.266.923 2.434-.769.974-1.485 2.761-.461 4.38.923 1.461 3.23 2.921 7.382.488\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M17.23 11.43c-.46.486-1.845 1.46-3.69 1.46-1.846 0-2.308.648-2.308.973.154 1.136 1.246 3.115 5.307 0m-5.064-4.031c.176-.2.651-.5 1.15-.1m1.376-1.223.23.73\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><ellipse cx=\'14.1168\' cy=\'11.0641\' rx=\'0.576772\' ry=\'0.608433\' fill=\'currentColor\'/><ellipse cx=\'14.8082\' cy=\'10.8207\' rx=\'0.576772\' ry=\'0.608433\' fill=\'currentColor\'/><path d=\'M2.927 11.43c.566-1.088 1.384-1.461 1.846-1.461.461 0 1.846.487 1.846 2.92 0 2.613-3.158 1.835-3.62.861-.5-1-.499-1.5-.072-2.32Z\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M5.695 14.35c-.308-.812-.826-2.49-1.195-2.1\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","greenhouse":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'21\' viewBox=\'0 0 20 21\' fill=\'none\'><circle cx=\'10\' cy=\'15.38\' r=\'3.75\' stroke=\'currentColor\' fill=\'none\'/><circle cx=\'10\' cy=\'5.88\' r=\'2.75\' stroke=\'currentColor\' fill=\'none\'/><circle cx=\'13\' cy=\'1.38\' r=\'1.25\' fill=\'currentColor\'/><path d=\'M9.25 8.63c.5.5 1.2 1.8 0 3\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M10.912 8.63c-.5.5-1.2 1.8 0 3m1.885-10.5c-.085.452-.513 1.454-1.547 1.843\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M13.371 1.612c-.43.162-1.343.758-1.547 1.843\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","hubspot":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'m11 15-2.12 1.697M14.25 4v3.5M11 8.625 3.863 3.272\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><circle cx=\'14.25\' cy=\'11.75\' r=\'4.25\' stroke=\'currentColor\' fill=\'none\'/><circle cx=\'2.5\' cy=\'2.5\' r=\'1.5\' fill=\'currentColor\' fill-opacity=\'0.5\' stroke=\'currentColor\'/><circle cx=\'14.25\' cy=\'2.5\' r=\'1.5\' fill=\'currentColor\' fill-opacity=\'0.5\' stroke=\'currentColor\'/><circle cx=\'7.5\' cy=\'17.5\' r=\'1.5\' fill=\'currentColor\' fill-opacity=\'0.5\' stroke=\'currentColor\'/></svg>","goodbits":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'m6.5 13.5 2.358-7.074m.249 7.074 2.358-7.074m.25 7.074 2.358-7.074\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><circle cx=\'10\' cy=\'10\' r=\'9\' stroke=\'currentColor\' fill=\'none\'/></svg>","mailerlite":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M4.25 11.25v-5m2.5 5v-3\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'m11.25 11.2-.304.06a1 1 0 0 1-1.196-.98V6.25l-1 1h2\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><circle cx=\'6.75\' cy=\'6.5\' r=\'0.75\' fill=\'currentColor\'/><path d=\'M13 9h3.25v-.725c0-.897-.727-1.625-1.625-1.625v0c-.898 0-1.625.728-1.625 1.625V9Zm0 0v.4c0 2 1.5 2.1 3.25 1.668\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M3.676 14.703 1 17.5V4a1.5 1.5 0 0 1 1.5-1.5h15A1.5 1.5 0 0 1 19 4v9.203a1.5 1.5 0 0 1-1.5 1.5H3.676Z\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\'/></svg>","clearbit":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M1 3a2 2 0 0 1 2-2h5v18H3a2 2 0 0 1-2-2V3Z\' fill=\'currentColor\' fill-opacity=\'0.5\' stroke=\'currentColor\'/><path d=\'M11 1h5.5a2 2 0 0 1 2 2v5.5H11V1Z\' fill=\'currentColor\' fill-opacity=\'0.3\' stroke=\'currentColor\'/><path d=\'M11 11.5h7.5V17a2 2 0 0 1-2 2H11v-7.5Z\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\'/></svg>","activecampaign":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'m5 1.5 10.272 7.276a1.5 1.5 0 0 1 0 2.448L5 18.5m0-12 5.5 3.5\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/></svg>","airtable":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M1.5 13.595V7.88c0-.18.184-.3.348-.23l6.157 2.639a.25.25 0 0 1 .013.453L1.862 13.82a.25.25 0 0 1-.362-.224Z\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\' stroke-linejoin=\'round\'/><path d=\'M9.91 2.783 3.087 5.285a.25.25 0 0 0-.013.464l6.83 2.96a.25.25 0 0 0 .193.002l6.823-2.729a.25.25 0 0 0 0-.464l-6.831-2.732a.25.25 0 0 0-.179-.003Z\' fill=\'currentColor\' fill-opacity=\'0.3\' stroke=\'currentColor\' stroke-linejoin=\'round\'/><path d=\'M18.5 14.329V8.115a.25.25 0 0 0-.34-.233l-7.25 2.806a.25.25 0 0 0-.16.233v6.214a.25.25 0 0 0 .34.233l7.25-2.806a.25.25 0 0 0 .16-.233Z\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\' stroke-linejoin=\'round\'/><path d=\'M8 10.6 1.5 10V7.5L8 10.6Z\' fill=\'currentColor\' fill-opacity=\'0.12\'/></svg>","moments":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M4.565 8.068a3.715 3.715 0 0 1 3.503-3.503C8.738 4.527 9.415 4.5 10 4.5s1.263.027 1.932.065a3.715 3.715 0 0 1 3.503 3.503c.038.67.065 1.347.065 1.932s-.027 1.263-.065 1.932a3.715 3.715 0 0 1-3.503 3.503c-.67.038-1.348.065-1.932.065-.585 0-1.263-.027-1.932-.065a3.715 3.715 0 0 1-3.503-3.503A35.094 35.094 0 0 1 4.5 10c0-.585.027-1.263.065-1.932Z\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M1.086 7.208a6.463 6.463 0 0 1 6.122-6.122A54.348 54.348 0 0 1 10 1c.849 0 1.819.035 2.792.086a6.463 6.463 0 0 1 6.122 6.122C18.965 8.181 19 9.151 19 10c0 .849-.035 1.819-.086 2.792a6.463 6.463 0 0 1-6.122 6.122c-.973.051-1.943.086-2.792.086-.849 0-1.819-.035-2.792-.086a6.463 6.463 0 0 1-6.122-6.122A54.348 54.348 0 0 1 1 10c0-.849.035-1.819.086-2.792Z\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'8\' y=\'8\' width=\'4\' height=\'4\' rx=\'1\' fill=\'currentColor\' fill-opacity=\'0.5\' stroke=\'currentColor\' stroke-linejoin=\'round\'/></svg>","cache":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M1 10h18M1 10v4.5A1.5 1.5 0 0 0 2.5 16h15a1.5 1.5 0 0 0 1.5-1.5V10M1 10l2.13-5.538a1.5 1.5 0 0 1 1.4-.962h11.362a1.5 1.5 0 0 1 1.434 1.059L19 10\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M13 13h3\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><circle cx=\'4.25\' cy=\'13\' r=\'0.75\' fill=\'currentColor\' fill-opacity=\'0.5\'/></svg>","location":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><rect x=\'1\' y=\'2\' width=\'18\' height=\'16\' rx=\'1.5\' stroke=\'currentColor\' fill=\'none\'/><path d=\'M1.5 6.5h17\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'2.25\' y=\'3.5\' width=\'1.5\' height=\'1.5\' rx=\'0.5\' fill=\'currentColor\'/><rect x=\'4.5\' y=\'3.5\' width=\'1.5\' height=\'1.5\' rx=\'0.5\' fill=\'currentColor\'/><path d=\'M9 4a.5.5 0 0 1 .5-.5h7.75a.5.5 0 0 1 .5.5v.5a.5.5 0 0 1-.5.5H9.5a.5.5 0 0 1-.5-.5V4Z\' fill=\'currentColor\' fill-opacity=\'0.5\'/><rect x=\'6.75\' y=\'3.5\' width=\'1.5\' height=\'1.5\' rx=\'0.5\' fill=\'currentColor\'/></svg>","fallback":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M19 12V5.5A1.5 1.5 0 0 0 17.5 4h-15A1.5 1.5 0 0 0 1 5.5v9A1.5 1.5 0 0 0 2.5 16H11\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M1.5 4.5 10 11l8.5-6.5m-17 11 5.687-6.651m5.626 0 2.133 2.494\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><circle cx=\'15.75\' cy=\'15.75\' r=\'3.75\' fill=\'currentColor\' fill-opacity=\'0.12\'/><path d=\'M17.75 17.75 14 14m0 3.75L17.75 14\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","migration":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M14 13H2.5A1.5 1.5 0 0 1 1 11.5v-9A1.5 1.5 0 0 1 2.5 1h9A1.5 1.5 0 0 1 13 2.5V4m1 9-2 2m2-2-2-2\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M6 7h11.5A1.5 1.5 0 0 1 19 8.5v9a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 7 17.5V16M6 7l2-2M6 7l2 2\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","transfer":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M13 10V6h3l-4-5-5 5h3v8h3l-4 5-5-5h3v-4\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","debug":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'m1.469 17.245 1.286 1.286a1.6 1.6 0 0 0 2.263 0l6.663-6.662c.424-.425 1.05-.556 1.646-.477 1.521.2 3.088-.265 4.226-1.403 1.495-1.495 1.826-3.73 1.018-5.631a.253.253 0 0 0-.415-.074l-2.754 2.754a.267.267 0 0 1-.377 0l-2.063-2.063a.267.267 0 0 1 0-.377l2.754-2.754a.253.253 0 0 0-.074-.415C13.74.62 11.506.952 10.011 2.447 8.873 3.585 8.409 5.152 8.608 6.673c.079.596-.052 1.222-.477 1.647L1.47 14.982a1.6 1.6 0 0 0 0 2.263Z\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","documentation":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M3 3.75h2m-2 2.5h2m-2 2.5h2m-2 2.5h2m-2 2.5h2m-2 2.5h2M5.5 1v18\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M15.5 19h-11A1.5 1.5 0 0 1 3 17.5v-15A1.5 1.5 0 0 1 4.5 1h11A1.5 1.5 0 0 1 17 2.5v15a1.5 1.5 0 0 1-1.5 1.5Z\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M8 3.5h5m-5 2h3m-3 2h2\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' fill=\'none\'/></svg>","conditionalTags":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M10 19H2.5A1.5 1.5 0 0 1 1 17.5v-15A1.5 1.5 0 0 1 2.5 1H10\' stroke=\'currentColor\' stroke-width=\'1.5\' fill=\'none\'></path><path d=\'M10 19h7.5a1.5 1.5 0 0 0 1.5-1.5v-15A1.5 1.5 0 0 0 17.5 1H10\' stroke=\'currentColor\' stroke-opacity=\'.3\' stroke-width=\'1.5\' fill=\'none\'></path><path d=\'M16.5 14.146 13.435 11l-1.455 1.573m-1.455 1.573 1.455-1.573m0 0L10 10\' stroke=\'currentColor\' stroke-opacity=\'.3\' stroke-width=\'1.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'></path><path d=\'M3.687 13.603 8.513 8.02 10 9.97\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'></path><circle cx=\'13.5\' cy=\'6.5\' r=\'1.5\' fill=\'currentColor\' fill-opacity=\'.3\'></circle></svg>","workable":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M1.5 5.75c.166 2.833 1.391 8.5 4.968 8.5 3.576 0 5.464-3.667 5.96-5.5.166-.667.1-2.1-1.49-2.5-1.589-.4-2.318.833-2.483 1.5-.166.5 0 2 .993 3m2.98 2.5c.994.667 3.379 1.3 4.969-1.5.668-1.177.979-2.277 1.103-3.219\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/></svg>","listingPost":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M3.5 4h2m-2 3h2m-2 3h2m-2 3h2m-2 3h2m0-14v16\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M15.5 18.5h-11A1.5 1.5 0 0 1 3 17V3a1.5 1.5 0 0 1 1.5-1.5h11A1.5 1.5 0 0 1 17 3v14a1.5 1.5 0 0 1-1.5 1.5z\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M8.25 4.5h5m-5 2.5h3m-3 2.5h2\' stroke=\'currentColor\' stroke-opacity=\'.3\' stroke-width=\'1.5\' stroke-linecap=\'round\' fill=\'none\'/></svg>","listingPage":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'m16 7-5-5v5h5z\' fill=\'currentColor\' fill-opacity=\'.12\'/><path d=\'M16 6.5h-5v-5\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M14.5 18.5h-9A1.5 1.5 0 0 1 4 17V3a1.5 1.5 0 0 1 1.5-1.5h5.85a1.5 1.5 0 0 1 1.095.474l3.15 3.363A1.5 1.5 0 0 1 16 6.362V17a1.5 1.5 0 0 1-1.5 1.5z\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' fill=\'none\'/></svg>","listingGeneric":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><rect x=\'1\' y=\'1\' width=\'18\' height=\'18\' rx=\'1.5\' stroke=\'currentColor\' stroke-opacity=\'0.3\' fill=\'none\'/><rect x=\'3\' y=\'3\' width=\'10\' height=\'3\' rx=\'1\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'3\' y=\'8.5\' width=\'10\' height=\'3\' rx=\'1\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'9\' y=\'14.5\' width=\'8\' height=\'2.5\' rx=\'1\' fill=\'currentColor\'/></svg>","edit":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'m16.25 7-3-3 2.5-2.5 3 3-2.5 2.5Z\' fill=\'currentColor\' fill-opacity=\'0.3\'/><path d=\'m12.863 3.903 3.484 3.484m-3.484-3.484L2.746 13.458a1.5 1.5 0 0 0-.435.765l-.87 3.915a.5.5 0 0 0 .647.583L6.14 17.37a1.5 1.5 0 0 0 .586-.362l9.62-9.62m-3.483-3.485 1.843-1.842a1.5 1.5 0 0 1 2.12 0l1.363 1.362a1.5 1.5 0 0 1 0 2.122l-1.842 1.842\' stroke=\'currentColor\' fill=\'none\'/></svg>","trash":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'m5 4.75 1.712 12.14a1 1 0 0 0 .99.86h5.596a1 1 0 0 0 .99-.86L16 4.75m-12 0h13\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M12.5 4.25a2 2 0 1 0-4 0\' stroke=\'currentColor\' stroke-width=\'1.5\' fill=\'none\'/><path d=\'M9 8v6m3-6v6\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' fill=\'none\'/></svg>","restore":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M4.5 11A5.5 5.5 0 1 0 10 5.5H8.5m0 0L10.75 8M8.5 5.5l2.5-2\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M4.5 11c0-.706.133-1.38.375-2\' stroke=\'currentColor\' stroke-opacity=\'.12\' stroke-width=\'1.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","settings":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M4.726 4.706a2.642 2.642 0 0 0 2.608-3.043c-.02-.138.055-.276.188-.315a8.94 8.94 0 0 1 3.912-.234c.159.026.251.192.215.35a2.642 2.642 0 0 0 2.57 3.242c.759 0 1.442-.322 1.923-.836.11-.118.299-.133.409-.015a9.003 9.003 0 0 1 1.935 3.233c.052.154-.05.313-.206.355A2.646 2.646 0 0 0 16.33 10c0 1.224.827 2.254 1.951 2.557.156.042.258.201.206.355a9.003 9.003 0 0 1-1.935 3.233c-.11.118-.298.103-.409-.015a2.625 2.625 0 0 0-1.923-.836 2.642 2.642 0 0 0-2.57 3.243c.036.157-.056.323-.215.349a8.996 8.996 0 0 1-3.912-.234.28.28 0 0 1-.188-.315 2.642 2.642 0 0 0-2.608-3.043c-.5 0-.967.14-1.365.382-.119.072-.275.056-.362-.053a8.993 8.993 0 0 1-1.485-2.711c-.052-.154.05-.313.206-.355A2.646 2.646 0 0 0 3.67 10a2.647 2.647 0 0 0-1.95-2.557c-.156-.042-.258-.201-.206-.355a8.993 8.993 0 0 1 1.485-2.71c.087-.11.243-.126.362-.054.398.242.865.382 1.365.382Z\' stroke=\'currentColor\' fill=\'none\'/><circle cx=\'10\' cy=\'10\' r=\'2.5\' stroke=\'currentColor\' fill=\'none\'/></svg>","locations":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M6.5 8A1.5 1.5 0 0 1 8 6.5h4A1.5 1.5 0 0 1 13.5 8v4a1.5 1.5 0 0 1-1.5 1.5H8A1.5 1.5 0 0 1 6.5 12V8Z\' fill=\'currentColor\' fill-opacity=\'0.3\'/><path d=\'M10 1.5v5m0 0H8A1.5 1.5 0 0 0 6.5 8v2M10 6.5h2A1.5 1.5 0 0 1 13.5 8v2M10 13.5h2a1.5 1.5 0 0 0 1.5-1.5v-2M10 13.5H8A1.5 1.5 0 0 1 6.5 12v-2m3.5 3.5v5m3.5-8.5h5m-12 0H1\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><path opacity=\'0.8\' d=\'M14 1h3.5A1.5 1.5 0 0 1 19 2.5V6m-5 13h3.5a1.5 1.5 0 0 0 1.5-1.5V14M6 1H2.5A1.5 1.5 0 0 0 1 2.5V6m5 13H2.5A1.5 1.5 0 0 1 1 17.5V14\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","sync":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M14 13H2.5A1.5 1.5 0 0 1 1 11.5v-9A1.5 1.5 0 0 1 2.5 1h9A1.5 1.5 0 0 1 13 2.5V4m1 9-2 2m2-2-2-2\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'></path><path d=\'M6 7h11.5A1.5 1.5 0 0 1 19 8.5v9a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 7 17.5V16M6 7l2-2M6 7l2 2\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'></path></svg>","view":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><circle cx=\'10\' cy=\'10\' r=\'2.5\' stroke=\'currentColor\' stroke-width=\'1.5\' fill=\'none\'/><path d=\'M10 15c-5 0-8-3-9-5 1-2 4-5 9-5s8 3 9 5c-1 2-4 5-9 5z\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","warning":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M1.174 16.71 8.675 1.835a1.469 1.469 0 0 1 2.65 0l7.5 14.875c.525 1.04-.198 2.29-1.324 2.29H2.499c-1.126 0-1.85-1.25-1.325-2.29Z\' stroke=\'currentColor\' fill=\'none\'/><circle cx=\'10\' cy=\'15.25\' r=\'0.75\' fill=\'currentColor\'/><path d=\'M10 12.5v-5\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/></svg>","arrowLeft":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M19 10H1m0 0 7.143-7M1 10l7.143 7\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","plusCircle":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path fill-rule=\'evenodd\' clip-rule=\'evenodd\' d=\'M17.5 10a7.5 7.5 0 1 1-15 0 7.5 7.5 0 0 1 15 0zM10 5.636a.75.75 0 0 1 .75.75v3h3a.75.75 0 0 1 0 1.5h-3v3a.75.75 0 1 1-1.5 0v-3h-3a.75.75 0 1 1 0-1.5h3v-3a.75.75 0 0 1 .75-.75z\' fill=\'currentColor\'/></svg>","tooltip":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><circle r=\'7.5\' transform=\'matrix(1 0 0 -1 10 10)\' stroke=\'currentColor\' stroke-width=\'1.5\'></circle><path d=\'M11 13.5c-1 .5-1.75 0-1.5-1L10 10c.15-.5-.5-1-1.5 0\' fill=\'none\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\'></path><circle r=\'1\' transform=\'matrix(1 0 0 -1 10 6.75)\' fill=\'currentColor\'></circle></svg>","invalidContent":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M4.71991 1.60974C3.11997 2.29956 2 3.89096 2 5.74394C2 7.70327 3.25221 9.37013 5 9.98788V17C5 17.8284 5.67157 18.5 6.5 18.5C7.32843 18.5 8 17.8284 8 17V9.98788C9.74779 9.37013 11 7.70327 11 5.74394C11 3.78461 9.74779 2.11775 8 1.5V5.74394C8 6.57237 7.32843 7.24394 6.5 7.24394C5.67157 7.24394 5 6.57237 5 5.74394V1.5C4.90514 1.53353 4.81173 1.57015 4.71991 1.60974Z\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linejoin=\'round\'/><path d=\'M13 13V16C13 17.3807 14.1193 18.5 15.5 18.5V18.5C16.8807 18.5 18 17.3807 18 16V13M13 13V10.5H14M13 13H18M18 13V10.5H17M14 10.5V5.5L13.5 3.5L14 1.5H17L17.5 3.5L17 5.5V10.5M14 10.5H17\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\'/></svg>","loader":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'44\' height=\'44\' viewBox=\'0 0 44 44\'><g fill=\'none\' fill-rule=\'evenodd\' stroke-width=\'2\'><circle cx=\'22\' cy=\'22\' r=\'1\' stroke=\'var(--loader-color-1, currentColor)\'><animate attributeName=\'r\' begin=\'0s\' dur=\'1.8s\' values=\'1; 20\' calcMode=\'spline\' keyTimes=\'0; 1\' keySplines=\'0.165, 0.84, 0.44, 1\' repeatCount=\'indefinite\'/><animate attributeName=\'stroke-opacity\' begin=\'0s\' dur=\'1.8s\' values=\'1; 0\' calcMode=\'spline\' keyTimes=\'0; 1\' keySplines=\'0.3, 0.61, 0.355, 1\' repeatCount=\'indefinite\'/></circle><circle cx=\'22\' cy=\'22\' r=\'1\' stroke=\'var(--loader-color-2, currentColor)\'><animate attributeName=\'r\' begin=\'-0.9s\' dur=\'1.8s\' values=\'1; 20\' calcMode=\'spline\' keyTimes=\'0; 1\' keySplines=\'0.165, 0.84, 0.44, 1\' repeatCount=\'indefinite\'/><animate attributeName=\'stroke-opacity\' begin=\'-0.9s\' dur=\'1.8s\' values=\'1; 0\' calcMode=\'spline\' keyTimes=\'0; 1\' keySplines=\'0.3, 0.61, 0.355, 1\' repeatCount=\'indefinite\'/></circle></g></svg>","database":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' fill=\'none\'><ellipse cx=\'10\' cy=\'4.138\' stroke=\'currentColor\' stroke-width=\'1.5\' rx=\'7.25\' ry=\'2.638\'/><path stroke=\'currentColor\' stroke-width=\'1.5\' d=\'M17.25 8.197c0 1.457-3.246 2.638-7.25 2.638s-7.25-1.18-7.25-2.638M17.25 12.154c0 1.457-3.246 2.639-7.25 2.639s-7.25-1.181-7.25-2.639\'/><path stroke=\'currentColor\' stroke-width=\'1.5\' d=\'M17.25 3.935v12.177c0 1.457-3.246 2.638-7.25 2.638s-7.25-1.181-7.25-2.638V3.935\'/></svg>","save":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M13.379 2H3.5A1.5 1.5 0 0 0 2 3.5v13A1.5 1.5 0 0 0 3.5 18h13a1.5 1.5 0 0 0 1.5-1.5V6.621a1.5 1.5 0 0 0-.44-1.06l-3.12-3.122A1.5 1.5 0 0 0 13.378 2z\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M5 18v-6a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v6M6 2v3a1.5 1.5 0 0 0 1.5 1.5h4A1.5 1.5 0 0 0 13 5V2\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","check":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'m6.25 11 2.5 2.5 5-6\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><circle cx=\'10\' cy=\'10\' r=\'7.5\' stroke=\'currentColor\' stroke-width=\'1.5\' fill=\'none\'/></svg>","order":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><circle cx=\'12.5\' cy=\'5\' r=\'1\' transform=\'rotate(90 12.5 5)\' fill=\'currentColor\' /><circle cx=\'7.5\' cy=\'5\' r=\'1\' transform=\'rotate(90 7.5 5)\' fill=\'currentColor\' /><circle cx=\'12.5\' cy=\'10\' r=\'1\' transform=\'rotate(90 12.5 10)\' fill=\'currentColor\' /><circle cx=\'7.5\' cy=\'10\' r=\'1\' transform=\'rotate(90 7.5 10)\' fill=\'currentColor\' /><circle cx=\'12.5\' cy=\'15\' r=\'1\' transform=\'rotate(90 12.5 15)\' fill=\'currentColor\' /><circle cx=\'7.5\' cy=\'15\' r=\'1\' transform=\'rotate(90 7.5 15)\' fill=\'currentColor\' /></svg>","down":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M10 16V3M5 12l5 5 5-5\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'></path></svg>","up":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M10 4v13M5 8l5-5 5 5\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' fill=\'none\' stroke-linejoin=\'round\'></path></svg>","tools":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M4.72 1.61A4.501 4.501 0 0 0 5 9.988V17a1.5 1.5 0 0 0 3 0V9.988A4.502 4.502 0 0 0 8 1.5v4.244a1.5 1.5 0 1 1-3 0V1.5a4.47 4.47 0 0 0-.28.11z\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linejoin=\'round\' fill=\'none\'></path><path d=\'M13 13v3a2.5 2.5 0 0 0 2.5 2.5v0A2.5 2.5 0 0 0 18 16v-3m-5 0v-2.5h1M13 13h5m0 0v-2.5h-1m-3 0v-5l-.5-2 .5-2h3l.5 2-.5 2v5m-3 0h3\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'></path></svg>","wrench":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M14.091 9.933C16.25 9.933 18 8.157 18 5.967a4 4 0 0 0-.372-1.692L15 6.902l-2-2 2.799-2.5C15.5 2 14.625 2 14.09 2c-2.159 0-3.909 1.776-3.909 3.967 0 .274.028.542.08.8l-7.886 8.004a1.989 1.989 0 1 0 2.833 2.791l7.7-7.813c.373.12.77.184 1.182.184z\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","error":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><circle cx=\'10\' cy=\'10\' r=\'7.5\' stroke=\'currentColor\' stroke-width=\'1.5\' fill=\'none\'/><path stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' d=\'m7.348 7.484 5.304 5.304m-5.304 0 5.304-5.304\' fill=\'none\'/></svg>","success":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'m6.25 11 2.5 2.5 5-6\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><circle cx=\'10\' cy=\'10\' r=\'7.5\' stroke=\'currentColor\' stroke-width=\'1.5\' fill=\'none\'/></svg>","empty":"<svg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M8.5 2h-5A1.5 1.5 0 0 0 2 3.5v5A1.5 1.5 0 0 0 3.5 10h5A1.5 1.5 0 0 0 10 8.5v-5A1.5 1.5 0 0 0 8.5 2z\' stroke=\'currentColor\' stroke-opacity=\'.12\' stroke-width=\'1.5\' fill=\'none\'/><path d=\'M11 6h1.5A1.5 1.5 0 0 1 14 7.5v5a1.5 1.5 0 0 1-1.5 1.5h-5A1.5 1.5 0 0 1 6 12.5V11\' stroke=\'currentColor\' stroke-opacity=\'.12\' stroke-width=\'1.5\' fill=\'none\'/><path d=\'M15 10h1.5a1.5 1.5 0 0 1 1.5 1.5v5a1.5 1.5 0 0 1-1.5 1.5h-5a1.5 1.5 0 0 1-1.5-1.5V15\' stroke=\'currentColor\' stroke-opacity=\'.12\' stroke-width=\'1.5\' fill=\'none\'/></svg>","allChecked":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'m2.5 3 1.688 1.75L7 1.25M2.5 10l1.688 1.75L7 8.25M2.5 17l1.688 1.75L7 15.25\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'2.5\' y=\'1.46429\' width=\'3.5\' height=\'3.5\' rx=\'1\' stroke=\'currentColor\' stroke-opacity=\'0.12\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'2.5\' y=\'8.46429\' width=\'3.5\' height=\'3.5\' rx=\'1\' stroke=\'currentColor\' stroke-opacity=\'0.12\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'2.5\' y=\'15.4643\' width=\'3.5\' height=\'3.5\' rx=\'1\' stroke=\'currentColor\' stroke-opacity=\'0.12\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M9.5 3.214h8m-8 7H16m-6.5 7h8\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","warningFill":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path fill-rule=\'evenodd\' clip-rule=\'evenodd\' d=\'m.684 17.082 7.918-15.7a1.55 1.55 0 0 1 2.796 0l7.918 15.7c.554 1.099-.21 2.418-1.398 2.418H2.082C.893 19.5.13 18.18.684 17.082ZM10.75 15.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0ZM10.5 7.5a.5.5 0 0 0-1 0v5a.5.5 0 0 0 1 0v-5Z\' fill=\'currentColor\'/></svg>","warningFillTransparent":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'m.351 17.573 8.31-16.427c.556-1.097 2.122-1.097 2.678 0l8.31 16.427a1.5 1.5 0 0 1-1.339 2.177H1.69a1.5 1.5 0 0 1-1.34-2.177Z\' fill=\'currentColor\' fill-opacity=\'0.3\'/><path d=\'M10 7.25v5\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><circle cx=\'10\' cy=\'14.75\' r=\'0.75\' fill=\'currentColor\'/></svg>","salesforce":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M1.262 13.135a3.29 3.29 0 0 1 .954-3.847c-.763-1.153 0-2.724.476-3.365C3.17 5.282 4.503 4 6.03 4c1.525 0 2.542.962 2.86 1.442.317-.32 1.239-.961 2.382-.961 1.144 0 1.748.961 1.907 1.442 1.906-.77 3.336-.32 3.813 0 1.112.801 2.955 2.98 1.43 5.288-1.526 2.308-3.178 2.244-3.813 1.924 0 .16-.286.673-1.43 1.442-1.144.77-2.066.32-2.383 0-.953 1.442-2.383 1.923-3.813 1.923-1.144 0-2.383-.961-2.86-1.442-.635.16-2.097 0-2.86-1.923Z\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M12 7.82c-.583-.138-1.75-.165-1.75.825l-.146 1.105M8.5 13.185c1.05.33 1.313-.687 1.313-1.238l.29-2.197m-1.165 0h1.166m1.459 0h-1.46M7.5 8.874c-.417-.295-2.083-.443-2.083.443 0 .866 1.666 1.064 1.666 1.773 0 .71-1.527.591-2.083.443\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","zapier":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M8.771 11.229c-.491-.983-.204-2.048 0-2.458.983-.491 2.048-.204 2.458 0 .205.41.491 1.475 0 2.458-.41.205-1.475.491-2.458 0Z\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\' stroke-linejoin=\'round\'/><path d=\'M1.367 8.56c.181-.177 2.772-.093 4.11-.036a.303.303 0 0 0 .226-.519L2.689 5.052c-.288-.282-.447-.683-.235-1.026a4.112 4.112 0 0 1 1.29-1.255c.34-.197.73-.043 1.01.232L7.782 5.97l.297.301c.098.1.269.03.269-.11V1.99c0-.403.173-.797.565-.892a4.24 4.24 0 0 1 1.809 0c.391.095.565.49.565.892v4.17c0 .131.163.192.249.092l.24-.283 3.027-2.966c.28-.275.67-.429 1.01-.232a4.11 4.11 0 0 1 1.29 1.256c.212.342.053.743-.235 1.025l-3.013 2.953-.247.225a.19.19 0 0 0 .128.33h4.285c.393 0 .78.164.878.544a3.7 3.7 0 0 1 .102.896 3.7 3.7 0 0 1-.102.896c-.098.38-.485.544-.878.544h-4.285a.19.19 0 0 0-.128.33l.247.225 3.013 2.953c.288.282.447.683.235 1.025a4.111 4.111 0 0 1-1.29 1.256c-.34.197-.73.043-1.01-.232l-3.026-2.966-.241-.283a.141.141 0 0 0-.25.092v4.17c0 .403-.173.797-.564.892-.534.13-1.275.13-1.809 0-.392-.095-.565-.49-.565-.892v-4.17c0-.14-.17-.21-.27-.11l-.296.301-3.026 2.966c-.28.274-.671.429-1.01.232a4.112 4.112 0 0 1-1.291-1.255c-.212-.343-.053-.744.235-1.026l3.014-2.953a.324.324 0 0 0-.228-.555H1.98c-.393 0-.78-.164-.878-.544A3.695 3.695 0 0 1 1 10c0-.6.122-1.2.367-1.44Z\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","talentlyft":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' fill=\'none\'><path stroke=\'currentColor\' d=\'M16.3 7.3c0 3.4-3.5 7.7-6.3 7.7-3 0-6.3-4.3-6.3-7.8a6.3 6.3 0 1 1 12.6 0Z\'/><path fill=\'currentColor\' fill-opacity=\'.3\' fill-rule=\'evenodd\' d=\'M15.8 4.9a6.2 6.2 0 0 0-.8-1.4c-3.5.9-5.6-.9-6.5-2.3a6.2 6.2 0 0 0-1.5.6c1 2 3.5 4.3 8.8 3Z\' clip-rule=\'evenodd\'/><path fill=\'currentColor\' fill-opacity=\'.3\' fill-rule=\'evenodd\' d=\'M16 8.9a6.7 6.7 0 0 0 .2-1.9c-5.9 2-10-1.1-11-3.7a6.2 6.2 0 0 0-1 1.6C7.6 9.8 12.7 9.7 16 9Z\' clip-rule=\'evenodd\'/><path fill=\'currentColor\' fill-opacity=\'.3\' fill-rule=\'evenodd\' d=\'M4.6 10.8a8.6 8.6 0 0 1-.9-3.6c1.9 2.6 5.5 5.4 11.5 3.8a11.9 11.9 0 0 1-1.3 2c-2.3.2-6.5-.1-9.3-2.2Z\' clip-rule=\'evenodd\'/><path stroke=\'currentColor\' d=\'M10 17c-.4 0-.8-.2-1-.4a.3.3 0 0 0-.2-.1.3.3 0 0 0-.3.3v.7c0 .8.7 1.5 1.5 1.5s1.5-.7 1.5-1.5v-.7a.3.3 0 0 0-.3-.3.3.3 0 0 0-.2 0c-.2.3-.6.5-1 .5Z\'/></svg>","productive":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M13.302 10.3c1.072-1.767 2.283-2.714 3.793-2.924.37-.05.733-.139.83-.708l.566-3.25a.758.758 0 0 0-.73-.918c-2.78 0-6.013 1.128-8.535 5.359l-2.069 3.638-1.991-3.443a.725.725 0 0 0-1.007-.264L1.361 9.483a.761.761 0 0 0-.258 1.03l3.543 6.128c.31.534.874.862 1.483.859l2.11-.008a1.707 1.707 0 0 0 1.474-.873l3.558-6.265.031-.055Z\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\'/><path d=\'M19 12.126c0 1.156-.916 2.093-2.045 2.093-1.13 0-2.046-.937-2.046-2.093s.916-2.093 2.046-2.093S19 10.97 19 12.126Z\' fill=\'currentColor\' fill-opacity=\'0.3\' stroke=\'currentColor\'/></svg>","campaignMonitor":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M18.604 3.786 1.627 16.047a.25.25 0 0 0 .146.453H18.75a.25.25 0 0 0 .25-.25V3.989a.25.25 0 0 0-.396-.203Z\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'m8.715 8.232-7.307 5.937A.25.25 0 0 1 1 13.975V3.927a.25.25 0 0 1 .373-.217L8.68 7.82a.25.25 0 0 1 .035.412Z\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\' stroke-linecap=\'round\'/></svg>","pardot":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'m7 17.75-1.157.145A.75.75 0 0 1 5 17.15v-.4a.75.75 0 0 1 .75-.75h.5a.75.75 0 0 1 .75.75v1Zm0 0V18m1.5 0v-1.25a.75.75 0 0 1 .75-.75h.25m3 0h-1.25a.75.75 0 0 0-.75.75v.5c0 .414.336.75.75.75h.5a.75.75 0 0 0 .75-.75V14m5 0v3.25c0 .414.336.75.75.75h.25m-2-3h2M2 18v-1.5a.5.5 0 0 1 .5-.5H3a.75.75 0 0 1 .75.75v.5A.75.75 0 0 1 3 18H2Zm0 0v1.5M15.25 16h-.5a.75.75 0 0 0-.75.75v.5c0 .414.336.75.75.75h.5a.75.75 0 0 0 .75-.75v-.5a.75.75 0 0 0-.75-.75Z\' stroke=\'currentColor\' stroke-width=\'0.75\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M1.262 10.135a3.29 3.29 0 0 1 .954-3.847c-.763-1.153 0-2.724.476-3.365C3.17 2.282 4.503 1 6.03 1c1.525 0 2.542.962 2.86 1.442.317-.32 1.239-.961 2.382-.961 1.144 0 1.748.961 1.907 1.442 1.906-.77 3.336-.32 3.813 0 1.112.801 2.955 2.98 1.43 5.289-1.526 2.307-3.178 2.243-3.813 1.923 0 .16-.286.673-1.43 1.442-1.144.77-2.066.32-2.383 0-.953 1.442-2.383 1.923-3.813 1.923-1.144 0-2.383-.961-2.86-1.442-.635.16-2.097 0-2.86-1.923Z\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M12 4.82c-.583-.138-1.75-.165-1.75.825l-.146 1.105M8.5 10.185c1.05.33 1.313-.687 1.313-1.238l.29-2.197m-1.165 0h1.166m1.459 0h-1.46M7.5 5.874c-.417-.295-2.083-.443-2.083.443 0 .866 1.666 1.064 1.666 1.773 0 .71-1.527.591-2.083.443\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","chilliPiper":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M2.21 18.649c1.204-.398 3.51-1.492 4.01-1.989.836.331 2.005.994 2.005.994-.5 0-7.518 1.492-6.014.995Zm7.52-2.486-2.005-.994L10.5 11.5c1.604 1.193 3.76 1.57 4.5 1.75-2.406 2.386-4.77 2.913-5.27 2.913Zm7.016-4.971c-2.405 0-4.677-1.326-5.513-1.988l1.002-3.48c3.208 0 5.347 1.326 6.015 1.988l-1.504 3.48Z\' fill=\'currentColor\' fill-opacity=\'0.3\'/><path d=\'M14.24 3.736c1.504.497 1.504.396 2.005.595m2.005.896c-1.002-.497-1.002-.497-2.005-.896m1.003-3.081c0 .424-.2 1.634-1.003 3.081M6.221 16.661c-.502.496-2.807 1.59-4.01 1.988-1.504.497 5.513-.995 6.014-.995 0 0-1.169-.663-2.004-.994Zm1.504-1.492 2.005.994c.5 0 2.864-.527 5.27-2.913-.74-.18-2.896-.557-4.5-1.75l-2.775 3.669Zm3.508-5.965c.835.662 3.108 1.988 5.513 1.988l1.504-3.48c-.668-.662-2.807-1.988-6.014-1.988l-1.003 3.48Z\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","info":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><circle cx=\'9\' cy=\'9\' r=\'9\' transform=\'matrix(1 0 0 -1 1 19)\' stroke=\'currentColor\' fill=\'none\'/><circle cx=\'0.75\' cy=\'0.75\' r=\'0.75\' transform=\'matrix(1 0 0 -1 9.25 7)\' fill=\'currentColor\'/><path d=\'M11 14c-.91 1.149-1.5.5-1.343-1.445l.356-3.622L9 9.5\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","emptyRect":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><rect x=\'1\' y=\'1\' width=\'18\' height=\'18\' rx=\'1.5\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' stroke-dasharray=\'3 4\' fill=\'none\'/></svg>","add":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M10 19V1m-9 9h18\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","addHighContrast":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M10 19V1m-9 9h18\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' stroke-width=\'1.5\' fill=\'none\'/></svg>","emptyStateLocations":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'64\' height=\'65\' viewBox=\'0 0 64 65\' fill=\'none\'><path d=\'M14.872 45.523v0c.315.089.582.298.744.583l1.981 3.49c.16.28.2.614.113.925v0m-2.838-4.998-4.457-1.255a1.5 1.5 0 0 0-1.85 1.037l-2.748 9.756a1.5 1.5 0 0 0 1.038 1.85l6.946 1.956a1.5 1.5 0 0 0 1.85-1.037l2.059-7.31m-2.838-4.997-.96 3.409a.5.5 0 0 0 .345.617l3.453.972M13.024 2.938v0c.297-.028.594.062.826.25l2.84 2.319c.23.186.374.457.402.75v0m-4.068-3.319-4.21.404A1.37 1.37 0 0 0 7.58 4.836l.883 9.217a1.37 1.37 0 0 0 1.494 1.234l6.563-.629a1.37 1.37 0 0 0 1.233-1.494l-.66-6.906m-4.07-3.32.31 3.221a.457.457 0 0 0 .497.411l3.262-.312\' stroke=\'currentColor\' stroke-width=\'0.75\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M50.313 4.757h.043a.77.77 0 0 1 .542.222l2.063 2.04a.77.77 0 0 1 .228.548V7.6m-2.876-2.844H46.77a.77.77 0 0 0-.77.77v3.851m4.313-4.621v2.587c0 .142.115.257.257.257h2.62m0 0v5.629a.77.77 0 0 1-.771.77h-2.824\' stroke=\'currentColor\' stroke-opacity=\'0.3\' stroke-width=\'0.75\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M27 63.672V52.586c0-.657.533-1.19 1.19-1.19h5.472m4.441 12.276V55.79m-4.44-4.392h.065c.314 0 .614.123.837.343l3.185 3.15c.226.224.353.529.353.847v.052m-4.44-4.392v3.996c0 .219.177.396.396.396h4.044\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-width=\'0.75\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'m56.825 58.876-.025.034a.763.763 0 0 1-.496.3l-2.842.444a.764.764 0 0 1-.57-.14l-.028-.02m3.961-.618 2.086-2.826a.763.763 0 0 0-.16-1.068l-6.143-4.535a.763.763 0 0 0-1.067.16l-3.326 4.505a.764.764 0 0 0 .16 1.068l4.49 3.314m3.96-.618-2.063-1.524a.254.254 0 0 0-.356.054l-1.542 2.088\' stroke=\'currentColor\' stroke-opacity=\'0.12\' stroke-width=\'0.75\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'m6.465 24.548.034-.008a.636.636 0 0 1 .478.076l2.046 1.245a.636.636 0 0 1 .288.396l.006.028m-2.852-1.737-2.846.676a.636.636 0 0 0-.472.765l1.469 6.188a.636.636 0 0 0 .765.472l4.538-1.077a.636.636 0 0 0 .471-.766l-1.073-4.521m-2.852-1.737.493 2.079a.212.212 0 0 0 .255.157l2.104-.5\' stroke=\'currentColor\' stroke-opacity=\'0.3\' stroke-width=\'0.75\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'m57.99 25.235.06.009c.278.044.528.196.695.423l2.392 3.25c.17.23.24.52.195.802l-.008.047m-3.334-4.531-4.868-.769a1.071 1.071 0 0 0-1.225.891L50.226 35.94a1.072 1.072 0 0 0 .89 1.226l7.762 1.225a1.071 1.071 0 0 0 1.225-.891l1.221-7.734m-3.334-4.531-.56 3.555a.357.357 0 0 0 .296.408l3.598.568\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-width=\'0.75\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M16 15v30.5a1.5 1.5 0 0 0 1.5 1.5h29a1.5 1.5 0 0 0 1.5-1.5v-33a1.5 1.5 0 0 0-1.5-1.5h-29\' stroke=\'currentColor\' stroke-opacity=\'0.5\' fill=\'none\'/><rect x=\'20\' y=\'15\' width=\'17\' height=\'4\' rx=\'1\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'20\' y=\'23\' width=\'17\' height=\'4\' rx=\'1\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'20\' y=\'31\' width=\'3\' height=\'3\' rx=\'0.75\' fill=\'currentColor\' fill-opacity=\'0.3\' stroke=\'currentColor\' stroke-linejoin=\'round\'/><rect x=\'31\' y=\'40\' width=\'14\' height=\'4\' rx=\'1\' fill=\'currentColor\'/><path d=\'M26 32.5h8\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' fill=\'none\'/></svg>","emptyStateFormList":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'64\' height=\'64\' viewBox=\'0 0 64 64\' fill=\'none\'><path d=\'M32.713 61.5v-33c0-.828-.582-1.836-1.3-2.25L6.3 11.75c-.718-.414-1.3-.078-1.3.75v33c0 .828.582 1.836 1.299 2.25l25.115 14.5c.717.414 1.299.078 1.299-.75Z\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><rect width=\'17\' height=\'4\' rx=\'1\' transform=\'matrix(.86603 .5 0 1 8.464 17)\' stroke=\'currentColor\' stroke-opacity=\'0.12\' stroke-linejoin=\'round\' fill=\'none\'/><rect width=\'17\' height=\'4\' rx=\'1\' transform=\'matrix(.86603 .5 0 1 8.464 25)\' stroke=\'currentColor\' stroke-opacity=\'0.12\' stroke-linejoin=\'round\' fill=\'none\'/><rect width=\'3\' height=\'3\' rx=\'0.75\' transform=\'matrix(.86603 .5 0 1 8.464 33)\' stroke=\'currentColor\' stroke-opacity=\'0.12\' stroke-linejoin=\'round\' fill=\'none\'/><rect width=\'14\' height=\'4\' rx=\'1\' transform=\'matrix(.86603 .5 0 1 17.99 47.5)\' fill=\'currentColor\' fill-opacity=\'0.12\'/><path d=\'m13.66 37.5 6.928 4\' stroke=\'currentColor\' stroke-opacity=\'0.12\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M14 14V9.5c0-.828.582-1.164 1.299-.75l25.115 14.5c.717.414 1.299 1.422 1.299 2.25v33c0 .828-.582 1.164-1.3.75L34.786 56\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M23 11V6.5c0-.828.582-1.164 1.299-.75l25.115 14.5c.717.414 1.299 1.422 1.299 2.25v33c0 .828-.582 1.164-1.3.75L43.786 53\' stroke=\'currentColor\' stroke-opacity=\'0.3\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M32 8V4.5c0-.828.582-1.164 1.299-.75l25.115 14.5c.717.414 1.299 1.422 1.299 2.25v33c0 .828-.582 1.164-1.3.75L52.786 51\' stroke=\'currentColor\' stroke-opacity=\'0.12\' stroke-linecap=\'round\' fill=\'none\'/></svg>","emptyStateTrash":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'64\' height=\'64\' viewBox=\'0 0 64 64\' fill=\'none\'><path d=\'m23.914 62.5 9.269-29.283\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M29.704 43.623c-1.386-.439-3.524.227-4.296 2.667-.772 2.44.593 4.215 1.979 4.654\' stroke=\'currentColor\' fill=\'none\'/><path d=\'m34 29.645 4.382 30.338a3 3 0 0 0 2.97 2.571H55.17a3 3 0 0 0 2.969-2.57l4.382-30.339\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path opacity=\'0.6\' d=\'m39.178 33.89 3.303 24.791M57.822 33.89l-3.303 24.791\' stroke=\'currentColor\' stroke-opacity=\'0.3\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M51.706 34 50.27 58.681M45.044 34l1.437 24.681\' stroke=\'currentColor\' stroke-opacity=\'0.3\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M2 63.5h61M59.25 1a3.75 3.75 0 1 1-7.5 0m3.75 7.5V6.625m3.977-1.648 1.326 1.326m-10.606 0 1.325-1.326M61.125 1H63M48 1h1.875\' stroke=\'currentColor\' stroke-opacity=\'0.12\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M19 63c-3.173-4.121-4.508-26.387-4.894-40.5M5 63c1.305-4.237 1.833-26.626 1.97-40.5\' stroke=\'currentColor\' stroke-opacity=\'0.3\' stroke-width=\'0.75\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M.5 18.5c-.176.702.48 1.1 1 1.1.59 0 1.16-.091 1.694-.26a.46.46 0 0 1 .55.243A4.3 4.3 0 0 0 7.63 22a4.332 4.332 0 0 0 2.771-.992c.17-.14.42-.14.59 0a4.332 4.332 0 0 0 2.772.992 4.3 4.3 0 0 0 3.812-2.269.443.443 0 0 1 .309-.228c1.332-.25 2.46-.963 3.145-1.932a.471.471 0 0 1 .642-.123c.89.6 1.967.952 3.13.952 3.048 0 5.519-2.418 5.519-5.4 0-.895-.223-1.74-.617-2.483a.477.477 0 0 1 .31-.681C32.315 9.331 34 7.715 34 5.8c0-1.008-.467-1.933-1.244-2.657a.463.463 0 0 1 .004-.68C33.446 1.862 34.23.91 33 .5\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-width=\'0.75\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M41.678 12.797c.562-.917 2-2.314 3.405-.882a.284.284 0 0 0 .366.032c1.63-1.172 2.807.451 3.204 1.45m-1.733 3.024c.707-.457 2.188-.958 2.717.487.048.13.184.21.32.189 1.52-.236 1.8 1.303 1.741 2.143m-14.977-1.717c.113-.616.595-1.67 1.647-1.284a.31.31 0 0 0 .354-.107c.665-.903 1.649-.29 2.082.162\' stroke=\'currentColor\' stroke-opacity=\'0.12\' stroke-width=\'0.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M48.25 30.5c7.87 0 14.25-.448 14.25-1s-6.38-1-14.25-1-14.25.448-14.25 1 6.38 1 14.25 1Z\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/></svg>","emptyStateResults":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'64\' height=\'64\' viewBox=\'0 0 64 64\' fill=\'none\'><path d=\'M34.687 50.378c.66 0 1.202-.283 1.817-.483.687-.223 1.465-.684 1.732-1.394.288-.768.188-1.816.056-2.603-.083-.503-.2-1.274-.713-1.562-.45-.253-.93-.366-1.347-.716-.726-.61-1.718-1.253-2.1-2.145-.13-.3-.177-.64-.083-.959.26-.886 1.051-1.72 1.647-2.391.679-.764 1.432-1.55 1.432-2.625\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M38.21 45.214c0-.567.143-1.345-.019-1.894a2.467 2.467 0 0 0-.294-.648c-.314-.47-.37-.962-.375-1.526-.002-.23-.019-.485.083-.699.108-.225.292-.37.473-.532.272-.242.417-.575.595-.883.19-.328.237-.661.354-1.012.065-.195.198-.35.262-.54\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M38.216 45.365c0-.298.072-.768.084-1.065.017-.44.301-.815.599-1.123.301-.31.683-.422 1.087-.548.253-.08.527-.1.775-.194.821-.313 1.581-.693 2.27-1.241.463-.37 1.021-.534 1.61-.417\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M54.027 57.9c0 .709-.046 1.418-.258 2.1-.248.8-.84 1.087-1.619 1.347-.568.19-1.22.515-1.809.58-1.093.122-1.964-.178-2.927-.728-1.786-1.02-4.088-1.79-4.986-3.81-.664-1.493-.617-3.305.58-4.502.49-.49 1.167-.773 1.66-1.266.31-.31.59-.798.812-1.176a5.91 5.91 0 0 0 .63-1.501c.13-.477.214-1.45-.035-1.893-.241-.43-.661-.73-.985-1.095-.244-.274-.351-.658-.55-.956\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'m50.49 23.125-.86 2.347 9.575-2.88-2.012-1.483\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'39.0815\' y=\'7.75934\' width=\'20\' height=\'18\' rx=\'1.5\' transform=\'rotate(-16.736 39.081 7.76)\' fill=\'url(#4a1ff35d-6451-4e00-8b61-316bb9234017)\' fill-opacity=\'0.3\' stroke=\'currentColor\'/><circle cx=\'43.4412\' cy=\'10.1032\' r=\'0.5\' transform=\'rotate(-16.736 43.441 10.103)\' fill=\'currentColor\'/><circle cx=\'44.3051\' cy=\'12.9761\' r=\'0.5\' transform=\'rotate(-16.736 44.305 12.976)\' fill=\'currentColor\'/><path d=\'M46.242 9c-.479.144-1.292.91-.86 2.347.431 1.437 1.533 1.627 2.012 1.483m-2.081 3.498 5.267-1.584m-4.835 3.02 3.83-1.151M46.177 19.2l4.788-1.44m-4.356 2.877 2.873-.864\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'m4.207 16.5-.517-.544a.75.75 0 0 1 .026-1.06L15.12 4.034a1.5 1.5 0 0 1 2.121.052l8.965 9.415a1.5 1.5 0 0 1-.052 2.12L14.75 26.483a.75.75 0 0 1-1.06-.026l-.517-.543m-8.965-9.415-1.63 1.552a.75.75 0 0 0-.025 1.06l7.93 8.328a.75.75 0 0 0 1.06.026l1.63-1.551m-8.965-9.415 8.965 9.415\' stroke=\'currentColor\' fill=\'none\'/><path d=\'m7.414 15.517 1.38 1.448m2.758 2.897 2.758 2.897\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'16.1385\' y=\'5.82758\' width=\'12\' height=\'9\' rx=\'0.75\' transform=\'rotate(46.4 16.139 5.828)\' fill=\'currentColor\' fill-opacity=\'0.12\'/><rect x=\'16.1385\' y=\'5.82758\' width=\'12\' height=\'9\' rx=\'0.75\' transform=\'rotate(46.4 16.139 5.828)\' fill=\'url(#a336d925-6bb0-4b90-9ebe-c349ed303f8d)\' fill-opacity=\'0.2\'/><path d=\'m16.776 8.672-.052 2.121m1.087-1.034-2.121-.052m5.224 3.311-.052 2.12m1.086-1.034-2.12-.052\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M18.06 14.009c-.266.254-.791.135-1.172-.265-.38-.4-.473-.93-.207-1.184\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M13.466 13.896c.356-.109 1.345-.038 2.448 1.121s1.345 2.862 1.327 3.57\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M16.3 24.967c.145.535 1.12.696 1.579.808.48.116.995.252 1.494.16.585-.11.862-.981 1.033-1.494.32-.958.851-1.776 1.876-2.126 1.208-.412 1.703.383 1.985 1.389.087.309.154 1.142.457 1.318.304.176.752.156 1.088.156.55 0 .921-.11 1.431-.312.605-.24 1.32-.508 1.99-.374 1.122.224 1.228 1.374 1.532 2.234.114.323.382.789.417 1.12.023.217.178.422.242.631.07.23.105.44.25.632m11.583-7.371c-1.492 0-3.133-.163-4.567.254-.76.22-1.045 1.311-1.147 1.989-.106.707-.11 1.466.425 2 .538.538 1.361.972 2.075 1.217.826.284 1.838.325 2.528.905 1.37 1.152.037 3.086-.211 4.477-.229 1.284.14 2.076 1.28 2.738 1.076.626 2.16.6 3.365.6.853 0 .94 1.833.956 2.442.014.565.276 1.032.772 1.28\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' fill=\'none\'/><rect x=\'51.7326\' y=\'40\' width=\'10\' height=\'17\' rx=\'1.5\' transform=\'rotate(9.25 51.733 40)\' fill=\'url(#36744ceb-ac09-4c3b-ba3f-84931fa7ec81)\' fill-opacity=\'0.12\' stroke=\'currentColor\'/><circle cx=\'56.3863\' cy=\'42.531\' r=\'0.5\' transform=\'rotate(9.25 56.386 42.531)\' fill=\'currentColor\' fill-opacity=\'0.3\'/><path d=\'m54.309 47.512 2.065 2.87m.402-2.468-2.87 2.065\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'m29.558 46.585-2.656-15.778a1.5 1.5 0 0 0-1.728-1.23L3.479 33.229a1.5 1.5 0 0 0-1.23 1.728l4.316 25.64a1.5 1.5 0 0 0 1.728 1.23l21.695-3.652a1.5 1.5 0 0 0 1.23-1.729l-.166-.986\' stroke=\'currentColor\' stroke-opacity=\'0.5\' fill=\'none\'/><rect x=\'6.60846\' y=\'36.7585\' width=\'17\' height=\'4\' rx=\'1\' transform=\'rotate(-9.555 6.608 36.758)\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'7.93646\' y=\'44.6475\' width=\'17\' height=\'4\' rx=\'1\' transform=\'rotate(-9.555 7.936 44.648)\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'9.34747\' y=\'53.0296\' width=\'3\' height=\'3\' rx=\'0.75\' transform=\'rotate(-9.555 9.347 53.03)\' fill=\'currentColor\' fill-opacity=\'0.3\' stroke=\'currentColor\' stroke-linejoin=\'round\'/><path d=\'m15.513 53.513 7.89-1.328\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' fill=\'none\'/><path fill-rule=\'evenodd\' clip-rule=\'evenodd\' d=\'M25.956 55.304a1.5 1.5 0 0 0 1.728 1.23l6.902-1.162a1.5 1.5 0 0 0 1.23-1.728l-1.161-6.903a1.5 1.5 0 0 0-1.729-1.23l-6.902 1.162a1.5 1.5 0 0 0-1.23 1.728l1.162 6.903Zm7.222-4.406a.5.5 0 0 0-.118-.698l-2.88-2.05a.5.5 0 0 0-.58.815l1.897 1.35-3.74.63a.5.5 0 1 0 .166.986l3.74-.63-1.35 1.897a.5.5 0 1 0 .814.58l2.05-2.88Z\' fill=\'currentColor\'/><defs><linearGradient id=\'a336d925-6bb0-4b90-9ebe-c349ed303f8d\' x1=\'27.6855\' y1=\'14.2531\' x2=\'16.5299\' y2=\'6.39158\' gradientUnits=\'userSpaceOnUse\'><stop stop-color=\'currentColor\' stop-opacity=\'0\'/><stop offset=\'1\' stop-color=\'currentColor\'/></linearGradient><linearGradient id=\'36744ceb-ac09-4c3b-ba3f-84931fa7ec81\' x1=\'56.7326\' y1=\'40\' x2=\'56.7326\' y2=\'57\' gradientUnits=\'userSpaceOnUse\'><stop stop-color=\'currentColor\' stop-opacity=\'0\'/><stop offset=\'1\' stop-color=\'currentColor\'/></linearGradient><radialGradient id=\'4a1ff35d-6451-4e00-8b61-316bb9234017\' cx=\'0\' cy=\'0\' r=\'1\' gradientUnits=\'userSpaceOnUse\' gradientTransform=\'matrix(13.00002 13.00002 -14.44442 14.44442 39.58 8.26)\'><stop stop-color=\'currentColor\'/><stop offset=\'1\' stop-color=\'currentColor\' stop-opacity=\'0\'/></radialGradient></defs></svg>","page":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M11.4 1h.083a1.5 1.5 0 0 1 1.055.433l4.017 3.973A1.5 1.5 0 0 1 17 6.472v.066M11.4 1H4.5A1.5 1.5 0 0 0 3 2.5v15A1.5 1.5 0 0 0 4.5 19h11a1.5 1.5 0 0 0 1.5-1.5V6.538M11.4 1v5.038a.5.5 0 0 0 .5.5H17\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M11.5 6.5v-6l6 6h-6Z\' fill=\'currentColor\' fill-opacity=\'0.5\'/></svg>","post":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><rect x=\'3\' y=\'1\' width=\'2.5\' height=\'18\' rx=\'1.25\' fill=\'currentColor\' fill-opacity=\'0.12\'/><path d=\'M3 3.75h2m-2 2.5h2m-2 2.5h2m-2 2.5h2m-2 2.5h2m-2 2.5h2M5.5 1v18\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M15.5 19h-11A1.5 1.5 0 0 1 3 17.5v-15A1.5 1.5 0 0 1 4.5 1h11A1.5 1.5 0 0 1 17 2.5v15a1.5 1.5 0 0 1-1.5 1.5Z\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M8 3.5h5m-5 2h3m-3 2h2\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' fill=\'none\'/></svg>","jira":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M12.626 10.192 10 12.82a4.643 4.643 0 0 1 0 6.566l8.485-8.486a1 1 0 0 0 0-1.414L10 1a4.643 4.643 0 0 0 0 6.566l2.626 2.626Z\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\'/><path d=\'M7.374 10.192 10 7.566A4.643 4.643 0 0 1 10 1L1.515 9.485a1 1 0 0 0 0 1.415L10 19.384a4.643 4.643 0 0 0 0-6.566l-2.626-2.627Z\' fill=\'currentColor\' fill-opacity=\'0.3\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\'/></svg>","steps":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><rect x=\'1\' y=\'1\' width=\'7\' height=\'7\' rx=\'1.5\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\'/><rect x=\'1\' y=\'10\' width=\'7\' height=\'7\' rx=\'1.5\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\'/><path fill=\'currentColor\' fill-opacity=\'0.12\' d=\'M1.5 19h6v1h-6z\'/><path d=\'M1 20a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1\' stroke=\'currentColor\' fill=\'none\'/><path d=\'M10 4.5h7.5M10 14h7.5\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M4.75 6.5v-4l-1 .8m-.25 8.2h1.25a.75.75 0 0 1 .75.75v.5a.75.75 0 0 1-.75.75h-.5a.75.75 0 0 0-.75.75v1.25h2\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","cloudflare":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M11.984 13.5H1a3.006 3.006 0 0 1 3.373-2.473 1.502 1.502 0 0 1 2.14-2.105C7.136 7.065 8.677 5.75 10.48 5.75c1.379 0 2.604.768 3.383 1.96l.183.29m1.204 5.5H19V13c0-1.526-.98-2.824-2.345-3.303\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M6.5 11.5H11m0 0c1.167 0 3-1 4-2.5 0 .833.4 2.5 2 2.5-1 0-3.1.4-3.5 2 0-.667-.9-2-2.5-2Z\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","cloudfront":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><circle cx=\'10\' cy=\'10\' r=\'9\' stroke=\'currentColor\' fill=\'none\'/><circle cx=\'6.5\' cy=\'9.5\' r=\'1.75\' fill=\'currentColor\'/><circle cx=\'10.5\' cy=\'4.5\' r=\'1.75\' fill=\'currentColor\'/><circle cx=\'13.5\' cy=\'13.5\' r=\'1.75\' fill=\'currentColor\'/><path d=\'M1 10c3.5-1.167 11.3-1.4 14.5 7\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M15.498 3C11.332 3.167 4 6.4 6 18\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M5.98 1.96C11.083 1.7 15.5 11 12.5 18.5\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/></svg>","rocketCache":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M5 1H2.5L6 13.5h.5l3.25-7h.5l3.25 7h.5L17.5 1H15l-1.5 6-3-6h-1l-3 6L5 1Z\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\'/><path d=\'M7.5 15.25 10 9.5l2.5 5.75-1 3.75-1.5-2-1.5 2-1-3.75Z\' fill=\'currentColor\' fill-opacity=\'0.5\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\'/></svg>","security":"<svg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 20 20\' width=\'20\' height=\'20\' fill=\'none\'><rect x=\'3\' y=\'9\' width=\'14\' height=\'10\' rx=\'1\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'></rect><path d=\'M15 9V5.8C15 3.149 12.761 1 10 1S5 3.149 5 5.8V9\' stroke=\'currentColor\' fill=\'none\'></path><circle cx=\'10\' cy=\'13.25\' r=\'0.75\' stroke=\'currentColor\' fill=\'none\'></circle><path d=\'M10 14v1.5\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'></path></svg>","wpml":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M16.374 16.701c.433 1.724-.542 2.515-1.084 2.694-1.373.273-1.877-.016-2.061-.539-.216-.359-.54-1.077-.107-1.077.433 0 .252.718.107 1.077.184.523.688.812 2.06.54.543-.18 1.518-.97 1.085-2.695-.434-1.724-2.348-1.437-3.252-1.078-1.445.719-4.985 1.617-7.586-.538C2.284 12.39.658 7.54 3.368 3.769 5.536.752 9.329.357 10.955.536 13.303.716 18 2.476 18 8.08c0 5.604-2.529 6.286-3.793 5.927-1.575-.539-3.996-2.479-1.084-5.927 2.912-3.449 1.134-4.887 0-5.388-1.626-.719-5.528-1.293-8.129 2.155-2.6 3.448-.723 8.262.542 10.238 2.6 2.155 6.141 1.257 7.586.538.903-.359 2.818-.646 3.252 1.078Z\' fill=\'currentColor\' fill-opacity=\'0.3\'/><path d=\'M13.122 17.779c0 .395 0 .775.107 1.077m-.107-1.077c.433 0 .252.718.107 1.077m-.107-1.077c-.434 0-.11.718.107 1.077m-7.693-3.771c2.6 2.155 6.141 1.257 7.586.538.903-.359 2.818-.646 3.252 1.078.433 1.724-.542 2.515-1.084 2.694-1.373.273-1.877-.016-2.061-.539m-7.693-3.771C2.284 12.39.658 7.54 3.368 3.769 5.536.752 9.329.357 10.955.536 13.303.716 18 2.476 18 8.08c0 5.604-2.529 6.286-3.793 5.927-1.575-.539-3.996-2.479-1.084-5.927 2.912-3.449 1.134-4.887 0-5.388-1.626-.719-5.528-1.293-8.129 2.155-2.6 3.448-.723 8.262.542 10.238Z\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","pipedrive":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path fill-rule=\'evenodd\' clip-rule=\'evenodd\' d=\'M3 4.5V1h4.5L8 3l1.5-1 2-.5L15 3l2 3.5-.5 4-2.5 3-3 1L8 13v6H4.5V4.5H3Zm7.5.5L9 6l-.5 2 1 2.5 2 .5 2-2-.5-3-1.5-1h-1Z\' fill=\'currentColor\' fill-opacity=\'0.3\'/><ellipse cx=\'11.0506\' cy=\'8\' rx=\'2.45\' ry=\'3.15\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M6.9 1H3v3.5h1.4v14.7h3.5v-6.282c.959.865 2.176 1.382 3.5 1.382 3.093 0 5.6-2.82 5.6-6.3s-2.507-6.3-5.6-6.3c-1.324 0-2.541.517-3.5 1.382V2a1 1 0 0 0-1-1Z\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","docsFormList":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'64\' height=\'64\' viewBox=\'0 0 64 64\' fill=\'none\'><path d=\'M48 36.5v-33A1.5 1.5 0 0 0 46.5 2h-29A1.5 1.5 0 0 0 16 3.5v33a1.5 1.5 0 0 0 1.5 1.5h29a1.5 1.5 0 0 0 1.5-1.5Z\' stroke=\'currentColor\' stroke-opacity=\'0.5\' fill=\'none\'/><rect x=\'20\' y=\'6\' width=\'17\' height=\'4\' rx=\'1\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'20\' y=\'14\' width=\'17\' height=\'4\' rx=\'1\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'20\' y=\'22\' width=\'3\' height=\'3\' rx=\'0.75\' fill=\'currentColor\' fill-opacity=\'0.3\' stroke=\'currentColor\' stroke-linejoin=\'round\'/><rect x=\'31\' y=\'31\' width=\'14\' height=\'4\' rx=\'1\' fill=\'currentColor\'/><path d=\'M26 23.5h8\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M15 32.483c-.855.117-1.556.235-2.065.33a1.433 1.433 0 0 0-1.135 1.12l-5.33 24.88c-.224 1.043.684 1.997 1.743 1.862A86.956 86.956 0 0 1 19 60c7.456 0 13.5 2.5 13.5 2.5S38.544 60 46 60c4.617 0 8.5.383 10.788.675 1.059.135 1.967-.82 1.743-1.863L53.2 33.933a1.432 1.432 0 0 0-1.134-1.12A47.656 47.656 0 0 0 49 32.355\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><path fill-rule=\'evenodd\' clip-rule=\'evenodd\' d=\'M33 39v21.75c0-2.329 15.066-3.198 23.269-1.877a.51.51 0 0 0 .582-.601l-4.793-23.489a.479.479 0 0 0-.33-.369c-.774-.229-1.701-.392-2.728-.499V36.5a2.5 2.5 0 0 1-2.5 2.5H33Zm-18-4.958V36.5a2.5 2.5 0 0 0 2.5 2.5H32v21.75c0-2.329-15.066-3.198-23.269-1.877a.51.51 0 0 1-.582-.601l4.793-23.489a.478.478 0 0 1 .33-.369A13.109 13.109 0 0 1 15 34.042Z\' fill=\'currentColor\' fill-opacity=\'0.12\'/></svg>","rating":"<svg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 20 20\' width=\'20\' height=\'20\' fill=\'none\'><path d=\'M9.453 1.668a.75.75 0 0 1 1.345 0l2.239 4.536a.75.75 0 0 0 .564.41l5.006.728a.75.75 0 0 1 .416 1.28l-3.622 3.53a.75.75 0 0 0-.216.664l.855 4.986a.75.75 0 0 1-1.088.79l-4.478-2.353a.75.75 0 0 0-.698 0L5.3 18.593a.75.75 0 0 1-1.089-.79l.855-4.987a.75.75 0 0 0-.215-.664l-3.623-3.53a.75.75 0 0 1 .416-1.28l5.006-.727a.75.75 0 0 0 .565-.41l2.239-4.537Z\' stroke=\'currentColor\' fill=\'none\'></path></svg>","emptyStateEntries":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'64\' height=\'64\' viewBox=\'0 0 64 64\' fill=\'none\'><path d=\'M19 31.732V62.5a.5.5 0 0 0 .5.5H41V3H19.5a.5.5 0 0 0-.5.5v15\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M48 3.25a.25.25 0 0 0-.25-.25H41v60h6.75a.25.25 0 0 0 .25-.25V3.25Z\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\' stroke-linejoin=\'round\'/><path d=\'M27 14h6\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'21.0001\' y=\'5\' width=\'18\' height=\'12\' rx=\'0.25\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'28.0001\' y=\'8\' width=\'4\' height=\'3\' rx=\'0.5\' fill=\'currentColor\' fill-opacity=\'0.5\'/><path d=\'M27 42.5h6\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M39 45.25v-11.5a.25.25 0 0 0-.25-.25h-17.5a.25.25 0 0 0-.25.25v11.5c0 .138.112.25.25.25h17.5a.25.25 0 0 0 .25-.25Z\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'28.0001\' y=\'36.5\' width=\'4\' height=\'3\' rx=\'0.5\' fill=\'currentColor\' fill-opacity=\'0.5\'/><path d=\'M27 56.5h6\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'21.0001\' y=\'47.5\' width=\'18\' height=\'12\' rx=\'0.25\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'28.0001\' y=\'50.5\' width=\'4\' height=\'3\' rx=\'0.5\' fill=\'currentColor\' fill-opacity=\'0.5\'/><path d=\'M24 23h15\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M23.5 19h15.25a.25.25 0 0 1 .25.25v12a.25.25 0 0 1-.25.25H23.5\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M10.5 28.5H17\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'4.00006\' y=\'18.75\' width=\'19.5\' height=\'13\' rx=\'0.25\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'11.5833\' y=\'22\' width=\'4.33333\' height=\'3.25\' rx=\'0.5\' fill=\'currentColor\' fill-opacity=\'0.5\'/><path d=\'M24 31h14.5\' stroke=\'currentColor\' stroke-opacity=\'0.3\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path fill=\'currentColor\' fill-opacity=\'0.3\' d=\'M23.5 19H39v4H23.5z\'/><path d=\'m52.58 62.138.263-1.384-.5-.381-1.252-.955.882-.119-.31-.632-.238-1.765 1.646-1.12.572-.751.942.322.441-.06.382-.5 2.194 1.276 1.133.072.5.381-.13.692.941.322-.394 2.075-.513 1.192-.513 1.192-.941-.322-.823.56-1.133-.071-1.765.238-1.383-.262Z\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'m52.962 61.637.823-.56-.81-1.014.071-1.133m0 0-.691-.131m.691.13.382-.5.382-.5-.37-1.074.382-.5-.31-.633m1.586 5.191.774-1.017m0 0 1.09 1.809m-1.09-1.809-.047-2.015-.623-1.29m3.174 5.214-.37-1.074-.679-1.705.263-1.383m0 0 1.514-.43m-1.514.43-.56-.823-.92-1.422\' stroke=\'currentColor\' stroke-opacity=\'0.12\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M63 63H1\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/></svg>","entries":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M16 8c-5.2 2.39-10.167.996-12 0v9.46c5.2 2.789 10.167 1.162 12 0V8Z\' fill=\'currentColor\' fill-opacity=\'0.12\'/><path d=\'M6.085 5.525C4.808 5.922 4 6.51 4 7.167c0 1.196 2.686 2.166 6 2.166s6-.97 6-2.166c0-.657-.809-1.245-2.085-1.642\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'M16 10.5c0 1.197-2.686 2.167-6 2.167s-6-.97-6-2.167m12 3.25c0 1.197-2.686 2.167-6 2.167s-6-.97-6-2.167\' stroke=\'currentColor\' fill=\'none\'/><path d=\'M4 7.167v9.666C4 18.03 6.686 19 10 19s6-.97 6-2.167V7.167\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'m12 5-2 2m0 0L8 5m2 2V1.5\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","menuIcon":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path fill-rule=\'evenodd\' clip-rule=\'evenodd\' d=\'M1.5 0A1.5 1.5 0 0 0 0 1.5v17A1.5 1.5 0 0 0 1.5 20h17a1.5 1.5 0 0 0 1.5-1.5v-17A1.5 1.5 0 0 0 18.5 0h-17ZM3 2a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1h9a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H3ZM2 7.5a1 1 0 0 1 1-1h9a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-1Zm9 7.5a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-1a1 1 0 0 0-1-1h-6Z\' fill=\'#fff\'/><rect x=\'12\' y=\'16.25\' width=\'4\' height=\'0.5\' rx=\'0.25\' fill=\'#fff\'/></svg>","resultOutput":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M12.5 16h-10A1.5 1.5 0 0 1 1 14.5v-12A1.5 1.5 0 0 1 2.5 1h11A1.5 1.5 0 0 1 15 2.5v10\' stroke=\'currentColor\' stroke-opacity=\'0.3\' fill=\'none\'/><rect x=\'3\' y=\'3\' width=\'10\' height=\'2.5\' rx=\'1\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'3\' y=\'7.5\' width=\'10\' height=\'2.5\' rx=\'1\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'8\' y=\'11.75\' width=\'5\' height=\'2.5\' rx=\'1\' fill=\'currentColor\' fill-opacity=\'0.5\'/><path fill-rule=\'evenodd\' clip-rule=\'evenodd\' d=\'M12 18.5a1.5 1.5 0 0 0 1.5 1.5h5a1.5 1.5 0 0 0 1.5-1.5v-5a1.5 1.5 0 0 0-1.5-1.5h-5a1.5 1.5 0 0 0-1.5 1.5v5Zm6.354-2.146a.5.5 0 0 0 0-.708l-2-2a.5.5 0 0 0-.708.708l1.147 1.146H14a.5.5 0 0 0 0 1h2.793l-1.147 1.146a.5.5 0 0 0 .708.708l2-2Z\' fill=\'currentColor\'/><path d=\'m3.75 13 1.09 1 1.91-2\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","resultOutputItem":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M12.5 15h-10A1.5 1.5 0 0 1 1 13.5v-11A1.5 1.5 0 0 1 2.5 1h13A1.5 1.5 0 0 1 17 2.5v10\' stroke=\'currentColor\' stroke-opacity=\'0.3\' fill=\'none\'/><path fill-rule=\'evenodd\' clip-rule=\'evenodd\' d=\'M12 18.5a1.5 1.5 0 0 0 1.5 1.5h5a1.5 1.5 0 0 0 1.5-1.5v-5a1.5 1.5 0 0 0-1.5-1.5h-5a1.5 1.5 0 0 0-1.5 1.5v5Zm6.354-2.146a.5.5 0 0 0 0-.708l-2-2a.5.5 0 0 0-.708.708l1.147 1.146H14a.5.5 0 0 0 0 1h2.793l-1.147 1.146a.5.5 0 0 0 .708.708l2-2Z\' fill=\'currentColor\'/><path d=\'M6.946 4.734c-.3-1.018-.988-1.087-1.73-1.087-.741 0-1.53.426-1.53 1.168 0 .594.186.87 1.06 1.227l1.206.456c.874.357 1.111.622 1.138 1.21.045 1.015-1.055 1.223-1.796 1.223-.742 0-1.528-.102-1.794-1.007M5.284 3l.01 6.753\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'m13 5 2 1.5m0 0L13 8m2-1.5H7.5m0 0c1 0 2.5 1 2.5 3.5v2.5m-2.5-6h-2m6 4-1.5 2m0 0-1.5-2\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","calculator":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M15.5 12.5v-10A1.5 1.5 0 0 0 14 1H3a1.5 1.5 0 0 0-1.5 1.5v15A1.5 1.5 0 0 0 3 19h9.5\' stroke=\'currentColor\' fill=\'none\'/><rect x=\'9\' y=\'9\' width=\'2\' height=\'2\' rx=\'1\' fill=\'currentColor\'/><rect x=\'3\' y=\'2.5\' width=\'11\' height=\'5.5\' rx=\'1\' fill=\'currentColor\' fill-opacity=\'0.5\'/><rect x=\'3\' y=\'15\' width=\'2\' height=\'2\' rx=\'1\' fill=\'currentColor\'/><rect x=\'6\' y=\'15\' width=\'2\' height=\'2\' rx=\'1\' fill=\'currentColor\'/><rect x=\'3\' y=\'12\' width=\'2\' height=\'2\' rx=\'1\' fill=\'currentColor\'/><rect x=\'6\' y=\'12\' width=\'2\' height=\'2\' rx=\'1\' fill=\'currentColor\'/><rect x=\'3\' y=\'9\' width=\'2\' height=\'2\' rx=\'1\' fill=\'currentColor\'/><rect x=\'6\' y=\'9\' width=\'2\' height=\'2\' rx=\'1\' fill=\'currentColor\'/><rect x=\'12\' y=\'9\' width=\'2\' height=\'2\' rx=\'0.5\' fill=\'currentColor\' fill-opacity=\'0.5\'/><path d=\'M11.75 5.25c-.414 0-.75.252-.75.563v.375c0 .31.336.562.75.562s.75-.252.75-.563v-.375c0-.31-.336-.562-.75-.562Zm0 0c.414 0 .75-.252.75-.563v-.375c0-.31-.336-.562-.75-.562s-.75.252-.75.563v.375c0 .31.336.562.75.562Z\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path fill-rule=\'evenodd\' clip-rule=\'evenodd\' d=\'M9 18.5a1.5 1.5 0 0 0 1.5 1.5h8a1.5 1.5 0 0 0 1.5-1.5v-5a1.5 1.5 0 0 0-1.5-1.5h-8A1.5 1.5 0 0 0 9 13.5v5Zm2-5a.5.5 0 0 0 0 1h.25v3H11a.5.5 0 0 0 0 1h1.5a.5.5 0 0 0 0-1h-.25v-3h.25a.5.5 0 0 0 0-1H11Z\' fill=\'currentColor\'/></svg>","checkbox":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><rect x=\'2\' y=\'2\' width=\'16\' height=\'16\' rx=\'3\' stroke=\'currentColor\' fill=\'none\'/><path d=\'m5.5 11.427 2.46 2.425a.5.5 0 0 0 .748-.051L14.5 6.25\' stroke=\'currentColor\' stroke-width=\'1.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","form":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><rect x=\'1\' y=\'1\' width=\'18\' height=\'18\' rx=\'1.5\' stroke=\'currentColor\' stroke-opacity=\'0.5\' fill=\'none\'/><rect x=\'3.5\' y=\'3.5\' width=\'10\' height=\'3\' rx=\'1\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\' stroke-linejoin=\'round\'/><rect x=\'3.5\' y=\'9\' width=\'10\' height=\'3\' rx=\'1\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\' stroke-linejoin=\'round\'/><rect x=\'9\' y=\'14.5\' width=\'8\' height=\'2.5\' rx=\'1\' fill=\'currentColor\'/></svg>","formPicker":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M15 14V2.5A1.5 1.5 0 0 0 13.5 1h-11A1.5 1.5 0 0 0 1 2.5v11A1.5 1.5 0 0 0 2.5 15H6\' stroke=\'currentColor\' stroke-opacity=\'0.5\' fill=\'none\'/><rect x=\'3\' y=\'3\' width=\'8\' height=\'2\' rx=\'0.5\' fill=\'currentColor\' fill-opacity=\'0.5\'/><rect x=\'3\' y=\'6\' width=\'8\' height=\'2\' rx=\'0.5\' fill=\'currentColor\' fill-opacity=\'0.5\'/><rect x=\'6\' y=\'9.75\' width=\'7\' height=\'2.5\' rx=\'0.5\' fill=\'currentColor\' fill-opacity=\'0.5\'/><rect x=\'6\' y=\'14\' width=\'13\' height=\'5\' rx=\'1.5\' stroke=\'currentColor\' fill=\'none\'/><path d=\'m14.75 16.25 1.25 1 1.25-1\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M8 16.5h3.5\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","input":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M3 8h.75m.75 0h-.75m0 0v4m0 0H3m.75 0h.75\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'1\' y=\'6\' width=\'18\' height=\'8\' rx=\'1.5\' stroke=\'currentColor\' fill=\'none\'/></svg>","radio":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><circle cx=\'10\' cy=\'10\' r=\'8.5\' stroke=\'currentColor\' fill=\'none\'/><circle cx=\'10\' cy=\'10\' r=\'3.5\' fill=\'currentColor\' stroke=\'currentColor\'/></svg>","select":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><rect x=\'1\' y=\'7\' width=\'18\' height=\'6\' rx=\'1.5\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\'/><path d=\'m13 9.25 1.75 1.5 1.75-1.5M3.5 10H8\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","selectOption":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><rect x=\'1\' y=\'1\' width=\'18\' height=\'5\' rx=\'1.5\' stroke=\'currentColor\' fill=\'none\'/><path d=\'M1 4v13.5A1.5 1.5 0 0 0 2.5 19h15a1.5 1.5 0 0 0 1.5-1.5V4\' stroke=\'currentColor\' fill=\'none\'/><path d=\'m13.75 4 1.5-1 1.5 1M3.5 3.5H8m-4 5h6.5m-6.5 8h6.5\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path fill-rule=\'evenodd\' clip-rule=\'evenodd\' d=\'M3.5 10.25a1 1 0 0 0-1 1v2.5a1 1 0 0 0 1 1h13a1 1 0 0 0 1-1v-2.5a1 1 0 0 0-1-1h-13ZM4 12a.5.5 0 0 0 0 1h6.5a.5.5 0 0 0 0-1H4Z\' fill=\'currentColor\'/></svg>","submit":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'m18.5 1.5-9 9L12 19l6.5-17.5Z\' fill=\'currentColor\' fill-opacity=\'0.12\'/><path d=\'m19 1-6.468 16.633a.5.5 0 0 1-.946-.04L9.5 10.5M19 1l-9.5 9.5M19 1 2.367 7.468a.5.5 0 0 0 .04.946L9.5 10.5\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M1 13.5 3.5 11M6 18.5 8.5 16M2 17.5 4.5 15\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","textarea":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M3 4h.75m.75 0h-.75m0 0v4m0 0H3m.75 0h.75\' stroke=\'currentColor\' stroke-opacity=\'0.5\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><rect x=\'1\' y=\'2\' width=\'18\' height=\'16\' rx=\'1.5\' stroke=\'currentColor\' fill=\'none\'/></svg>","checkboxes":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><rect x=\'1\' y=\'1\' width=\'7\' height=\'7\' rx=\'1.5\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\'/><rect x=\'1\' y=\'10\' width=\'7\' height=\'7\' rx=\'1.5\' stroke=\'currentColor\' fill=\'none\'/><path d=\'M1 20a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1\' stroke=\'currentColor\' fill=\'none\'/><path d=\'m2.75 5.139 1.148 1.167L6.358 3\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M10 4.5h7.5M10 14h7.5\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/></svg>","radios":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><circle cx=\'4.5\' cy=\'4.5\' r=\'3\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\'/><circle cx=\'4.5\' cy=\'4.5\' r=\'1.5\' fill=\'currentColor\'/><circle cx=\'4.5\' cy=\'12.75\' r=\'3\' stroke=\'currentColor\' fill=\'none\'/><path d=\'M7.28 20a.598.598 0 0 0-.052-.25 3 3 0 0 0-5.455 0 .598.598 0 0 0-.052.25\' stroke=\'currentColor\' fill=\'none\'/><path d=\'M10 4.5h7.5M10 12.75h7.5\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/></svg>","custom-data":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M13 4C7.8 6.39 2.833 4.996 1 4v9.46c5.2 2.789 10.167 1.162 12 0V4Z\' fill=\'currentColor\' fill-opacity=\'0.12\'/><ellipse cx=\'7\' cy=\'3.16667\' rx=\'6\' ry=\'2.16667\' stroke=\'currentColor\' fill=\'none\'/><path d=\'M13 6.5c0 1.197-2.686 2.167-6 2.167S1 7.697 1 6.5m12 3.25c0 1.197-2.686 2.167-6 2.167s-6-.97-6-2.167\' stroke=\'currentColor\' fill=\'none\'/><path d=\'M1 3.167v9.666C1 14.03 3.686 15 7 15c.636 0 1.249-.036 1.824-.102M13 3.167V11\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/><path d=\'m17.886 12.5-1.636-1.636L17.614 9.5l1.636 1.636-1.364 1.364Z\' fill=\'currentColor\' fill-opacity=\'0.3\'/><path d=\'m15.952 10.613 1.935 1.935m-1.935-1.935-5.695 5.379a.5.5 0 0 0-.145.255l-.42 1.89a.5.5 0 0 0 .646.584l1.953-.651a.5.5 0 0 0 .196-.121l5.4-5.4m-1.935-1.936.905-.906a1 1 0 0 1 1.415 0l.52.521a1 1 0 0 1 0 1.415l-.905.905\' stroke=\'currentColor\' fill=\'none\'/></svg>","file":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path fill-rule=\'evenodd\' clip-rule=\'evenodd\' d=\'M2.5 9A1.5 1.5 0 0 0 1 10.5v5A1.5 1.5 0 0 0 2.5 17h5A1.5 1.5 0 0 0 9 15.5v-5A1.5 1.5 0 0 0 7.5 9h-5Zm2.146 1.646a.5.5 0 0 1 .708 0l2 2a.5.5 0 0 1-.708.708L5.5 12.207V15a.5.5 0 0 1-1 0v-2.793l-1.146 1.147a.5.5 0 0 1-.708-.708l2-2Z\' fill=\'currentColor\'/><path d=\'M13.4 1h.083a1.5 1.5 0 0 1 1.055.433l4.017 3.973A1.5 1.5 0 0 1 19 6.472v.066M13.4 1H6.5A1.5 1.5 0 0 0 5 2.5V9m8.4-8v5.038a.5.5 0 0 0 .5.5H19m0 0V17.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 5 17.5V17\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M13.5 6.5v-6l6 6h-6Z\' fill=\'currentColor\' fill-opacity=\'0.5\'/></svg>","senderEmail":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><rect x=\'1\' y=\'4\' width=\'18\' height=\'12\' rx=\'1.5\' stroke=\'currentColor\' fill=\'none\'/><path d=\'m1.5 4.5 7.589 5.803a1.5 1.5 0 0 0 1.822 0L18.5 4.5m-17 11 5.687-6.651M18.5 15.5l-5.687-6.651\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M18.5 4h-17l8.5 6.5L18.5 4Z\' fill=\'currentColor\' fill-opacity=\'0.12\'/></svg>","formCustom":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M13 3.571 15.571 1 19 4.429 16.429 7 13 3.571Z\' fill=\'currentColor\' fill-opacity=\'0.3\'/><path d=\'m12.817 3.638 3.545 3.545m-3.545-3.545-10.3 9.729a1.5 1.5 0 0 0-.435.765l-.986 4.437a.25.25 0 0 0 .323.291l4.563-1.52a1.5 1.5 0 0 0 .586-.363l9.794-9.794m-3.545-3.545 2.414-2.414a.763.763 0 0 1 1.08 0l2.465 2.465a.763.763 0 0 1 0 1.08l-2.414 2.414\' stroke=\'currentColor\' fill=\'none\'/></svg>","country":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M7.086 2.543 4 4.086l.514 7.2 6.686-.515 5.143-1.542-.514-7.2-8.743.514Z\' fill=\'currentColor\' fill-opacity=\'0.12\'/><path d=\'M4.257 4.086c.857-.686 3.291-1.955 6.171-1.543 2.88.411 4.972-.857 5.657-1.543v8.229c-.685.685-2.777 1.954-5.657 1.542-2.88-.411-5.314.858-6.171 1.543m0-8.228v8.228m0-8.228V3.57m0 8.743V19\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","date":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path fill=\'currentColor\' fill-opacity=\'0.12\' d=\'M1.25 1.25h17.5v4H1.25z\'/><rect x=\'1\' y=\'1\' width=\'18\' height=\'18\' rx=\'1.5\' stroke=\'currentColor\' fill=\'none\'/><path d=\'M1 5.5h18M1 10h18M5.5 5.5V19M10 5.5V19m4.5-13.5V19M1 14.5h18\' stroke=\'currentColor\' fill=\'none\'/><path fill=\'currentColor\' fill-opacity=\'0.5\' d=\'M10.25 10.25h4v4h-4z\'/></svg>","time":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><circle cx=\'10\' cy=\'10\' r=\'9\' stroke=\'currentColor\' fill=\'none\'/><path d=\'M10 4.25v5.714L7 12.25\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'m10 10 6 4\' stroke=\'currentColor\' stroke-opacity=\'0.12\' stroke-linecap=\'round\' fill=\'none\'/></svg>","phone":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M5.143 1h-2.95c-.658 0-1.201.519-1.19 1.175.057 3.287.916 7.067 3.512 10.31 3.957 4.945 9.65 6.346 13.082 6.5.79.036 1.403-.623 1.403-1.413v-2.763a1.5 1.5 0 0 0-1.364-1.494l-3.013-.274a1.5 1.5 0 0 0-1.096.341l-1.533 1.277a.485.485 0 0 1-.54.059c-2.849-1.542-5.117-4.51-6.068-6.085a.483.483 0 0 1 .077-.592L6.515 6.99a1.5 1.5 0 0 0 .433-1.197l-.312-3.429A1.5 1.5 0 0 0 5.143 1Z\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\' stroke-linecap=\'round\'/></svg>","starRating":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M9.522 6.866a.5.5 0 0 1 .957 0l.682 2.253a.5.5 0 0 0 .49.355l2.37-.056c.498-.012.705.633.293.913l-1.937 1.319a.5.5 0 0 0-.19.581l.785 2.198a.5.5 0 0 1-.772.568l-1.899-1.43a.5.5 0 0 0-.601 0l-1.9 1.43a.5.5 0 0 1-.77-.568l.783-2.198a.5.5 0 0 0-.19-.581l-1.935-1.32c-.412-.28-.205-.925.293-.913l2.369.056a.5.5 0 0 0 .49-.355l.683-2.253Z\' fill=\'currentColor\' fill-opacity=\'0.3\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\'/><path d=\'m5.927 12.449-2.135 1.524a.5.5 0 0 1-.759-.583l.938-2.492a.5.5 0 0 0-.197-.596L1.487 8.825c-.424-.274-.222-.931.282-.92l2.854.064a.5.5 0 0 0 .488-.348l.84-2.63a.5.5 0 0 1 .952 0L7.704 7.5m6.369 4.949 2.135 1.524a.5.5 0 0 0 .759-.583l-.938-2.492a.5.5 0 0 1 .197-.596l2.287-1.477c.424-.274.222-.931-.282-.92l-2.854.064a.5.5 0 0 1-.488-.348l-.84-2.63a.5.5 0 0 0-.952 0L12.296 7.5\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","calculate":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M1 2.5A1.5 1.5 0 0 1 2.5 1H9v8H1V2.5ZM1 11h8v8H2.5A1.5 1.5 0 0 1 1 17.5V11ZM11 1h6.5A1.5 1.5 0 0 1 19 2.5V9h-8V1Z\' stroke=\'currentColor\' fill=\'none\'/><path d=\'M11 11h8v6.5a1.5 1.5 0 0 1-1.5 1.5H11v-8Z\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\'/><path d=\'M5 3v4m2-2H3m14 0h-4m4 9h-4m4 2h-4m-9.414-2.414 2.829 2.828m0-2.828-2.829 2.828\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/></svg>","compute":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M4 5.5A1.5 1.5 0 0 1 5.5 4h9A1.5 1.5 0 0 1 16 5.5v9a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 4 14.5v-9Z\' stroke=\'currentColor\' fill=\'none\'/><path d=\'M7 7.75A.75.75 0 0 1 7.75 7h4.5a.75.75 0 0 1 .75.75v4.5a.75.75 0 0 1-.75.75h-4.5a.75.75 0 0 1-.75-.75v-4.5Z\' fill=\'currentColor\' fill-opacity=\'0.3\' stroke=\'currentColor\' stroke-linejoin=\'round\'/><path d=\'M7 4V1.5M10 4V1.5M13 4V1.5m-6 17V16m3 2.5V16m3 2.5V16M1.5 7H4m-2.5 3H4m-2.5 3H4m12-6h2.5M16 10h2.5M16 13h2.5\' stroke=\'currentColor\' stroke-linecap=\'round\' fill=\'none\'/></svg>","dynamic":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M14.5 10 10 12.5V19l4.5-2.5V10Z\' fill=\'currentColor\' fill-opacity=\'0.3\'/><path d=\'M5.209 2.886 8.674 6.99a.5.5 0 0 1 .118.323v2.813a.5.5 0 0 0 .754.43l1.212-.715a.5.5 0 0 0 .246-.43V7.323a.5.5 0 0 1 .13-.337l3.762-4.11\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M15.111 2.444c0 .798-2.263 1.445-5.055 1.445C7.263 3.889 5 3.242 5 2.444 5 1.647 7.263 1 10.056 1c2.792 0 5.055.647 5.055 1.444Z\' stroke=\'currentColor\' fill=\'none\'/><path d=\'m9.941 19-4.563-2.608a.75.75 0 0 1-.378-.65V9.823l4.941 2.823V19Z\' fill=\'currentColor\' fill-opacity=\'0.12\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\'/><path d=\'m9.94 19 4.564-2.608a.75.75 0 0 0 .378-.65V9.823L9.94 12.647V19Z\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M8.664 7.73 5 9.824l4.941 2.823 4.941-2.823L11 7.605\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>","corvus":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M4.884 10.004c-.372-4.092-2.17-3.72-3.255-3.255 1.085-1.24 3.255-3.72 5.58-1.396 2.326-4.65 8.61-3.459 11.162-2.325v3.256c-1.86-1.86-6.494-1.418-7.906.465-1.395 1.86-1.395 6.975 1.86 7.905 2.28.652 5.115-.155 6.046-.93v2.79c-2.233 2.233-6.511 1.706-8.371.93-1.55-.774-4.744-3.348-5.116-7.44Z\' stroke=\'currentColor\' stroke-linejoin=\'round\' fill=\'none\'/><path d=\'M8.605 14.19C6.67 11.356 6.589 7.368 7.209 5.352l.466-.93 1.86-1.395 1.86-.93h2.325l2.79.465c-3.166.327-5.688 2.825-6.393 4.08l-.582 3.36.93 3.721 1.86.93h3.72l2.322-.928c.002-.413.003-.6.003-.002 0 .505-.006.863-.012 1.15a7.042 7.042 0 0 1-.008.37c.089.452-1.756 1.111-3.805 1.281-2.352.097-4.319.039-5.94-2.336Z\' fill=\'currentColor\' fill-opacity=\'0.3\'/></svg>","paycek":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path d=\'M2.733 10.688 1.5 18.5h1.54a3 3 0 0 0 2.942-2.412L6.5 13.5h5.143A6.857 6.857 0 0 0 18.5 6.643 5.143 5.143 0 0 0 13.357 1.5h-2.474a4 4 0 0 0-3.795 2.735L6.5 6H13a1.5 1.5 0 0 1 0 3H4.709a2 2 0 0 0-1.976 1.688Z\' stroke=\'currentColor\' fill=\'none\'/><path d=\'M12.495 13.5c3.6-1.2 3.107-4.926 2.44-6.426l-.94 1.426-1 .5h-3c-2.8 0-3.698 2.817-3.981 4.39l6.481.11Z\' fill=\'currentColor\' fill-opacity=\'0.3\'/></svg>","nationbuilder":"<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' fill=\'none\'><path opacity=\'0.8\' d=\'M6.317 2.337a8.515 8.515 0 0 0-4.606 5.77\' stroke=\'currentColor\' fill=\'none\'/><path opacity=\'0.7\' d=\'M1.711 8.108A8.574 8.574 0 0 0 3.354 15.3\' stroke=\'currentColor\' fill=\'none\'/><path opacity=\'0.5\' d=\'M10 18.5a8.484 8.484 0 0 1-6.646-3.2\' stroke=\'currentColor\' fill=\'none\'/><path opacity=\'0.7\' d=\'M10 18.5c2.696 0 5.1-1.256 6.657-3.214\' stroke=\'currentColor\' fill=\'none\'/><path d=\'M16.656 15.286a8.564 8.564 0 0 0 1.632-7.178\' stroke=\'currentColor\' fill=\'none\'/><path opacity=\'0.9\' d=\'M18.289 8.108a8.516 8.516 0 0 0-4.59-5.764\' stroke=\'currentColor\' fill=\'none\'/><path opacity=\'0.5\' d=\'M6.316 2.337a8.57 8.57 0 0 1 7.382.007\' stroke=\'currentColor\' fill=\'none\'/><path d=\'m9 5.5-1.5 9m5-9-1.5 9m-5-3h7.5M6.5 8H14\' stroke=\'currentColor\' stroke-linecap=\'round\' stroke-linejoin=\'round\' fill=\'none\'/></svg>"}}');

/***/ }),

/***/ "jquery":
/*!*************************!*\
  !*** external "jQuery" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = window["jQuery"];

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/ensure chunk */
/******/ 	(() => {
/******/ 		__webpack_require__.f = {};
/******/ 		// This file contains only the entry chunk.
/******/ 		// The chunk loading function for additional chunks
/******/ 		__webpack_require__.e = (chunkId) => {
/******/ 			return Promise.all(Object.keys(__webpack_require__.f).reduce((promises, key) => {
/******/ 				__webpack_require__.f[key](chunkId, promises);
/******/ 				return promises;
/******/ 			}, []));
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get javascript chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference async chunks
/******/ 		__webpack_require__.u = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "" + chunkId + ".js";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get mini-css chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference async chunks
/******/ 		__webpack_require__.miniCssF = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return undefined;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/load script */
/******/ 	(() => {
/******/ 		var inProgress = {};
/******/ 		var dataWebpackPrefix = "EightshiftForms:";
/******/ 		// loadScript function to load a script via script tag
/******/ 		__webpack_require__.l = (url, done, key, chunkId) => {
/******/ 			if(inProgress[url]) { inProgress[url].push(done); return; }
/******/ 			var script, needAttach;
/******/ 			if(key !== undefined) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				for(var i = 0; i < scripts.length; i++) {
/******/ 					var s = scripts[i];
/******/ 					if(s.getAttribute("src") == url || s.getAttribute("data-webpack") == dataWebpackPrefix + key) { script = s; break; }
/******/ 				}
/******/ 			}
/******/ 			if(!script) {
/******/ 				needAttach = true;
/******/ 				script = document.createElement('script');
/******/ 		
/******/ 				script.charset = 'utf-8';
/******/ 				if (__webpack_require__.nc) {
/******/ 					script.setAttribute("nonce", __webpack_require__.nc);
/******/ 				}
/******/ 				script.setAttribute("data-webpack", dataWebpackPrefix + key);
/******/ 		
/******/ 				script.src = url;
/******/ 			}
/******/ 			inProgress[url] = [done];
/******/ 			var onScriptComplete = (prev, event) => {
/******/ 				// avoid mem leaks in IE.
/******/ 				script.onerror = script.onload = null;
/******/ 				clearTimeout(timeout);
/******/ 				var doneFns = inProgress[url];
/******/ 				delete inProgress[url];
/******/ 				script.parentNode && script.parentNode.removeChild(script);
/******/ 				doneFns && doneFns.forEach((fn) => (fn(event)));
/******/ 				if(prev) return prev(event);
/******/ 			}
/******/ 			var timeout = setTimeout(onScriptComplete.bind(null, undefined, { type: 'timeout', target: script }), 120000);
/******/ 			script.onerror = onScriptComplete.bind(null, script.onerror);
/******/ 			script.onload = onScriptComplete.bind(null, script.onload);
/******/ 			needAttach && document.head.appendChild(script);
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		__webpack_require__.p = "/wp-content/plugins/eightshift-forms/public/";
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"applicationBlocksFrontend": 0
/******/ 		};
/******/ 		
/******/ 		__webpack_require__.f.j = (chunkId, promises) => {
/******/ 				// JSONP chunk loading for javascript
/******/ 				var installedChunkData = __webpack_require__.o(installedChunks, chunkId) ? installedChunks[chunkId] : undefined;
/******/ 				if(installedChunkData !== 0) { // 0 means "already installed".
/******/ 		
/******/ 					// a Promise means "currently loading".
/******/ 					if(installedChunkData) {
/******/ 						promises.push(installedChunkData[2]);
/******/ 					} else {
/******/ 						if(true) { // all chunks have JS
/******/ 							// setup Promise in chunk cache
/******/ 							var promise = new Promise((resolve, reject) => (installedChunkData = installedChunks[chunkId] = [resolve, reject]));
/******/ 							promises.push(installedChunkData[2] = promise);
/******/ 		
/******/ 							// start chunk loading
/******/ 							var url = __webpack_require__.p + __webpack_require__.u(chunkId);
/******/ 							// create error before stack unwound to get useful stacktrace later
/******/ 							var error = new Error();
/******/ 							var loadingEnded = (event) => {
/******/ 								if(__webpack_require__.o(installedChunks, chunkId)) {
/******/ 									installedChunkData = installedChunks[chunkId];
/******/ 									if(installedChunkData !== 0) installedChunks[chunkId] = undefined;
/******/ 									if(installedChunkData) {
/******/ 										var errorType = event && (event.type === 'load' ? 'missing' : event.type);
/******/ 										var realSrc = event && event.target && event.target.src;
/******/ 										error.message = 'Loading chunk ' + chunkId + ' failed.\n(' + errorType + ': ' + realSrc + ')';
/******/ 										error.name = 'ChunkLoadError';
/******/ 										error.type = errorType;
/******/ 										error.request = realSrc;
/******/ 										installedChunkData[1](error);
/******/ 									}
/******/ 								}
/******/ 							};
/******/ 							__webpack_require__.l(url, loadingEnded, "chunk-" + chunkId, chunkId);
/******/ 						}
/******/ 					}
/******/ 				}
/******/ 		};
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		// no on chunks loaded
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 		
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkEightshiftForms"] = self["webpackChunkEightshiftForms"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be in strict mode.
(() => {
"use strict";
/*!**********************************************************!*\
  !*** ./src/Blocks/assets/application-blocks-frontend.js ***!
  \**********************************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _styles_blocks_frontend_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./styles/blocks-frontend.scss */ "./src/Blocks/assets/styles/blocks-frontend.scss");
/* harmony import */ var _scripts_blocks_frontend__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./scripts/blocks-frontend */ "./src/Blocks/assets/scripts/blocks-frontend.js");
/**
 * This is the main entry point for Block Editor blocks used for the `WordPress frontend screen`.
 * This file registers styles and scripts.
 *
 * Usage: `WordPress frontend screen`.
 */ // Styles.

// Scripts.


})();

EightshiftForms = __webpack_exports__;
/******/ })()
;
"use strict";
(self["webpackChunk_eightshift_redesign"] = self["webpackChunk_eightshift_redesign"] || []).push([["src_Blocks_components_card-article_assets_card-article_js"],{

/***/ "./src/Blocks/components/card-article/assets/card-article.js":
/*!*******************************************************************!*\
  !*** ./src/Blocks/components/card-article/assets/card-article.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CardArticle: () => (/* binding */ CardArticle)
/* harmony export */ });
class CardArticle {
    constructor({ hoverClassElementSelector, selfDetectSelector, elements }){
        this.hoverClassElementSelector = hoverClassElementSelector;
        this.selfDetectSelector = selfDetectSelector;
        this.elements = elements;
        this.HOVERED_CLASS = 'hovered';
    }
    init = ()=>{
        [
            ...this.elements
        ].forEach((element)=>{
            element.addEventListener('mouseenter', this.onEnter);
            element.addEventListener('mouseleave', this.onLeave);
            element.addEventListener('focus', this.onEnter);
            element.addEventListener('blur', this.onLeave);
        });
    };
    onEnter = ({ target })=>{
        if (target) {
            // Hover on all
            if (target.classList.contains(this.selfDetectSelector)) {
                target.classList.add(this.HOVERED_CLASS);
                return;
            }
            target.closest(`.${this.hoverClassElementSelector}`)?.classList.add(this.HOVERED_CLASS);
        }
    };
    onLeave = ({ target })=>{
        if (target) {
            if (target.classList.contains(this.selfDetectSelector)) {
                target.classList.remove(this.HOVERED_CLASS);
                return;
            }
            target.closest(`.${this.hoverClassElementSelector}`)?.classList.remove(this.HOVERED_CLASS);
        }
    };
}


/***/ })

}]);